=== Fixpass Pro (local prototype) ===
Contributors: mindanticipation
Tags: support, remote access, temporary login, debugging, troubleshooting
Requires at least: 6.5
Requires PHP: 7.4
Stable tag: 2.11.7
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Give your support team safe, temporary access to your site, and Spotlight the exact spot that's broken.

== Description ==

LOCAL AGENCY MVP: Pro 2.0.0-prototype.16 adds a WordPress agency workspace with one-use site connection codes, local owner consent, per-request owner approval, one-time or reusable entry and bounded owner-authorized extensions. The .16 hosted test portal and private package are published; .17 is local only. Simulated payments only; no email verification, recovery or automatic updates. Actual WordPress installation has not been verified. Read PROTOTYPE.md / prototype/README.md before testing. The inherited product description below documents the original support tools.

Something's wrong with your site and you need help. Usually that means a long email thread: describing the problem, sharing a password, sending screenshots, answering "which page?" and "which browser?".

Fixpass does it in a minute:

* **Spotlight the problem.** Click "Spotlight a problem" in the toolbar, then click the broken part of the page or drag a box around it. Add a note. Your support team opens that page with the spot highlighted, along with your screen size, browser and any errors on the page. Nothing on your screen is recorded.
* **Give access, safely.** One click creates a temporary administrator account for your support team, with a login link instead of a password. Choose 1 day to a week; extend or end it any time. When access ends, the account is deleted.
* **Copy the details.** One button copies the login link, your spots, site health and your plugins and themes, ready to paste into an email or ticket.
* **See what's happening.** The status shows when support logs in, logs out or finishes, and updates by itself.

Once support logs in, they get a Support session page with your spots, full site details, the debug log, errors, scheduled tasks and **troubleshooting mode**, which switches plugins off in their browser only, and **View as**, which shows the site as a lower role such as Subscriber. Your visitors never notice.

= Security =

* Login links are random 256-bit codes; only a hash is stored.
* Reusable links (support can come back until access ends) or one-time links.
* Password login is switched off for support accounts. They can't manage users or remove Fixpass.
* However access ends, the support account is deleted.
* Nothing is sent outside your site unless you send it.

Fixpass stays installed when new access ends. You can uninstall it manually when you no longer need it.

Documentation: https://github.com/george-stathopoulos/fixpass/tree/main/docs

== Installation ==

1. Install and activate Fixpass from Plugins → Add New, or upload the zip.
2. Fixpass opens with a short tour.
3. To get help, choose "Show the problem, then give access" (recommended) or "Just give access". With the first, you point at the problem on your site, add a note, then give access. Then copy the details and send them to your support team.

== Frequently Asked Questions ==

= Do I need an account anywhere? =

No. Fixpass runs entirely on your site.

= Who is "support"? =

Whoever helps you with your site: a developer, an agency, a plugin or theme vendor.

= Reusable or one-time link? =

Reusable, in most cases: support often needs to log in more than once over a few days. One-time is the strictest option.

= Will visitors notice anything? =

No. Spotlight and the support tools only show for administrators, and troubleshooting mode only affects support's browser.

= What does uninstalling remove? =

Every support account, Fixpass's tables and settings, the troubleshooting must-use plugin and Fixpass's scheduled tasks.

== Privacy ==

Agencies can optionally send newly confirmed reports to their configured Slack channel. Slack receives the problem description, selected Spotlight titles, notes and page links, access policy/deadline and a session-scoped bearer link. Anyone holding that link may use the exact owner-approved access while active; no FixHub login is required. It stops on expiry, revocation, consumed one-time entry or Slack integration changes. Local support-message bodies and raw diagnostics are excluded.

The original support tools keep diagnostics local. This Pro prototype additionally sends a license credential and the installation URL to the built-in hosted test licensing service; customer reports and diagnostics are sent to the connected agency only after the owner explicitly approves that report and finite access duration. Reports include the description, Spotlight notes and original URLs, browser/errors/failed requests, site health, recent fatal errors, plugins and themes. Portal reports contain no reusable login link; the agency uses a separate single-use, 60-second entry launch. Only a saved agency display name is used; authentication email is separate. Website removal can retain gated history or explicitly purge all selected website portal data. Manual sharing remains available and sends details only when you copy and share them. Spots keep the page address, your note, your screen size and browser, and errors on that page, for 90 days. Passwords, keys and email addresses are removed from the site details support sees.

Agency support sessions now synchronize a bounded history of action names, safe changed-component basenames, local event IDs and timestamps to the connected agency. No IP, actor identity, login URLs, credentials or freeform log details are included. Sync uses the exact installation credential and locally recorded grant/request/generation mapping, retries safely, and continues terminal-event delivery without paid entitlement. Up to 2,000 events per request are retained; the portal displays the latest 200. Older sessions may be unavailable and local retention can leave gaps. Ending access or resolving work does not delete hosted reports or synchronized history; disconnected or unlicensed history is hidden. Client groups, favourites and request workflow history are stored in your agency account.

== Changelog ==

= 2.11.7 =
* The toolbar notices (messages from support, access requests, support is logged in, Support has finished) no longer disappear when the connection to your support team's FixHub was last checked more than a minute ago or just failed.
* On the support Session page, Messages to the site owner and This session now sit side by side.

= 2.11.6 =
* Fixed a fatal error in 2.11.5 that could stop WordPress pages from loading. Update from 2.11.5 straight away.

= 2.11.5 =
* When support ends their access, the toolbar says Support has finished instead of still saying support is logged in.
* Access status and Last support access show how long support worked during the access.
* Fixed the layout of the Messages to the site owner box on the support session page.

= 2.11.4 =
* The agreement is no longer repeated on the Give support access screen; it stays under Your connection.

= 2.11.3 =
* Manage connection now explains your actual situation: when the site is already connected it no longer asks you to paste a code.

= 2.11.2 =
* The Access status card shows the session number, keeps the original request as it was and shows what it is now, with each approved extension listed as its own entry.

= 2.11.1 =
* Refresh connection now sits next to Manage connection, the agreement only opens when you open it, and connection actions look like buttons.
* With one-time access, support no longer sees Leave session, only End access.
* New messages from support and access requests appear in the toolbar and on the Fixpass page within about a minute, without reloading.

= 2.11.0 =
* The access history and the log FixHub shows your support team now use plain words. Settings private to other plugins (like review prompts) are no longer logged, and other settings are described by name instead of a code.
* Every access session now has a number such as #0001, shown in the access history, in Messages from support and in the history download.
* FixHub always receives the same session log you can read here, even if your agreement hides the history from you.

= 2.10.2 =
* Screenshots are deleted when the access they were sent with ends, and the Screenshots card says plainly when no access is open.
* Messages from support leave the top bar as soon as you have read them, and are hidden once you have read them and their access has ended.
* When support asks for access, the top bar and the Fixpass menu item now show it.
* Describe the problem first: the Access and Approval steps stay greyed out until you have.
* Fixed the Switch back to Support button on View as, the cursor landing on the wrong note after a screenshot, and the layout of the connection and request cards.

= 2.10.1 =
* Messages from your support team now always reach you: they have their own Messages from support card on the Fixpass page, even when your agreement does not show you the access history.
* The WordPress toolbar shows an envelope with the number of new messages from support, and a green dot while support is logged in (grey while access is open but nobody is logged in).

= 2.10.0 =
* Your support team can now switch individual support tools off for your site (Site details, Debugging, Troubleshoot mode, View as). Your agreement card lists any that are off.
* A support team member's own role can narrow what they may do on your site, such as no plugin installs or no code editing, and which tools they get. It can never give them more than your agreement allows.
* The support login is recorded with the limits that applied.

= 2.8.0 =
* Screenshots: support can open a screenshot full size in a full-page viewer, and you get a Screenshots on your site card where you can view and delete them yourself (type DELETE to confirm), as a fallback to the automatic delete.
* Support can get back to the support session with one button from a highlighted spot or a screenshot, instead of using the browser's Back button.
* The support login page now says who is entering, why, for how long, what support may do, and shows the agreement in an expandable section.
* Support's screens use the same look as yours: soft-fill tabs, one button size, clearer spots and session controls.

= 2.7.1 =
* The agreement card is clearer: it says plainly what you can and cannot do in the plugin, what the support team keeps for you, and that urgent situations such as a site being down are handled outside the agreement.

= 2.7.0 =
* New for support: a View as tab lets support see the site as a lower role, such as Subscriber, Customer or Editor, in their own browser, and switch back with one button. It can only reduce what support can do, never add to it, and the start and stop are recorded in the access history.

= 2.6.1 =
* Taking a screenshot no longer adds stray browser errors from your site to the report.

= 2.6.0 =
* You can send just a screenshot of the page you are on, without pointing at anything, when your support team's agreement allows screenshots. The option is in the window that explains Spotlight and while picking a spot.
* Support can now see the screenshot on their Support session page, with a View screenshot button, while access is open.
* FixHub shows a camera badge on reports that include a screenshot.

= 2.5.0 =
* A cleaner look for the access screen. Your agreement is now a clear checklist, your choices are highlighted softly instead of with a coloured edge, and buttons and fields have one consistent size.
* The access history marks events with a small dot instead of a coloured stripe.
* "Back" is now a proper button.

= 2.4.0 =
* Screenshots in Spotlight reports, only when your support team's agreement allows it. You see the screenshot first, can mark the problem with an arrow, box or pen, and can cover any part of it; password and payment fields are covered for you. It stays on your site, support can open it only while access is open, and it is deleted when access ends.

= 2.3.0 =
* Your support team can choose what Fixpass offers you: what support may do on your site, whether you can see, download or delete the access history, and whether you can disconnect. Your agreement card lists any limits, and options that are not offered are not shown.
* Optional owner emails when support logs in or extends access, and a summary when access ends. Both are off unless your support team turns them on.
* You can always end access and deactivate or delete the plugin in WordPress.

= 2.2.9 =
* The agreement note now says whether you can choose a one-time or a reusable link for each approval, or one-time links only.

= 2.2.8 =
* Your agreement with your support team now shows in Fixpass: the longest access, one entry or reusable, and whether extra time is allowed. The access options only offer what the agreement covers. Websites without an agreement work as before.

= 2.2.7 =
* “Refresh connection” now shows a spinner and then the result with the time, and does a fresh check-in straight away. Connecting, approving, declining and disconnecting also confirm what happened.

= 2.2.6 =
* Sites whose login page was moved to a custom address by another plugin can now finish connecting to the support team.

= 2.2.5 =
* If the site cannot finish its first check-in with your support team, the Fixpass screen now says why. Sites whose login page is on the www/non-www or http/https version of the same address now connect.

= 2.2.4 =
* Activity logs and the connection screen now call your support team by its own name (or “Support team”), never “Agency”. Older log entries are relabelled too.

= 2.2.3 =
* If your support team clears its business name in FixHub, the plugin goes back to showing Fixpass instead of a generic name.

= 2.2.2 =
* The footer now only shows “How secure is this?”, rewritten to match what Fixpass does today. Your support team can add a short note and switch the “Powered by Fixpass” credit off.
* The welcome tour text now matches the current connect and approval steps.

= 2.2.1 =
* Your support team can now set a subtitle that shows under its name at the top of the Fixpass screens. Without one, the website’s own title is shown.

= 2.2.0 =
* Your support team’s logo and name now appear at the top of the Fixpass screens in WordPress, not only in the menu.
* The welcome tour keeps the same height on every step, so the Next button stays put.
* Once the website is connected, “Skip tour” lets you leave the welcome tour at any step.

= 2.1.0 =
First release with a regular version number.
* Your support team can show its own logo instead of the generic icon in the WordPress menu.
* FixHub now shows whether each site runs the latest plugin, and can check a site instantly with “Check now”.
* FixHub is told when the plugin is deactivated or removed, so a disconnected site no longer looks connected.
* Wording throughout the plugin now says “support team” instead of “agency”.

= 2.0.0-prototype.25 =
Add optional Slack notifications in FixHub Account with encrypted incoming webhooks, masked settings, connection test and bounded delivery retries. Newly confirmed customer reports include the problem, selected Spotlights, exact access deadline and a session-scoped Enter WordPress link without FixHub sign-in. Preserve owner-approved limits, final-claim checks and existing manual access. No historical report backfill. Focused domain and preview checks pass; live Slack delivery and installed WordPress entry remain unverified.

= 2.0.0-prototype.24 =
Keep Spotlight enabled for eligible site owners and remove the “Spotlight is on. Turn it off” control. Ignore saved off preferences and keep Spotlight enabled for legacy disable requests. Open the problem-reporting flow directly without an enable/reload step. Preserve entitlement, owner permissions, active-session checks, consent, history retention and earlier fixes. Build and focused settings/report-form checks pass. Full real WordPress installation and session lifecycle remain unverified.

= 2.0.0-prototype.23 =
Refresh the WordPress plugin with calm neutral panels, restrained purple accents and numbered Problem, Access and Approval sections. Improve connection/status grouping, full-width access forms and readable session History; carry shared styling into onboarding and support screens. Preserve consent and access policies, manual sharing, mandatory setup, support messages and the .22 history/Spotlight fixes. Build and focused fixture/browser/package checks pass. Full real WordPress installation and session lifecycle remain unverified.

= 2.0.0-prototype.22 =
Fix Delete history leaving legacy agency-request events behind, while retaining active-session history and diagnostics. Focus each newly captured Spotlight comment field instead of the first, preserving earlier comments. Focused history-deletion and five-capture comment-focus checks pass. Actual WordPress lifecycle remains unverified.


= 2.0.0-prototype.21 =
Customer UI update: equal-height Spotlight summary and access-status cards, full-width access form, responsive stacked layout, and no Skip action in onboarding. Retain consent while editing the description; use Share manually to support; show agency connection status only. Includes grant-bound Spotlight expiry/revocation cleanup, distinct support-message colors and included Spotlight counts in History. Focused lifecycle/render/package checks and desktop/mobile-width browser layout checks passed. Actual WordPress lifecycle remains unverified.


= 2.0.0-prototype.20 =
Simplify connection status on the main page and onboarding: show only the agency connection status, removing the separate license status badge. Licensing checks and setup requirements remain enforced. Includes the pending .18 Spotlight fix and .19 History improvements. Local build; not published.


= 2.0.0-prototype.19 =
History: distinguish support messages with a purple theme-aware background, border and text. Record the number of Spotlights included with each successfully shared access grant, including zero, for both manual sharing and agency reports. Retain counts after access ends and deduplicate delivery retries. Existing history without recorded counts is not guessed. Includes the .18 Spotlight session-isolation fix. Local build; not published. Focused message/count/lifecycle checks pass; live WordPress browser validation remains outstanding.


= 2.0.0-prototype.18 =
Fix stale Spotlights after access ends: bind shared selections and sent highlight links to their exact access grant; hide them after expiry or revocation and prevent reuse in later access. Consume setup selection URLs once and clear the open page when access ends. Preserve stored report history and fresh unsent drafts. Legacy sent highlights without a grant mapping are hidden. Focused lifecycle checks pass; live WordPress browser lifecycle remains unverified. Local release prepared, not published.


= 2.0.0-prototype.17 =
Support messages (WordPress only): plain text up to 2,000 characters, saved to the authenticated access grant with agency/support identity and timestamp. Messages survive support account deletion, follow local activity retention/clear rules, and export safely in CSV. Leave/end prompts offer Save, explicit Skip and Cancel when this grant has no message; failures retain drafts. FixHub cannot read or author these local messages and discloses that boundary before ending access. Message bodies remain in the customer WordPress database; the existing bounded event sync sends only the event name, never message text. Copy access link creates a fresh single-use 60-second fragment-secret launch URL beside Enter WordPress, with a selectable fallback if clipboard permission fails. Another launch can invalidate an earlier link. Local build only; not published. Focused adapter/interface checks pass; live WordPress browser lifecycle remains unverified.


= 2.0.0-prototype.16 =
* Recover removed websites using a fresh reviewed agency code despite an obsolete saved credential.
* Keep active installations protected; expose recovery controls when verification fails and remove ineffective management toggles during required setup.

= 2.0.0-prototype.15 =
* Owner-selected one-time/reusable access, default-on bounded extensions and exact policy retries.
* Authenticated WordPress acknowledgement before completing hosted +1/+24 hour extensions; expired grants stay ended.
* Explicit agency identity with Agency fallback, grouped history and responsive single-page owner layout.
* Individual/bulk website removal, retained archive by default, separately confirmed irreversible portal-data purge.
* Focused fixture/DOM/package checks; actual WordPress browser lifecycle remains unverified.

= 2.0.0-prototype.14 =
* Agency profile now supports a saved agency name. Connected customer websites show it instead of the default email at their next sync; sign-in email remains unchanged.


= 2.0.0-prototype.13 =
* Complete FixHub agency workspace: Overview, compact searchable/grouped/favourite website directory, central request inbox/details, tabbed site workspaces and real interactive reports.
* Separate New / In progress / Waiting for client / Resolved workflow from expiring single-use WordPress access, with retained transition history.
* Bounded sanitized grant-mapped session activity synchronization with cursor retries and honest partial-history states. Existing billing and private downloads preserved.


= 2.0.0-prototype.12 =
* Deliver customer reports and up to five cross-page Spotlights to the exact connected, licensed agency after explicit owner approval; retain manual sharing.
* Plugin-style portal report cards, safe original highlight links, diagnostics and owner-approved single-use access.
* Remove automatic deletion choice; newly created access never uninstalls Fixpass. Retry-safe delivery retains drafts on failure.

= 2.0.0-prototype.11 =
* Collect up to five Spotlights across site pages in one tab, browse normally, review notes and remove spots before access setup. Drafts survive navigation and reloads for up to two hours.

= 2.0.0-prototype.10 =
* Mandatory code-only agency connection first in onboarding. Server-side feature lock, including Spotlight; local ending and disconnect remain available offline. Portal test accounts and sites reset for fresh testing.

= 2.0.0-prototype.7 =
* WordPress agency/client-site workspace. Licensing is separate from owner consent.
* One-use connection codes; locally approved finite support requests; one entry per approval.
* Scoped end/disconnect, stale contact status, independent local expiry/cleanup. No automatic plugin deletion.
* Preserves existing accounts, keys, annual prices and historical private packages.
* Local build only. Real WordPress lifecycle remains unverified.

= 2.0.0-prototype.6 =
* Annual plans: up to 10 websites for USD $49/year or 500 for USD $99/year. Free Pro plan removed.
* Existing legacy terms retain their recorded expiry; unused settled time becomes credit on an explicit switch.
* Manual account license activation and safety cleanup preserved.

= 2.0.0-prototype.5 =
* Activate and verify an account license key in WordPress. Invalid or expired licenses block new work; safety cleanup remains available.

= 2.0.0-prototype.4 =
* Persistent account license with confirmed security reset, browser account approval, and authenticated generic plugin library.

= 2.0.0-prototype.3 =
* Built-in hosted test licensing endpoint and owner-confirmed setup in WordPress. No wp-config.php edits or global environment changes. Existing configured test installations remain supported.

= 2.0.0-prototype.2 =
* Hosted test accounts, secure sessions, transactional Cloudflare storage, separate public pricing website and HTTPS staging adapter.

= 2.0.0-prototype.1 =
* Local-only Pro prototype: server-side licensing, simulated checkout, immediate plan replacement and unused-time credit.
* Opt-in local WordPress license adapter; no production payments or automatic updates. Real WordPress integration remains unverified.

= 1.1.0 =
* New: let support extend access themselves. Optional, off by default: support can add 1 or 24 hours at a time from their Support session page, up to a limit you set (1 week, 2 weeks or 30 days from now, or a specific date). You are emailed each time only if your support team's agreement turns that on, and support stays logged in.
* New: the access history now says who did what (you, support or Fixpass), in plain words. Access given, extended and ended stand out with colour; what support did is shown in smaller text between them. The CSV has a "Who" column.
* Fix: Fixpass's own screens no longer clutter the history with lines like "Saved data through the REST API".

= 1.0.3 =
* New: Access history on the Fixpass page: when access was given, extended and ended, when support logged in and out, and what support did. Download it (CSV), delete it, and choose to keep it for 30, 90 or 365 days.
* New: the Spotlight button keeps pulsing on your site, with a hint beside it, after you choose "Show the problem, then give access".
* New: the Fixpass page checks for support logging in every few seconds, and as soon as you return to the tab.
* Change: the login link choice and the delete option are always visible, and shown before the Give access button.
* Change: "Remove Fixpass when access ends" is now "Delete Fixpass when access ends", and says that the access history is deleted with it.
* Change: Skip the tour now hides the tour for good (take it again any time from the page).
* Change: shorter time estimates on the two start buttons.

= 1.0.2 =
* Fix: in troubleshooting mode, Fixpass switched itself off for support (it showed as inactive and couldn't be activated) when the plugin folder wasn't called "fixpass", for example after installing GitHub's "Download ZIP". Fixpass now always stays on, whatever its folder is called.
* Change: support can no longer install or delete themes, which could break the site for visitors. To try a default theme, support uses troubleshooting mode, which only changes their own browser.

= 1.0.1 =
* New: the Fixpass page now starts with two big choices, "Show the problem, then give access" (recommended) and "Just give access". The first walks you through Spotlight, shows your spots, and then gives access.
* New: the welcome tour starts with Spotlight and explains the two choices.
* Fix: the Fixpass page stayed on "Loading…" on WordPress 6.5, which has no JSX runtime script. It is now bundled.
* Fix: a clear message instead of an endless "Loading…" if the plugin's built files are missing (for example after installing GitHub's "Download ZIP").

= 1.0.0 =
* First release: support access with reusable or one-time links, Spotlight, copyable access details, live status, Support session with site details, debugging tools and troubleshooting mode, welcome tour.
