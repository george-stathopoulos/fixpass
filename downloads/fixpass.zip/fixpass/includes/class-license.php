<?php
/**
 * Owner-enabled hosted test adapter. Unsigned HTTPS responses are suitable only for
 * disposable test sites using the fixed development service below. This is not a production license lease.
 *
 * @package Fixpass
 */
defined( 'ABSPATH' ) || exit;

final class Fixpass_License {
	const OPTION = 'fixpass_prototype_license';
	const SERVICE = 'https://fixpass-pro.george-stathopoulos.workers.dev';
	const TEST_OPTION = 'fixpass_prototype_testing';

	public static function enabled() { return true; }

	public static function init() {
		add_action( 'admin_init', array( __CLASS__, 'legacy_redirect' ) );
		add_action( 'admin_post_fixpass_prototype_license', array( __CLASS__, 'handle' ) );
		add_action( 'admin_notices', array( __CLASS__, 'notice' ) );
		add_action( 'admin_init', array( __CLASS__, 'maybe_refresh' ) );
	}

	public static function owner() {
		return current_user_can( Fixpass_Access::CAP ) && ! Fixpass_Access::current_grant_id();
	}

	public static function menu() {
		if ( self::owner() ) {
			add_submenu_page( Fixpass_Admin::SLUG, 'Pro license', 'Pro license', Fixpass_Access::CAP, 'fixpass-prototype-license', array( __CLASS__, 'render' ) );
		}
	}

	private static function url() {
		return untrailingslashit( home_url( '/' ) );
	}

	public static function request( $path, $data ) {
		// Fixed HTTPS test origin only; TLS verification required. No request-supplied URL.
		$response = wp_remote_post( self::SERVICE . '/v1/' . $path, array(
			'timeout' => 5, 'redirection' => 0, 'sslverify' => true,
			'headers' => array( 'Content-Type' => 'application/json' ),
			'body' => wp_json_encode( $data ),
		) );
		if ( is_wp_error( $response ) ) {
			return new WP_Error( 'fixpass_demo_unreachable', 'The hosted licensing service could not be reached. Check the runtime networking notes.' );
		}
		$body = json_decode( wp_remote_retrieve_body( $response ), true );
		if ( 200 !== wp_remote_retrieve_response_code( $response ) || ! is_array( $body ) ) {
			return new WP_Error( 'fixpass_demo_rejected', isset( $body['message'] ) ? $body['message'] : 'The demo licensing service rejected this request.', wp_remote_retrieve_response_code( $response ) );
		}
		return $body;
	}

	public static function maybe_refresh() {
		if ( ! self::enabled() || ! self::owner() ) { return; }
		$state = get_option( self::OPTION, array() );
		if ( ! empty( $state['credential'] ) && (int) ( $state['checked'] ?? 0 ) < time() - 45 ) { self::refresh(); }
	}

	private static function refresh() {
		$state = get_option( self::OPTION, array() );
		if ( empty( $state['credential'] ) || ( $state['url'] ?? '' ) !== self::url() ) {
			return new WP_Error( 'fixpass_demo_connect', 'Connect this exact WordPress installation first.' );
		}
		$result = self::request( 'licenses/verify', array( 'credential' => $state['credential'], 'url' => self::url() ) );
		if ( ! is_wp_error( $result ) ) { $state['account'] = $result['account'] ?? ( $state['account'] ?? '' ); $state['plan'] = $result['plan'] ?? ( $state['plan'] ?? '' ); }
		$state['checked'] = time();
		$state['active'] = ! is_wp_error( $result ) && ! empty( $result['active'] );
		$state['until'] = $state['active'] ? min( time() + 60, (int) floor( $result['expires'] / 1000 ) ) : 0;
		update_option( self::OPTION, $state, false );
		return $result;
	}

	/** Verify only when licensed work is requested. Safety cleanup never calls this guard. */
	public static function guard() {
		$state = get_option( self::OPTION, array() );
		if ( ! empty( $state['credential'] ) && ( $state['url'] ?? '' ) === self::url() && (int) ( $state['until'] ?? 0 ) <= time() && (int) ( $state['checked'] ?? 0 ) < time() - 5 ) { self::refresh(); $state = get_option( self::OPTION, array() ); }
		Fixpass_Agency::sync();
		if ( self::ready() && ! empty( $state['active'] ) && ( $state['url'] ?? '' ) === self::url() && (int) ( $state['until'] ?? 0 ) > time() ) { return true; }
		return new WP_Error( 'fixpass_license_required', 'Connect your support team with a reviewed code and active plan to use Fixpass. Ending access, expiry, cleanup and exports remain available.', array( 'status' => 403 ) );
	}

	/** Cached readiness: no outbound calls during toolbar rendering. */
	public static function ready() {
		$s = get_option( Fixpass_Agency::OPTION, array() );
		return self::status()['active'] && ! empty( $s['connected'] ) && empty( $s['error'] ) && ( $s['url'] ?? '' ) === self::url() && (int) ( $s['contact'] ?? 0 ) > time() - 60;
	}
	public static function legacy_redirect() {
		if ( self::owner() && in_array( $_GET['page'] ?? '', array( 'fixpass-prototype-license', 'fixpass-agency' ), true ) ) { wp_safe_redirect( admin_url( 'admin.php?page=fixpass&setup=1' ) ); exit; }
	}
	public static function status() {
		$s = get_option( self::OPTION, array() );
		return array( 'active' => ! empty( $s['active'] ) && ( $s['url'] ?? '' ) === self::url() && (int) ( $s['until'] ?? 0 ) > time(), 'configured' => ! empty( $s['credential'] ), 'account' => Fixpass_Agency::display_name(), 'url' => self::url() );
	}
	public static function action( $action, $key = '' ) {
		if ( ! self::owner() ) { return new WP_Error( 'forbidden', 'Owner access required.', array( 'status' => 403 ) ); }
		$result = true;
		if ( 'connect' === $action ) {
			return new WP_Error( 'code_required', 'Use a reviewed connection code.', array( 'status' => 403 ) );
		} elseif ( 'disconnect' === $action ) {
			Fixpass_Agency::disconnect();
			self::cancel_pairing();
			$state = get_option( self::OPTION, array() );
			if ( ! empty( $state['credential'] ) ) { self::request( 'licenses/disconnect', array( 'credential' => $state['credential'], 'url' => self::url() ) ); }
			delete_option( self::OPTION ); // Local disconnect always works, even offline.
			delete_option( self::TEST_OPTION );
			delete_option( 'fixpass_pairing' );
		} elseif ( 'refresh' === $action ) { $result = self::refresh(); Fixpass_Agency::sync( true ); }
		else { $result = new WP_Error( 'fixpass_demo_action', 'Unknown action.' ); }
		return is_wp_error( $result ) ? $result : self::status();
	}
	public static function handle() {
		if ( ! self::owner() ) { wp_die( 'Owner access required.' ); }
		check_admin_referer( 'fixpass_prototype_license' );
		$result = self::action( sanitize_key( wp_unslash( $_POST['license_action'] ?? '' ) ), wp_unslash( $_POST['license_key'] ?? '' ) );
		if ( is_wp_error( $result ) ) { wp_die( esc_html( $result->get_error_message() ) ); }
		wp_safe_redirect( admin_url( 'admin.php?page=fixpass' ) ); exit;
	}

	private static function cancel_pairing() {
		$pair = get_option( 'fixpass_pairing', array() );
		if ( ! empty( $pair['secret'] ) && ( $pair['url'] ?? '' ) === self::url() ) { self::request( 'pairing/cancel', array( 'code' => $pair['code'], 'secret' => $pair['secret'], 'url' => self::url() ) ); }
		delete_option( 'fixpass_pairing' );
	}

	public static function notice() {
		if ( ! self::owner() ) { return; }
		$state = get_option( self::OPTION, array() );
		if ( ! empty( $state['active'] ) && ( $state['url'] ?? '' ) === self::url() && (int) ( $state['until'] ?? 0 ) > time() ) { return; }
		echo '<div class="notice notice-warning"><p>FixPass Pro needs an active account plan. <a href="' . esc_url( admin_url( 'admin.php?page=fixpass&setup=1' ) ) . '">Connect your support team or refresh verification</a>. Ending access and safety cleanup remain available.</p></div>';
	}

	public static function render() { self::legacy_redirect(); }
}
