<?php
/**
 * Emails to the site owner about support access. The support team decides in the agreement level
 * whether the owner gets them, so a team that informs clients through its help desk is not
 * doubled up by automatic mail.
 *
 * @package Fixpass
 */

defined( 'ABSPATH' ) || exit;

/**
 * Owner emails.
 */
class Fixpass_Owner_Mail {

	/**
	 * Actions worth naming in the summary because they change what the site can do.
	 *
	 * @var string[]
	 */
	const SENSITIVE = array( 'plugin_installed', 'plugin_activated', 'plugin_deactivated', 'plugin_deleted', 'plugin_updated', 'core_updated', 'theme_switched' );

	/**
	 * Whether an email kind is on.
	 *
	 * A site with no agreement keeps the login and extension emails it always had and gets no
	 * summary. A site with an agreement follows the level.
	 *
	 * @param string $kind 'login' (support logs in or extends access) or 'summary' (access ended).
	 * @return bool
	 */
	public static function enabled( $kind ) {
		$agreement = Fixpass_Agency::agreement();
		if ( ! $agreement ) {
			return 'login' === $kind;
		}
		return ! empty( $agreement['login' === $kind ? 'owner_login_email' : 'owner_summary_email'] );
	}

	/**
	 * Plain-language line for a logged change.
	 *
	 * @param array $row Log row.
	 * @return string
	 */
	private static function line( array $row ) {
		$name = isset( $row['details']['name'] ) ? (string) $row['details']['name'] : (string) $row['object'];
		$name = '' !== $name ? ' ' . wp_strip_all_tags( $name ) : '';
		$map  = array(
			'plugin_installed'   => __( 'Installed plugin', 'fixpass' ),
			'plugin_activated'   => __( 'Activated plugin', 'fixpass' ),
			'plugin_deactivated' => __( 'Deactivated plugin', 'fixpass' ),
			'plugin_deleted'     => __( 'Deleted plugin', 'fixpass' ),
			'plugin_updated'     => __( 'Updated plugin', 'fixpass' ),
			'core_updated'       => __( 'Updated WordPress', 'fixpass' ),
			'theme_switched'     => __( 'Switched theme', 'fixpass' ),
		);
		return ( $map[ $row['action'] ] ?? __( 'Changed', 'fixpass' ) ) . $name;
	}

	/**
	 * Tell the owner what happened during an access that has just ended.
	 *
	 * @param int    $grant_id Access.
	 * @param string $reason   How it ended.
	 */
	public static function summary( $grant_id, $reason ) {
		if ( ! self::enabled( 'summary' ) ) {
			return;
		}
		$rows    = Fixpass_Monitor::query( array( 'grant_id' => (int) $grant_id, 'limit' => 500 ) );
		$logins  = 0;
		$changes = array();
		foreach ( array_reverse( $rows ) as $row ) {
			if ( 'support_login' === $row['action'] ) {
				++$logins;
			}
			if ( 'change' === $row['type'] && in_array( $row['action'], self::SENSITIVE, true ) ) {
				$changes[] = '- ' . self::line( $row );
			}
		}
		$ended = array(
			'expired'       => __( 'Access ended because the time ran out.', 'fixpass' ),
			'support_ended' => __( 'Support ended the access.', 'fixpass' ),
		);
		$body  = ( $ended[ $reason ] ?? __( 'Access ended.', 'fixpass' ) ) . "\n\n";
		/* translators: %d: number of logins */
		$body .= sprintf( _n( 'Support logged in %d time.', 'Support logged in %d times.', $logins, 'fixpass' ), $logins ) . "\n\n";
		if ( $changes ) {
			$body .= __( 'Changes that affect how your site works:', 'fixpass' ) . "\n" . implode( "\n", array_slice( $changes, 0, 30 ) ) . "\n";
			if ( count( $changes ) > 30 ) {
				/* translators: %d: number of further changes */
				$body .= sprintf( __( 'and %d more.', 'fixpass' ), count( $changes ) - 30 ) . "\n";
			}
		} else {
			$body .= __( 'Support made no changes that affect how your site works.', 'fixpass' ) . "\n";
		}
		$body .= "\n" . sprintf(
			/* translators: %s: URL */
			__( 'The full history is in Fixpass: %s', 'fixpass' ),
			admin_url( 'admin.php?page=' . Fixpass_Admin::SLUG )
		);
		wp_mail(
			Fixpass_Settings::notify_email(),
			/* translators: %s: site name */
			sprintf( __( '[%s] Support session summary', 'fixpass' ), wp_specialchars_decode( get_bloginfo( 'name' ), ENT_QUOTES ) ),
			$body
		);
	}
}
