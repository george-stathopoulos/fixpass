<?php
/**
 * Messages from support, and whether support is logged in, for the site owner.
 *
 * Messages are saved on this site by the support session. They are always readable by the owner,
 * whatever the agreement says about the access history.
 *
 * @package Fixpass
 */

defined( 'ABSPATH' ) || exit;

/**
 * The owner's inbox and the toolbar items that point to it.
 */
final class Fixpass_Inbox {

	const SEEN = 'fixpass_messages_seen';

	/**
	 * Hooks.
	 */
	public static function init() {
		add_action( 'admin_bar_menu', array( __CLASS__, 'admin_bar' ), 98 );
		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'assets' ) );
		add_action( 'wp_enqueue_scripts', array( __CLASS__, 'assets' ) );
		add_filter( 'heartbeat_received', array( __CLASS__, 'heartbeat' ), 10, 2 );
	}

	/**
	 * Heartbeat: tell an open page how many messages and requests wait, so the toolbar follows
	 * without a reload (the same way agreement changes show up while the page is open).
	 *
	 * @param array $response Response.
	 * @param array $data     Data from the browser.
	 * @return array
	 */
	public static function heartbeat( $response, $data ) {
		if ( empty( $data['fixpass_inbox'] ) || ! self::is_owner() ) { return $response; }
		global $wpdb;
		$seen = (int) get_user_meta( get_current_user_id(), self::SEEN, true );
		$response['fixpass_inbox'] = array(
			'messages' => (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM %i WHERE action = 'support_message' AND grant_id > 0 AND id > %d", Fixpass_DB::table( 'log' ), $seen ) ), // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			'requests' => self::pending_requests(),
			'presence' => self::presence_state(),
		);
		return $response;
	}

	/**
	 * Whether this site is set up with a support team and an active plan. The toolbar only needs that:
	 * Fixpass_License::ready() also needs a Hub check-in under a minute old and no sync error, so it hid the
	 * toolbar (messages, requests, "support has finished") whenever the Hub was briefly unreachable.
	 *
	 * @return bool
	 */
	public static function connected() {
		$state = get_option( Fixpass_Agency::OPTION, array() );
		return Fixpass_License::status()['active'] && ! empty( $state['connected'] ) && ( $state['url'] ?? '' ) === untrailingslashit( home_url( '/' ) );
	}

	/**
	 * Only the site owner side: administrators of the site, never the support login.
	 *
	 * @return bool
	 */
	private static function is_owner() {
		return is_user_logged_in() && current_user_can( Fixpass_Access::CAP ) && ! Fixpass_Access::current_grant_id();
	}

	/**
	 * Latest messages from support, newest first.
	 *
	 * @param int $limit How many.
	 * @return array[] id, by, text, time (MySQL), unread.
	 */
	public static function messages( $limit = 50 ) {
		global $wpdb;
		$seen = (int) get_user_meta( get_current_user_id(), self::SEEN, true );
		$rows = $wpdb->get_results( $wpdb->prepare( "SELECT id, grant_id, details, created_at FROM %i WHERE action = 'support_message' AND grant_id > 0 ORDER BY id DESC LIMIT %d", Fixpass_DB::table( 'log' ), max( 1, (int) $limit ) ), ARRAY_A ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$out  = array();
		foreach ( (array) $rows as $row ) {
			$d = json_decode( (string) $row['details'], true );
			if ( ! is_array( $d ) || ! isset( $d['message'] ) ) { continue; }
			// Once read, a message goes away with the access it was sent in; unread ones stay until seen.
			$unread = (int) $row['id'] > $seen;
			if ( ! $unread && ! Fixpass_Access::is_active( Fixpass_Access::get( (int) $row['grant_id'] ) ) ) { continue; }
			$out[] = array(
				'id'     => (int) $row['id'],
				'session' => Fixpass_Agency::number( (int) $row['grant_id'] ),
				'by'     => (string) ( $d['by'] ?? __( 'Support', 'fixpass' ) ),
				'text'   => (string) $d['message'],
				'time'   => $row['created_at'],
				'unread' => $unread,
			);
		}
		return $out;
	}

	/**
	 * Mark everything up to now as read for the current owner.
	 */
	public static function mark_read() {
		global $wpdb;
		$latest = (int) $wpdb->get_var( $wpdb->prepare( "SELECT MAX(id) FROM %i WHERE action = 'support_message' AND grant_id > 0", Fixpass_DB::table( 'log' ) ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		if ( $latest ) { update_user_meta( get_current_user_id(), self::SEEN, $latest ); }
	}

	/**
	 * How many access requests from the support team wait for the owner's decision (as last synced).
	 * Reads the saved state only, so the toolbar and menu never wait on the network.
	 *
	 * @return int
	 */
	public static function pending_requests() {
		$state = get_option( Fixpass_Agency::OPTION, array() );
		if ( empty( $state['connected'] ) || ( $state['url'] ?? '' ) !== untrailingslashit( home_url( '/' ) ) || Fixpass_Access::active() ) { return 0; }
		return count( array_filter( (array) ( $state['requests'] ?? array() ), static function ( $r ) { return 'pending' === ( $r['status'] ?? '' ); } ) );
	}

	/**
	 * Is a support user logged in right now? Needs open access and a live login session.
	 *
	 * @return bool|null null when no access is open.
	 */
	public static function support_presence() {
		$grant = Fixpass_Access::active();
		if ( ! $grant || empty( $grant['user_id'] ) ) { return null; }
		return count( WP_Session_Tokens::get_instance( (int) $grant['user_id'] )->get_all() ) > 0;
	}

	const DONE_SEEN = 'fixpass_done_seen';

	/**
	 * The support item for the toolbar: live, idle (access open, nobody in), or done (support ended
	 * the access themselves and the owner has not opened Fixpass since).
	 *
	 * @return string live|idle|done|'' (nothing to show).
	 */
	public static function presence_state() {
		$presence = self::support_presence();
		if ( null !== $presence ) { return $presence ? 'live' : 'idle'; }
		$latest = Fixpass_Access::all( false, 1 );
		$g      = $latest ? $latest[0] : null;
		if ( $g && 'support_revoked' === (string) $g['status'] && ! empty( $g['revoked_at'] ) && (int) $g['id'] > (int) get_user_meta( get_current_user_id(), self::DONE_SEEN, true ) && strtotime( $g['revoked_at'] . ' UTC' ) > time() - DAY_IN_SECONDS ) {
			return 'done';
		}
		return '';
	}

	/**
	 * The owner opened Fixpass: the "support is done" notice has been seen.
	 */
	public static function mark_done_seen() {
		$latest = Fixpass_Access::all( false, 1 );
		if ( $latest ) { update_user_meta( get_current_user_id(), self::DONE_SEEN, (int) $latest[0]['id'] ); }
	}

	/**
	 * Label and hover text for each support item state.
	 *
	 * @return array
	 */
	private static function presence_labels() {
		return array(
			'live' => array( __( 'Support is logged in', 'fixpass' ), __( 'Your support team is logged in to your site right now', 'fixpass' ) ),
			'idle' => array( __( 'Support access open', 'fixpass' ), __( 'Your support team has access, but is not logged in right now', 'fixpass' ) ),
			'done' => array( __( 'Support has finished', 'fixpass' ), __( 'Your support team ended their access: they are done working on your site', 'fixpass' ) ),
		);
	}

	/**
	 * Toolbar: envelope with the unread count, and the support presence item.
	 *
	 * @param WP_Admin_Bar $bar Bar.
	 */
	public static function admin_bar( $bar ) {
		if ( ! self::is_owner() || ! self::connected() ) { return; }
		$page = admin_url( 'admin.php?page=' . Fixpass_Admin::SLUG );
		$list = self::messages( 3 );
		$new  = count( array_filter( $list, static function ( $m ) { return $m['unread']; } ) );
		if ( $new ) {
			global $wpdb;
			$seen = (int) get_user_meta( get_current_user_id(), self::SEEN, true );
			$new  = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM %i WHERE action = 'support_message' AND grant_id > 0 AND id > %d", Fixpass_DB::table( 'log' ), $seen ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			$bar->add_node(
				array(
					'id'     => 'fixpass-messages',
					'parent' => 'top-secondary',
					'title'  => '<svg class="fxp-ab-icon" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true" focusable="false"><rect x="3" y="5" width="18" height="14" rx="2"/><path d="M3 7l9 6 9-6"/></svg><span class="ab-label">' . esc_html__( 'Message from support', 'fixpass' ) . '</span> <span class="fxp-ab-badge">' . esc_html( number_format_i18n( min( $new, 99 ) ) ) . ( $new > 99 ? '+' : '' ) . '</span>',
					'href'   => $page . '#fixpass-messages',
					'meta'   => array( 'class' => 'fxp-ab-messages', 'title' => __( 'Your support team sent you a message', 'fixpass' ) ),
				)
			);
			foreach ( $list as $i => $m ) {
				$bar->add_node(
					array(
						'id'     => 'fixpass-messages-' . (int) $m['id'],
						'parent' => 'fixpass-messages',
						'title'  => '<strong>' . esc_html( $m['by'] ) . '</strong><br>' . esc_html( wp_html_excerpt( $m['text'], 80, '…' ) ),
						'href'   => $page . '#fixpass-messages',
					)
				);
			}
			$bar->add_node(
				array(
					'id'     => 'fixpass-messages-all',
					'parent' => 'fixpass-messages',
					'title'  => esc_html__( 'Open all messages', 'fixpass' ),
					'href'   => $page . '#fixpass-messages',
				)
			);
		}
		$asked = self::pending_requests();
		if ( $asked ) {
			$bar->add_node(
				array(
					'id'     => 'fixpass-request',
					'parent' => 'top-secondary',
					'title'  => '<svg class="fxp-ab-icon" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true" focusable="false"><circle cx="8" cy="15" r="4"/><path d="M10.8 12.2L20 3M16 7l3 3"/></svg><span class="ab-label">' . esc_html__( 'Support is asking for access', 'fixpass' ) . '</span> <span class="fxp-ab-badge">' . esc_html( number_format_i18n( min( $asked, 99 ) ) ) . '</span>',
					'href'   => $page,
					'meta'   => array( 'class' => 'fxp-ab-messages', 'title' => __( 'Your support team asked for access to your site. Review it in Fixpass.', 'fixpass' ) ),
				)
			);
		}
		$state = self::presence_state();
		if ( '' !== $state ) {
			$labels = self::presence_labels();
			$bar->add_node(
				array(
					'id'     => 'fixpass-presence',
					'parent' => 'top-secondary',
					'title'  => '<span class="fxp-ab-dot' . ( 'live' === $state ? ' is-live' : '' ) . ( 'done' === $state ? ' is-done' : '' ) . '" aria-hidden="true"></span><span class="ab-label">' . esc_html( $labels[ $state ][0] ) . '</span>',
					'href'   => $page,
					'meta'   => array(
						'class' => 'live' === $state ? 'fxp-ab-live' : 'fxp-ab-idle',
						'title' => $labels[ $state ][1],
					),
				)
			);
		}
	}

	/**
	 * Toolbar styles, only when the toolbar shows.
	 */
	public static function assets() {
		if ( ! is_admin_bar_showing() || ! self::is_owner() ) { return; }
		wp_enqueue_style( 'fixpass-topbar', FIXPASS_URL . 'assets/topbar.css', array(), (string) filemtime( FIXPASS_DIR . 'assets/topbar.css' ) );
		wp_enqueue_script( 'fixpass-topbar', FIXPASS_URL . 'assets/topbar.js', array( 'heartbeat' ), (string) filemtime( FIXPASS_DIR . 'assets/topbar.js' ), true );
		wp_localize_script(
			'fixpass-topbar',
			'fixpassInbox',
			array(
				'page'     => admin_url( 'admin.php?page=' . Fixpass_Admin::SLUG ),
				'messages' => __( 'Message from support', 'fixpass' ),
				'requests' => __( 'Support is asking for access', 'fixpass' ),
				'presence' => self::presence_labels(),
			)
		);
	}
}
