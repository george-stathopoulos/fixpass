<?php
/**
 * Spotlight: mark the exact spot of a problem.
 *
 * @package Fixpass
 */

defined( 'ABSPATH' ) || exit;

/**
 * "Report a problem" in the admin bar, on the front end and in wp-admin. The site owner clicks
 * the broken part of a page (or drags a box around it), up to 5 spots, with a note each. The
 * spots then go into the message for support (Fixpass_Share): each with its page, a link
 * that opens the page with the spot highlighted, the screen size and browser, and the JavaScript
 * errors and failed requests on that page.
 */
final class Fixpass_Spotlight {

	const OPTION = 'fixpass_pins';
	const KEEP   = 90; // Days a spot stays highlightable.
	const SHOT = 'fixpass_shot_'; // Option name prefix; not autoloaded and never reachable by URL.
	const SHOT_KEEP = 30; // Days a screenshot is kept at most; it is also deleted when the access it was sent with ends.
	const SHOT_MAX  = 700000; // Bytes of base64 JPEG per screenshot.

	/**
	 * The toolbar icon: a spotlight casting its beam (static markup, nothing from users).
	 */
	const ICON = '<svg class="fxp-ab-icon" width="18" height="18" viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M15 3l6 3.5-2.5 4.3-6-3.5z" fill="currentColor"/><path d="M13.6 9.2L4 21h10.5l2.6-9.8z" fill="currentColor" opacity=".45"/><circle cx="18.6" cy="3.6" r="1.2" fill="currentColor"/></svg>';

	/**
	 * Register hooks.
	 */
	public static function init() {
		add_action( 'admin_bar_menu', array( __CLASS__, 'admin_bar' ), 99 );
		add_action( 'wp_head', array( __CLASS__, 'collector' ), 1 );
		add_action( 'admin_head', array( __CLASS__, 'collector' ), 1 );
		add_action( 'wp_enqueue_scripts', array( __CLASS__, 'assets' ) );
		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'assets' ) );
		add_action( 'rest_api_init', array( __CLASS__, 'routes' ) );
		add_action( Fixpass_Plugin::PRUNE, array( __CLASS__, 'prune_shots' ) );
	}

	/**
	 * Whether the support team's agreement lets the client add a screenshot to a report.
	 * Off unless a connected team's agreement level turns it on.
	 *
	 * @return bool
	 */
	public static function shots_allowed() {
		$ag = Fixpass_Agency::agreement();
		return ! empty( $ag['screenshots'] );
	}

	/**
	 * Whether the current person can use Spotlight: an eligible site administrator
	 * (not a support account), subject to the connection and active-session checks.
	 *
	 * @return bool
	 */
	public static function available() {
		$on = ! empty( ( (array) Fixpass_Settings::get( 'spotlight' ) )['enabled'] );
		/**
		 * Filters whether Spotlight ("Spotlight a problem" in the toolbar) is offered.
		 *
		 * @param bool $on On.
		 */
		return (bool) apply_filters( 'fixpass_spotlight', $on )
			&& Fixpass_License::ready()
			&& is_user_logged_in()
			&& current_user_can( Fixpass_Access::CAP )
			&& ! Fixpass_Access::current_grant_id()
			// While support has access, the status is all the owner needs.
			&& ! Fixpass_Access::active();
	}

	/**
	 * Admin bar button.
	 *
	 * @param WP_Admin_Bar $bar Bar.
	 */
	public static function admin_bar( $bar ) {
		if ( ! self::available() ) {
			return;
		}
		$bar->add_node(
			array(
				'id'     => 'fixpass-spotlight',
				'parent' => 'top-secondary',
				'title'  => self::ICON . '<span class="ab-label">' . esc_html__( 'Spotlight a problem', 'fixpass' ) . '</span>',
				'href'   => '#fixpass-spotlight',
				'meta'   => array( 'title' => __( 'Click the part of this page that has the problem, and send it to your support', 'fixpass' ) ),
			)
		);
	}

	/**
	 * Load the reporting overlay (for those who can report) or the highlighter (a link from a
	 * report, with ?fxp_spot=).
	 */
	public static function assets() {
		if ( ! Fixpass_License::ready() ) { return; }
		$pin = isset( $_GET['fxp_spot'] ) ? sanitize_key( wp_unslash( $_GET['fxp_spot'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only: highlights a spot.
		if ( ! self::available() && '' === $pin ) {
			return;
		}
		// Versioned by file time, so an update never leaves an old copy in the browser's cache.
		wp_enqueue_script( 'fixpass-spotlight', FIXPASS_URL . 'assets/spotlight.js', array(), (string) filemtime( FIXPASS_DIR . 'assets/spotlight.js' ), true );
		wp_enqueue_style( 'fixpass-spotlight', FIXPASS_URL . 'assets/spotlight.css', array(), (string) filemtime( FIXPASS_DIR . 'assets/spotlight.css' ) );
		wp_localize_script(
			'fixpass-spotlight',
			'fixpassSpotlight',
			array(
				'can'       => self::available(),
				'draft'     => self::available() ? hash( 'sha256', home_url( '/' ) . '|' . get_current_blog_id() . '|' . get_current_user_id() ) : '',
				'home'      => home_url( '/' ),
				'admin'     => admin_url( '/' ),
				'pin'       => $pin,
				'api'       => esc_url_raw( rest_url( Fixpass_REST::NS . '/' ) ),
				'nonce'     => self::available() ? wp_create_nonce( 'wp_rest' ) : '',
				'back'      => self::available() ? admin_url( 'admin.php?page=' . Fixpass_Admin::SLUG . '#/?spot=' ) : '',
				'session'   => $pin && Fixpass_Access::current_grant_id() > 0 ? admin_url( 'admin.php?page=' . Fixpass_Admin::SLUG . '#/session' ) : '',
				'area'      => is_admin() ? 'admin' : 'front',
				'shots'     => self::available() && self::shots_allowed(),
				'shotLib'   => self::available() && self::shots_allowed() ? FIXPASS_URL . 'assets/vendor/html2canvas.min.js?ver=1.4.1' : '',
				'i18n'      => array(
					'pick'      => __( 'Click the part of the page that has the problem, or drag a box around it. Links are paused while Spotlight is on. Press Esc to cancel.', 'fixpass' ),
					'cancel'    => __( 'Cancel', 'fixpass' ),
					'guideHint' => __( 'Click here, then click the problem on this page', 'fixpass' ),
					'guideStop' => __( 'Hide this hint', 'fixpass' ),
					'introTitle'   => __( 'How Spotlight works', 'fixpass' ),
					'intro1'       => __( 'Click the part of the page that has the problem, or drag a box around an area.', 'fixpass' ),
					'intro2'       => __( 'Add a short note if you like. You can mark up to 5 spots across pages on this site.', 'fixpass' ),
					'intro3'       => __( 'Click Finish to continue to access setup: all your spots go with you.', 'fixpass' ),
					'introPause'   => __( 'Links pause only while capturing. Choose Browse to another page to scroll and navigate normally, then Capture here. Your draft stays in this tab for up to two hours.', 'fixpass' ),
					'introPrivacy' => __( 'Nothing on your screen is recorded. Support opens the page itself, with your spots highlighted.', 'fixpass' ),
					'introHide'    => __( 'Don’t show this again', 'fixpass' ),
					'introStart'   => __( 'Start', 'fixpass' ),
					'title'     => __( 'Spotlight this spot', 'fixpass' ),
					'what'      => __( 'Next you create a support link. Your support gets the page, the spot, your screen size and browser, and any errors on this page.', 'fixpass' ),
					'next'      => __( 'Finish', 'fixpass' ),
					'another'   => __( 'Capture another here', 'fixpass' ),
					'browse'    => __( 'Browse to another page', 'fixpass' ),
					'capture'   => __( 'Capture here', 'fixpass' ),
					'review'    => __( 'Review / edit', 'fixpass' ),
					'remove'    => __( 'Remove spotlight', 'fixpass' ),
					'discard'   => __( 'Discard all spots', 'fixpass' ),
					'storage'   => __( 'This browser cannot save your draft. Finish on this page before navigating or reloading.', 'fixpass' ),
					'label'     => __( 'What’s wrong here? (optional)', 'fixpass' ),
					'labelHint' => __( 'For example: wrong price, button does nothing', 'fixpass' ),
					/* translators: %d: number of spots */
					'count'     => __( 'Spots: %d of 5', 'fixpass' ),
					'working'   => __( 'Preparing…', 'fixpass' ),
					'failed'    => __( 'Something went wrong. Try again.', 'fixpass' ),
					'here'      => __( 'The reported spot', 'fixpass' ),
					'notFound'  => __( 'The exact element isn’t on the page any more; the box shows where it was.', 'fixpass' ),
					'pinGone'   => __( 'This highlight link has expired.', 'fixpass' ),
					'close'     => __( 'Close', 'fixpass' ),
					'shotAdd'    => __( 'Add a screenshot (optional)', 'fixpass' ),
					'shotNote'   => __( 'Stays on your site. Support can open it only while access is open.', 'fixpass' ),
					'shotRemove' => __( 'Remove screenshot', 'fixpass' ),
					'shotPrep'   => __( 'Taking the screenshot…', 'fixpass' ),
					'shotTitle'  => __( 'Check your screenshot', 'fixpass' ),
					'shotHint'   => __( 'Point at the problem with an arrow, box or pen. Use Cover for anything you do not want support to see. Password and payment fields are covered for you.', 'fixpass' ),
					'shotTools'  => __( 'Drawing tools', 'fixpass' ),
					'shotArrow'  => __( 'Arrow', 'fixpass' ),
					'shotBox'    => __( 'Box', 'fixpass' ),
					'shotPen'    => __( 'Pen', 'fixpass' ),
					'shotCover'  => __( 'Cover', 'fixpass' ),
					'shotUndo'   => __( 'Undo last mark', 'fixpass' ),
					'shotSkip'   => __( 'Skip screenshot', 'fixpass' ),
					'shotUse'    => __( 'Use this screenshot', 'fixpass' ),
					'shotFail'   => __( 'The screenshot could not be taken. You can send the report without it.', 'fixpass' ),
					'shotView'   => __( 'View screenshot', 'fixpass' ),
					'backToSession' => __( 'Back to support session', 'fixpass' ),
					'shotActual' => __( 'Actual size', 'fixpass' ),
					'shotFit'    => __( 'Fit to window', 'fixpass' ),
					'shotNewTab' => __( 'Open in new tab', 'fixpass' ),
					'shotOnly'   => __( 'Just a screenshot', 'fixpass' ),
					'shotOnlyTitle' => __( 'Screenshot of this page', 'fixpass' ),
					'introShot'  => __( 'You can also send just a screenshot of the page you are on, without pointing at anything.', 'fixpass' ),
					'shotGone'   => __( 'The screenshot is no longer available.', 'fixpass' ),
				),
			)
		);
	}

	/**
	 * REST routes.
	 */
	public static function routes() {
		$owner = static function () {
			return Fixpass_License::owner() ? Fixpass_License::guard() : false;
		};
		$routes = array(
			array( '/admin/spot', 'POST', 'create', $owner ),
			array( '/admin/spot/(?P<id>[a-z0-9]{32})', 'GET', 'read', $owner ),
			// Public on purpose: the 32-character random ID is the key, and only the spot is returned.
			array( '/spot/(?P<id>[a-z0-9]{32})', 'GET', 'spot', static function () { return Fixpass_License::guard(); } ),
			// The screenshot of a sent spot: same random ID, and only while the access it was sent with is open.
			array( '/spot/(?P<id>[a-z0-9]{32})/shot', 'GET', 'shot', static function () { return Fixpass_License::guard(); } ),
			array( '/admin/shots', 'GET', 'shots_list', $owner ),
			array( '/admin/spot/(?P<id>[a-z0-9]{32})/shot', 'GET', 'shot_owner', $owner ),
			array( '/admin/spot/(?P<id>[a-z0-9]{32})/shot', 'DELETE', 'shot_delete', $owner ),
		);
		foreach ( $routes as $r ) {
			register_rest_route(
				Fixpass_REST::NS,
				$r[0],
				array(
					'methods'             => $r[1],
					'callback'            => array( __CLASS__, $r[2] ),
					'permission_callback' => $r[3],
				)
			);
		}
	}

	/**
	 * Save picked spots (from the overlay).
	 *
	 * @param WP_REST_Request $request Request.
	 * @return array|WP_Error { id, ids }
	 */
	public static function create( WP_REST_Request $request ) {
		$license = Fixpass_License::guard();
		if ( is_wp_error( $license ) ) { return $license; }
		$params = (array) $request->get_json_params();
		$spots  = isset( $params['spots'] ) && is_array( $params['spots'] ) ? array_slice( $params['spots'], 0, 5 ) : array( $params );
		if ( ! $spots ) {
			return new WP_Error( 'fixpass_pin', __( 'Pick a spot first.', 'fixpass' ), array( 'status' => 400 ) );
		}
		// Validate the whole collection before writing any spot. Stay within this installation.
		foreach ( $spots as $spot ) {
			$url = esc_url_raw( (string) ( ( (array) $spot )['url'] ?? '' ) );
			$local = false;
			foreach ( array( home_url( '/' ), admin_url( '/' ) ) as $base ) {
				if ( 0 === strpos( $url, $base ) || untrailingslashit( $base ) === $url ) { $local = true; }
			}
			// A screenshot-only spot is nothing without its screenshot, and needs the agreement to allow screenshots.
			if ( 'screenshot' === ( ( (array) $spot )['kind'] ?? '' ) && ( ! self::shots_allowed() || '' === self::clean_shot( ( (array) $spot )['shot'] ?? '' ) ) ) { return new WP_Error( 'fixpass_pin_shot', __( 'A screenshot is needed here. Take one, or pick a spot instead.', 'fixpass' ), array( 'status' => 400 ) ); }
			if ( ! $local ) { return new WP_Error( 'fixpass_pin_url', __( 'Choose pages within this WordPress site.', 'fixpass' ), array( 'status' => 400 ) ); }
		}
		$ids = array();
		foreach ( $spots as $spot ) {
			$spot = (array) $spot;
			$shot = self::shots_allowed() ? self::clean_shot( $spot['shot'] ?? '' ) : '';
			unset( $spot['shot'] );
			$ids[] = self::store( $spot, $shot );
		}
		return array(
			'id'  => $ids[0],
			'ids' => $ids,
		);
	}

	/**
	 * Early in the page: remember JavaScript errors and failed requests, so a report made later
	 * on this page includes them. Nothing is sent unless the person reports a problem.
	 */
	public static function collector() {
		if ( ! self::available() ) {
			return;
		}
		wp_print_inline_script_tag(
			'(function(){var w=window,l=w.rspPinLog={errors:[],requests:[]};function add(a,x){if(!l.hold&&a.length<20){a.push(x);}}' .
			'w.addEventListener("error",function(e){if(e&&e.message){add(l.errors,{message:String(e.message).slice(0,300),source:String(e.filename||"").slice(0,300),line:e.lineno||0});}else if(e&&e.target&&(e.target.src||e.target.href)){add(l.requests,{url:String(e.target.src||e.target.href).slice(0,300),status:0,method:"GET"});}},true);' .
			'w.addEventListener("unhandledrejection",function(e){add(l.errors,{message:String(e&&e.reason&&(e.reason.message||e.reason)||"Unhandled promise rejection").slice(0,300),source:"",line:0});});' .
			'if(w.fetch){var f=w.fetch;w.fetch=function(i,o){var u=String(i&&i.url||i),m=(o&&o.method)||(i&&i.method)||"GET";return f.apply(this,arguments).then(function(r){if(!r.ok){add(l.requests,{url:u.slice(0,300),status:r.status,method:m});}return r;},function(e){add(l.requests,{url:u.slice(0,300),status:0,method:m});throw e;});};}' .
			'var X=w.XMLHttpRequest&&w.XMLHttpRequest.prototype;if(X){var op=X.open,se=X.send;X.open=function(m,u){this._hdh=[m,String(u)];return op.apply(this,arguments);};X.send=function(){var x=this;x.addEventListener("loadend",function(){if(x._hdh&&(x.status===0||x.status>=400)){add(l.requests,{url:x._hdh[1].slice(0,300),status:x.status,method:x._hdh[0]});}});return se.apply(this,arguments);};}})();'
		);
	}
	/**
	 * The spot to highlight (nothing else).
	 *
	 * @param WP_REST_Request $request Request.
	 * @return array|WP_Error
	 */
	public static function spot( WP_REST_Request $request ) {
		$pin = self::all()[ (string) $request['id'] ] ?? null;
		if ( ! $pin || ! self::visible( $pin ) ) {
			return new WP_Error( 'fixpass_pin', __( 'This highlight link has expired.', 'fixpass' ), array( 'status' => 404 ) );
		}
		return array(
			'selector' => $pin['selector'],
			'kind'     => $pin['kind'] ?? 'element',
			'box'      => $pin['box'] ?? null,
			'path'     => $pin['path'] ?? array(),
			'rect'     => $pin['rect'],
			'viewport' => $pin['viewport'],
			'shot'     => ! empty( $pin['shot'] ) && ! empty( $pin['ticket_id'] ),
		);
	}
	/**
	 * A spot, for the report screen.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return array|WP_Error
	 */
	public static function read( WP_REST_Request $request ) {
		$pin = self::all()[ (string) $request['id'] ] ?? null;
		return $pin && empty( $pin['ticket_id'] ) ? $pin : new WP_Error( 'fixpass_pin', __( 'This report wasn’t found. Try again.', 'fixpass' ), array( 'status' => 404 ) );
	}
	/**
	 * Keep one spot.
	 *
	 * @param array $raw Spot from the browser.
	 * @return string Pin ID.
	 */
	private static function store( array $raw, $shot = '' ) {
		$pin       = self::clean( $raw );
		$pin['id'] = strtolower( wp_generate_password( 32, false ) );
		$all  = self::all();
		$pins = array_filter(
			$all,
			static function ( $p ) {
				return strtotime( $p['created_at'] . ' UTC' ) > time() - self::KEEP * DAY_IN_SECONDS;
			}
		);
		foreach ( array_diff_key( $all, $pins ) as $old_id => $old ) {
			delete_option( self::SHOT . $old_id );
		}
		if ( '' !== $shot ) {
			update_option( self::SHOT . $pin['id'], $shot, false );
			$pin['shot'] = 1;
		}
		$pins[ $pin['id'] ] = array_merge(
			$pin,
			array(
				'created_at' => Fixpass_DB::now(),
				'created_by' => get_current_user_id(),
				'ticket_id'  => 0,
			)
		);
		$kept = array_slice( $pins, -200, null, true );
		foreach ( array_diff_key( $pins, $kept ) as $cut_id => $cut ) {
			delete_option( self::SHOT . $cut_id );
		}
		update_option( self::OPTION, $kept, false );
		return $pin['id'];
	}

	/**
	 * Check a screenshot from the browser: a JPEG data URL of limited size. Anything else is dropped.
	 *
	 * @param mixed $data Raw value.
	 * @return string Base64 JPEG, or an empty string.
	 */
	private static function clean_shot( $data ) {
		if ( ! is_string( $data ) || 0 !== strpos( $data, 'data:image/jpeg;base64,' ) ) { return ''; }
		$b64 = substr( $data, 23 );
		if ( '' === $b64 || strlen( $b64 ) > self::SHOT_MAX || ! preg_match( '#^[A-Za-z0-9+/]+={0,2}$#', $b64 ) ) { return ''; }
		$bin = base64_decode( $b64, true ); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_decode -- validating an image upload.
		return false !== $bin && 0 === strpos( $bin, "\xFF\xD8\xFF" ) ? $b64 : '';
	}
	/**
	 * Delete a screenshot and forget it on its spot.
	 *
	 * @param string $id Spot.
	 */
	private static function drop_shot( $id ) {
		delete_option( self::SHOT . $id );
		$pins = self::all();
		if ( isset( $pins[ $id ] ) && ! empty( $pins[ $id ]['shot'] ) ) {
			$pins[ $id ]['shot'] = 0;
			update_option( self::OPTION, $pins, false );
		}
	}
	/**
	 * Delete the screenshots sent with an access grant (called when that access ends).
	 *
	 * @param int $grant_id Grant.
	 */
	public static function purge_grant( $grant_id ) {
		foreach ( self::all() as $id => $pin ) {
			if ( empty( $pin['shot'] ) ) { continue; }
			// Those sent with this access, and any sent one whose access is no longer open.
			if ( (int) ( $pin['grant_id'] ?? 0 ) === (int) $grant_id || ( ! empty( $pin['ticket_id'] ) && ! self::visible( $pin ) ) ) { self::drop_shot( (string) $id ); }
		}
	}
	/**
	 * Daily: remove screenshots older than the cap, and any whose access has already ended.
	 */
	public static function prune_shots() {
		foreach ( self::all() as $id => $pin ) {
			if ( empty( $pin['shot'] ) ) { continue; }
			$old   = strtotime( $pin['created_at'] . ' UTC' ) < time() - self::SHOT_KEEP * DAY_IN_SECONDS;
			$ended = ! empty( $pin['ticket_id'] ) && ! self::visible( $pin );
			if ( $old || $ended ) { self::drop_shot( (string) $id ); }
		}
	}
	/**
	 * The screenshot of a sent spot, for support, while the access it was sent with is open.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return array|WP_Error
	 */
	public static function shot( WP_REST_Request $request ) {
		$id  = (string) $request['id'];
		$pin = self::all()[ $id ] ?? null;
		$b64 = $pin && ! empty( $pin['shot'] ) && ! empty( $pin['ticket_id'] ) && self::visible( $pin ) ? get_option( self::SHOT . $id, '' ) : '';
		if ( '' === $b64 ) {
			return new WP_Error( 'fixpass_shot', __( 'The screenshot is no longer available.', 'fixpass' ), array( 'status' => 404 ) );
		}
		return array( 'image' => 'data:image/jpeg;base64,' . $b64 );
	}
	/**
	 * The screenshot, for the site owner who took it.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return array|WP_Error
	 */
	public static function shot_owner( WP_REST_Request $request ) {
		$id  = (string) $request['id'];
		$b64 = get_option( self::SHOT . $id, '' );
		if ( '' === $b64 ) {
			return new WP_Error( 'fixpass_shot', __( 'The screenshot is no longer available.', 'fixpass' ), array( 'status' => 404 ) );
		}
		return array( 'image' => 'data:image/jpeg;base64,' . $b64 );
	}
	/**
	 * The screenshots still stored on this site, for the owner to view or delete.
	 *
	 * @return array
	 */
	public static function shots_list() {
		$out = array();
		foreach ( self::all() as $id => $pin ) {
			if ( empty( $pin['shot'] ) || '' === get_option( self::SHOT . $id, '' ) ) { continue; }
			$out[] = array(
				'id'      => (string) $id,
				'title'   => (string) ( $pin['label'] ?? '' ) !== '' ? (string) $pin['label'] : (string) ( $pin['title'] ?? '' ),
				'page'    => (string) ( $pin['url'] ?? '' ),
				'created' => (string) ( $pin['created_at'] ?? '' ),
				'sent'    => ! empty( $pin['ticket_id'] ),
				'open'    => ! empty( $pin['ticket_id'] ) && self::visible( $pin ),
			);
		}
		usort( $out, static function ( $a, $b ) { return strcmp( $b['created'], $a['created'] ); } );
		return array( 'shots' => $out );
	}
	/**
	 * The owner removes a screenshot.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return array
	 */
	public static function shot_delete( WP_REST_Request $request ) {
		self::drop_shot( (string) $request['id'] );
		return array( 'deleted' => true );
	}
	/**
	 * Everything about a spot that goes into a report.
	 *
	 * @param string $id Pin.
	 * @return array|null
	 */
	public static function spot_data( $id ) {
		$pin = self::all()[ sanitize_key( (string) $id ) ] ?? null;
		if ( ! $pin || ! self::visible( $pin ) ) {
			return null;
		}
		unset( $pin['created_by'], $pin['ticket_id'], $pin['grant_id'], $pin['attachment'] ); // ticket_id: 1 once sent with a link.
		return $pin;
	}
	/** Sent highlights belong only to their original, still-active access grant. */
	private static function visible( array $pin ) {
		if ( empty( $pin['ticket_id'] ) ) { return true; }
		// Legacy sent spots without an exact mapping must never attach to later access.
		return ! empty( $pin['grant_id'] ) && Fixpass_Access::is_active( Fixpass_Access::get( (int) $pin['grant_id'] ) );
	}

	/**
	 * Remember that a spot was reported (for clean-up).
	 *
	 * @param string $id   Pin.
	 * @param int    $sent 1 once the spot went out with a support link.
	 * @param int    $grant_id Exact access grant; sent spots cannot move to another grant.
	 */
	public static function mark_sent( $id, $sent = 1, $grant_id = 0 ) {
		$pins = self::all();
		if ( isset( $pins[ $id ] ) && ( empty( $pins[ $id ]['ticket_id'] ) || (int) ( $pins[ $id ]['grant_id'] ?? 0 ) === (int) $grant_id ) ) {
			$pins[ $id ]['ticket_id'] = (int) $sent;
			$pins[ $id ]['grant_id'] = (int) $grant_id;
			update_option( self::OPTION, $pins, false );
		}
	}
	/**
	 * All pins by ID.
	 *
	 * @return array
	 */
	private static function all() {
		$pins = get_option( self::OPTION, array() );
		return is_array( $pins ) ? $pins : array();
	}
	/**
	 * Clean a report from the browser.
	 *
	 * @param array $in Raw.
	 * @return array
	 */
	public static function clean( array $in ) {
		$num  = static function ( $v ) {
			return (int) round( (float) $v );
		};
		$rect = (array) ( $in['rect'] ?? array() );
		$view = (array) ( $in['viewport'] ?? array() );
		$list = static function ( $items, array $keys ) {
			$out = array();
			foreach ( array_slice( (array) $items, 0, 20 ) as $item ) {
				$row = array();
				foreach ( $keys as $k => $type ) {
					$v         = ( (array) $item )[ $k ] ?? '';
					$row[ $k ] = 'int' === $type ? (int) $v : substr( Fixpass_Redactor::text( sanitize_text_field( (string) $v ) ), 0, 300 );
				}
				$out[] = $row;
			}
			return $out;
		};
		return array(
			'url'      => esc_url_raw( (string) ( $in['url'] ?? '' ) ),
			'title'    => substr( sanitize_text_field( (string) ( $in['title'] ?? '' ) ), 0, 200 ),
			'selector' => substr( sanitize_text_field( (string) ( $in['selector'] ?? '' ) ), 0, 500 ),
			// element: the element itself · area: a box drawn on the element (fractions of its size).
			'kind'     => in_array( $in['kind'] ?? '', array( 'area', 'screenshot' ), true ) ? $in['kind'] : 'element',
			'box'      => 'area' === ( $in['kind'] ?? '' ) && is_array( $in['box'] ?? null ) ? self::clean_box( $in['box'] ) : null,
			// How to find the element again, step by step from <body> (see spotlight.js).
			'path'     => self::clean_path( $in['path'] ?? array() ),
			'text'     => substr( sanitize_text_field( (string) ( $in['text'] ?? '' ) ), 0, 200 ),
			// The customer's own words for this spot ("this button", "wrong price").
			'label'    => substr( sanitize_text_field( (string) ( $in['label'] ?? '' ) ), 0, 80 ),
			'rect'     => array(
				'x' => $num( $rect['x'] ?? 0 ),
				'y' => $num( $rect['y'] ?? 0 ),
				'w' => max( 0, $num( $rect['w'] ?? 0 ) ),
				'h' => max( 0, $num( $rect['h'] ?? 0 ) ),
			),
			'viewport' => array(
				'w'   => max( 0, $num( $view['w'] ?? 0 ) ),
				'h'   => max( 0, $num( $view['h'] ?? 0 ) ),
				'dpr' => round( max( 0, min( 8, (float) ( $view['dpr'] ?? 1 ) ) ), 2 ),
			),
			'browser'  => substr( sanitize_text_field( (string) ( $in['browser'] ?? '' ) ), 0, 300 ),
			'area'     => 'admin' === ( $in['area'] ?? '' ) ? 'admin' : 'front',
			'errors'   => $list( $in['errors'] ?? array(), array( 'message' => 'text', 'source' => 'text', 'line' => 'int' ) ),
			'requests' => $list( $in['requests'] ?? array(), array( 'url' => 'text', 'status' => 'int', 'method' => 'text' ) ),
		);
	}
	/**
	 * Steps to an element: { id } or { t: tag, c: classes, i: position }.
	 *
	 * @param mixed $path Raw.
	 * @return array[]
	 */
	private static function clean_path( $path ) {
		$out = array();
		foreach ( array_slice( (array) $path, 0, 10 ) as $step ) {
			$step = (array) $step;
			if ( ! empty( $step['id'] ) && preg_match( '/^[A-Za-z][\w-]{0,99}$/', (string) $step['id'] ) ) {
				$out[] = array( 'id' => (string) $step['id'] );
				continue;
			}
			if ( empty( $step['t'] ) || ! preg_match( '/^[a-z][a-z0-9-]{0,30}$/', (string) $step['t'] ) ) {
				return array();
			}
			$out[] = array(
				't' => (string) $step['t'],
				'c' => array_values(
					array_filter(
						array_slice( (array) ( $step['c'] ?? array() ), 0, 2 ),
						static function ( $c ) {
							return is_string( $c ) && preg_match( '/^[A-Za-z][\w-]{0,99}$/', $c );
						}
					)
				),
				'i' => max( 0, min( 500, (int) ( $step['i'] ?? 0 ) ) ),
			);
		}
		return $out;
	}
	/**
	 * An area box: pixel offsets from an element, or (older spots) fractions of it.
	 *
	 * @param array $box Raw { x, y, w, h }.
	 * @return array
	 */
	private static function clean_box( array $box ) {
		$out = array();
		if ( ! empty( $box['px'] ) ) {
			// Pixels from the element under the box's centre.
			$out['px'] = true;
			foreach ( array( 'x', 'y', 'w', 'h' ) as $k ) {
				$out[ $k ] = max( -20000, min( 20000, (int) ( $box[ $k ] ?? 0 ) ) );
			}
			return $out;
		}
		// Fractions of the element (spots from before 2.1.1).
		foreach ( array( 'x', 'y', 'w', 'h' ) as $k ) {
			$out[ $k ] = round( max( 0, min( 1, (float) ( $box[ $k ] ?? 0 ) ) ), 4 );
		}
		return $out;
	}
}
