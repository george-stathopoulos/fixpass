<?php
/**
 * View the site as another role.
 *
 * @package Fixpass
 */

defined( 'ABSPATH' ) || exit;

/**
 * Lets support see the site the way a lower role (Subscriber, Customer, Editor...) sees it, and
 * switch back. Support stays logged in as their own support account: only the permissions that
 * account has are cut down to the chosen role's, in their own browser. So the activity log, the
 * limits on installs and users, and the access end time keep working, and the preview can never
 * give support more than they already have.
 */
final class Fixpass_Role_View {

	const COOKIE = 'fixpass_roleview';
	const ACTION = 'fixpass_roleview_stop';

	/**
	 * Role found in the cookie for this request: null until looked up.
	 *
	 * @var string|null
	 */
	private static $active = null;

	/**
	 * Register hooks.
	 */
	public static function init() {
		add_filter( 'user_has_cap', array( __CLASS__, 'limit' ), 99, 4 );
		add_action( 'set_current_user', array( __CLASS__, 'apply_role' ), 99 );
		add_action( 'admin_bar_menu', array( __CLASS__, 'admin_bar' ), 85 );
		add_action( 'admin_post_' . self::ACTION, array( __CLASS__, 'stop_request' ) );
		add_action( 'fixpass_access_changed', array( __CLASS__, 'forget' ) );
	}

	/**
	 * Whether this request is Fixpass's own screen talking to its REST routes, which always run
	 * with support's real permissions so the switch back can never be locked out.
	 *
	 * @return bool
	 */
	private static function bypass() {
		$uri = isset( $_SERVER['REQUEST_URI'] ) ? (string) wp_unslash( $_SERVER['REQUEST_URI'] ) : ''; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- only compared with a fixed string.
		return false !== strpos( $uri, Fixpass_REST::NS ) || false !== strpos( $uri, rawurlencode( Fixpass_REST::NS ) );
	}

	/**
	 * Sign the cookie so only this plugin can make one for this user and access.
	 *
	 * @param int    $user_id  User.
	 * @param int    $grant_id Access.
	 * @param string $role     Role.
	 * @param int    $expires  End time of the access.
	 * @return string
	 */
	private static function sign( $user_id, $grant_id, $role, $expires ) {
		return hash_hmac( 'sha256', implode( '|', array( $user_id, $grant_id, $role, $expires ) ), wp_salt( 'auth' ) );
	}

	/**
	 * The role support is viewing as right now, or ''.
	 *
	 * @return string
	 */
	public static function active() {
		if ( null !== self::$active ) {
			return self::$active;
		}
		self::$active = '';
		$user_id      = get_current_user_id();
		if ( ! $user_id || empty( $_COOKIE[ self::COOKIE ] ) ) {
			return self::$active;
		}
		$parts = explode( '|', (string) wp_unslash( $_COOKIE[ self::COOKIE ] ) ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- checked by the signature below.
		if ( 4 !== count( $parts ) ) {
			return self::$active;
		}
		list( $role, $grant_id, $expires, $sig ) = $parts;
		$grant_id                               = (int) $grant_id;
		$expires                                = (int) $expires;
		if ( $grant_id !== (int) get_user_meta( $user_id, Fixpass_Access::META, true ) || $expires < time() || ! hash_equals( self::sign( $user_id, $grant_id, $role, $expires ), (string) $sig ) ) {
			return self::$active;
		}
		if ( ! Fixpass_Access::is_active( Fixpass_Access::get( $grant_id ) ) || ! get_role( $role ) ) {
			return self::$active;
		}
		self::$active = $role;
		return self::$active;
	}

	/**
	 * Forget the role found earlier in this request.
	 */
	public static function forget() {
		self::$active = null;
	}

	/**
	 * Cut support's permissions down to the chosen role's. Never adds one.
	 *
	 * @param array   $allcaps All caps of the user.
	 * @param array   $caps    Required caps.
	 * @param array   $args    Args.
	 * @param WP_User $user    User.
	 * @return array
	 */
	public static function limit( $allcaps, $caps, $args, $user ) {
		if ( ! $user instanceof WP_User || get_current_user_id() !== (int) $user->ID || self::bypass() ) {
			return $allcaps;
		}
		$role = self::active();
		if ( '' === $role ) {
			return $allcaps;
		}
		$wanted = (array) get_role( $role )->capabilities;
		$out    = array();
		foreach ( $wanted as $cap => $on ) {
			if ( $on && ! empty( $allcaps[ $cap ] ) ) {
				$out[ $cap ] = true;
			}
		}
		$out[ $role ] = true;
		return $out;
	}

	/**
	 * Show the chosen role to plugins that read the user's role names.
	 */
	public static function apply_role() {
		$role = self::active();
		$user = wp_get_current_user();
		if ( '' !== $role && $user && $user->ID && ! self::bypass() ) {
			$user->roles = array( $role );
		}
	}

	/**
	 * Roles support may preview: every role on the site that has fewer permissions than they do.
	 *
	 * @return array List of { id, label, desc }.
	 */
	public static function roles() {
		$short = array(
			'editor'       => __( 'Edits all posts and pages', 'fixpass' ),
			'author'       => __( 'Publishes their own posts', 'fixpass' ),
			'contributor'  => __( 'Writes posts, cannot publish', 'fixpass' ),
			'subscriber'   => __( 'Can only read and edit their own profile', 'fixpass' ),
			'customer'     => __( 'WooCommerce shopper', 'fixpass' ),
			'shop_manager' => __( 'WooCommerce, manages orders and products', 'fixpass' ),
		);
		$out   = array();
		foreach ( wp_roles()->roles as $id => $role ) {
			if ( 'administrator' === $id || 'restricted_admin' === $id ) {
				continue;
			}
			$smaller = true;
			foreach ( (array) $role['capabilities'] as $cap => $on ) {
				if ( $on && ! current_user_can( $cap ) ) {
					$smaller = false;
					break;
				}
			}
			if ( $smaller ) {
				$out[] = array(
					'id'    => $id,
					'label' => translate_user_role( $role['name'] ),
					'desc'  => $short[ $id ] ?? '',
				);
			}
		}
		return $out;
	}

	/**
	 * What the View as screen shows.
	 *
	 * @return array
	 */
	public static function state() {
		$role  = self::active();
		$label = '';
		foreach ( self::roles() as $r ) {
			if ( $r['id'] === $role ) {
				$label = $r['label'];
			}
		}
		return array(
			'active' => $role,
			'label'  => $label,
			'roles'  => self::roles(),
			'home'   => home_url( '/' ),
		);
	}

	/**
	 * Start viewing as a role.
	 *
	 * @param string $role Role.
	 * @return array|WP_Error
	 */
	public static function start( $role ) {
		$grant = Fixpass_Access::current_grant();
		$ok    = array_filter( self::roles(), static function ( $r ) use ( $role ) { return $r['id'] === $role; } );
		if ( ! $grant || ! $ok ) {
			return new WP_Error( 'fixpass_roleview', __( 'That role can’t be previewed from your support account.', 'fixpass' ), array( 'status' => 400 ) );
		}
		$expires = (int) strtotime( $grant['expires_at'] . ' UTC' );
		if ( Fixpass_Access::is_permanent( $grant ) || $expires <= time() ) {
			$expires = time() + DAY_IN_SECONDS;
		}
		$user_id = get_current_user_id();
		$value   = implode( '|', array( $role, (int) $grant['id'], $expires, self::sign( $user_id, (int) $grant['id'], $role, $expires ) ) );
		self::set_cookie( $value, 0 );
		$_COOKIE[ self::COOKIE ] = $value;
		self::forget();
		Fixpass_Monitor::record( 'activity', 'role_view_on', $role, array( 'label' => reset( $ok )['label'] ), (int) $grant['id'] );
		return self::state();
	}

	/**
	 * Switch back to support's own permissions.
	 *
	 * @return array
	 */
	public static function stop() {
		$was = self::active();
		if ( '' !== $was ) {
			Fixpass_Monitor::record( 'activity', 'role_view_off', $was, array(), Fixpass_Access::current_grant_id() );
		}
		self::set_cookie( '', time() - YEAR_IN_SECONDS );
		unset( $_COOKIE[ self::COOKIE ] );
		self::forget();
		return self::state();
	}

	/**
	 * The Switch back link in the admin bar.
	 */
	public static function stop_request() {
		check_admin_referer( self::ACTION );
		if ( Fixpass_Access::current_grant_id() ) {
			self::stop();
		}
		wp_safe_redirect( admin_url( 'admin.php?page=' . Fixpass_Admin::SLUG . '#/view-as' ) );
		exit;
	}

	/**
	 * Write or clear the cookie: this browser only, ends with the browser session.
	 *
	 * @param string $value   Value.
	 * @param int    $expires Expiry (0 = browser session).
	 */
	private static function set_cookie( $value, $expires ) {
		setcookie( self::COOKIE, $value, array( 'expires' => $expires, 'path' => COOKIEPATH ?: '/', 'domain' => COOKIE_DOMAIN ?: '', 'secure' => is_ssl(), 'httponly' => true, 'samesite' => 'Lax' ) ); // phpcs:ignore Universal.Operators.DisallowShortTernary.Found, WordPress.PHP.NoSilencedErrors.Discouraged
	}

	/**
	 * Admin bar: always shows when support is previewing, with one click back.
	 *
	 * @param WP_Admin_Bar $bar Bar.
	 */
	public static function admin_bar( $bar ) {
		$role = self::active();
		if ( '' === $role || ! Fixpass_Access::current_grant_id() ) {
			return;
		}
		$name = translate_user_role( wp_roles()->roles[ $role ]['name'] ?? $role );
		$bar->add_node(
			array(
				'id'    => 'fixpass-roleview',
				'title' => '<span style="background:#dba617;color:#1d2327;padding:2px 8px;border-radius:3px;font-weight:700">' . esc_html( sprintf( /* translators: %s: role */ __( 'Viewing as %s', 'fixpass' ), $name ) ) . '</span>',
				'href'  => Fixpass_Admin::view_as_url(),
			)
		);
		$bar->add_node(
			array(
				'id'    => 'fixpass-roleview-back',
				'title' => '<span style="background:#f0f0f1;color:#1d2327;padding:2px 10px;border-radius:3px;font-weight:700">' . esc_html__( 'Switch back to Support', 'fixpass' ) . '</span>',
				'href'  => wp_nonce_url( admin_url( 'admin-post.php?action=' . self::ACTION ), self::ACTION ),
			)
		);
	}
}
