<?php
/** Owner-controlled WordPress agency connection and support requests. */
defined( 'ABSPATH' ) || exit;
final class Fixpass_Agency {
	const OPTION = 'fixpass_agency';
	const CRON = 'fixpass_agency_sync';
	private static $syncing = false;
	public static function init() {
		add_action( 'admin_post_fixpass_agency', array( __CLASS__, 'handle' ) );
		add_action( 'shutdown', array( __CLASS__, 'flush_activity' ) );
		add_action( 'admin_init', array( __CLASS__, 'refresh' ) );
		add_action( self::CRON, array( __CLASS__, 'sync' ) );
		add_action( 'login_form_fixpass_agency', array( __CLASS__, 'entry' ) );
		add_action( 'fixpass_access_changed', array( __CLASS__, 'changed' ), 20, 2 );
		add_action( 'rest_api_init', array( __CLASS__, 'routes' ) );
		add_filter( 'determine_current_user', array( __CLASS__, 'session' ), 99 );
	}
	public static function menu() {
		if ( Fixpass_License::owner() ) { add_submenu_page( Fixpass_Admin::SLUG, 'Support team', 'Support team', Fixpass_Access::CAP, 'fixpass-agency', array( __CLASS__, 'render' ) ); }
	}
	private static function url() { return untrailingslashit( home_url( '/' ) ); }
	private static function call( $path, $data = array() ) {
		$license = get_option( Fixpass_License::OPTION, array() );
		return Fixpass_License::request( 'agency-site/' . $path, array_merge( $data, array( 'credential' => $license['credential'] ?? '', 'url' => self::url() ) ) );
	}
	public static function owns( $grant ) {
		$state = get_option( self::OPTION, array() );
		foreach ( $state['grants'] ?? array() as $r ) { if ( (int) $r['grant'] === (int) $grant ) { return true; } }
		return false;
	}
	/** The session number FixHub gave this access (shown as #0001), or '' for access FixHub does not know. */
	public static function number( $grant ) {
		$state = get_option( self::OPTION, array() );
		foreach ( $state['grants'] ?? array() as $r ) { if ( (int) $r['grant'] === (int) $grant && ! empty( $r['number'] ) ) { return sprintf( '#%04d', (int) $r['number'] ); } }
		return '';
	}
	public static function can_create() {
		$state = get_option( self::OPTION, array() );
		return Fixpass_License::owner() && ! empty( $state['connected'] ) && ( $state['url'] ?? '' ) === self::url();
	}
	public static function track( $request, $grant ) {
		$state = get_option( self::OPTION, array() );
		wp_clear_scheduled_hook( Fixpass_Plugin::SELF_REMOVE );
		$state['grants'][ $request ] = array( 'grant' => (int) $grant, 'ended' => false, 'generation' => $state['generation'] ?? '', 'cursor' => 0 );
		update_option( self::OPTION, $state, false );
	}
	/** Bounded grant-only activity; no actor, IP, freeform details or login URLs leave WordPress. */
	public static function flush_activity( $force = false ) {
		if ( self::$syncing ) { return; }
		$state = get_option( self::OPTION, array() );
		if ( ! $force && (int) ( $state['activity_checked'] ?? 0 ) > time() - 45 ) { return; }
		self::$syncing = true;
		try {
			$sent = 0;
			foreach ( $state['grants'] ?? array() as $id => $local ) {
				if ( $sent >= 4 || empty( $local['generation'] ) ) { continue; }
				$rows = Fixpass_Monitor::query( array( 'grant_id' => (int) $local['grant'], 'after_id' => (int) ( $local['cursor'] ?? 0 ), 'limit' => 40 ) );
				if ( ! $rows ) { continue; }
				$events = array();
				foreach ( $rows as $row ) {
					// Only the component basename is synchronized; query strings and arbitrary details stay local.
					$object = 'change' === $row['type'] ? sanitize_text_field( basename( strtok( (string) $row['object'], '?#' ) ) ) : ''; 
					if ( preg_match( '/[@#?]|token|password|secret|nonce|credential/i', $object ) ) { $object = ''; }
					// The same plain wording the site owner sees; always sent, whatever the agreement shows the owner.
					$events[] = array( 'id' => (int) $row['id'], 'created' => (int) strtotime( $row['created_at'] . ' UTC' ) * 1000, 'action' => preg_replace( '/[^a-z_]/', '', substr( $row['action'], 0, 64 ) ) ?: 'activity', 'object' => substr( $object, 0, 160 ), 'text' => Fixpass_Activity::hub_text( $row ) );
				}
				$result = self::call( 'events', array( 'request' => $id, 'generation' => $local['generation'], 'events' => $events ) );
				$sent++;
				if ( ! is_wp_error( $result ) ) { $state['grants'][ $id ]['cursor'] = (int) $result['cursor']; }
			}
			$state['activity_checked'] = time();
			update_option( self::OPTION, $state, false );
		} finally { self::$syncing = false; }
	}
	public static function disconnect() {
		$state = get_option( self::OPTION, array() );
		self::$syncing = true;
		try { foreach ( $state['grants'] ?? array() as $r ) { Fixpass_Access::revoke( (int) $r['grant'] ); } }
		finally { self::$syncing = false; }
		$state['connected'] = false;
		$state['requests'] = array();
		update_option( self::OPTION, $state, false );
		self::flush_activity( true );
		// Local cleanup is complete even if the following network request fails.
		return self::call( 'consent', array( 'accept' => false ) );
	}
	/** Best-effort notice that this site stopped running the plugin, so FixHub need not wait for a timeout. */
	public static function offline( $reason ) {
		$state = get_option( self::OPTION, array() );
		if ( empty( $state['connected'] ) ) { return; }
		self::call( 'offline', array( 'reason' => $reason ) );
	}
	/**
	 * FixHub's "Check now": a public ping that makes this site sync with FixHub straight away (rate limited, reveals nothing).
	 */
	public static function routes() {
		register_rest_route( 'fixpass/v1', '/ping', array( 'methods' => 'GET,POST', 'permission_callback' => '__return_true', 'callback' => array( __CLASS__, 'ping' ) ) );
	}
	public static function ping() {
		nocache_headers();
		if ( ! get_transient( 'fixpass_ping' ) ) { set_transient( 'fixpass_ping', 1, 20 ); self::sync( true ); }
		return new WP_REST_Response( array( 'ok' => true, 'version' => FIXPASS_VERSION ), 200 );
	}
	public static function refresh() { if ( Fixpass_License::owner() ) { self::sync(); } }
	public static function session( $user ) {
		if ( $user && self::owns( (int) get_user_meta( $user, Fixpass_Access::META, true ) ) ) {
			self::sync();
			if ( ! Fixpass_Access::is_active( Fixpass_Access::get( (int) get_user_meta( $user, Fixpass_Access::META, true ) ) ) ) { return false; }
		}
		return $user;
	}
	public static function sync( $force = false ) {
		if ( self::$syncing ) { return; }
		$state = get_option( self::OPTION, array() );
		if ( ! $force && (int) ( $state['checked'] ?? 0 ) > time() - 45 ) { return; }
		$license = get_option( Fixpass_License::OPTION, array() );
		if ( empty( $license['credential'] ) ) { return; }
		self::$syncing = true;
		try {
			$result = self::call( 'sync', array( 'loginUrl' => strtok( wp_login_url(), '?#' ), 'version' => FIXPASS_VERSION ) );
			$state['checked'] = time();
			$state['error'] = is_wp_error( $result ) ? $result->get_error_message() : '';
			// Invalid credentials after a reset terminate locally; a network outage keeps the finite deadline.
			$invalid = is_wp_error( $result ) && 401 === (int) $result->get_error_data();
			foreach ( $state['grants'] ?? array() as $id => $local ) {
				$grant = Fixpass_Access::get( (int) $local['grant'] );
				if ( ! empty( $local['ended'] ) && ! empty( $local['reported'] ) && ! Fixpass_Access::is_active( $grant ) ) { continue; }
				$remote = null;
				if ( ! is_wp_error( $result ) ) { foreach ( $result['requests'] as $r ) { if ( $r['id'] === $id ) { $remote = $r; break; } } }
				if ( $remote && ! empty( $remote['number'] ) ) { $local['number'] = (int) $remote['number']; }
				if ( $remote && 'approved' === $remote['status'] && Fixpass_Access::is_active( $grant ) ) { self::reconcile( $id, $grant, $remote ); $grant = Fixpass_Access::get( (int) $local['grant'] ); }
				if ( ! Fixpass_Access::is_active( $grant ) || $invalid || ( ! is_wp_error( $result ) && ( empty( $state['connected'] ) || empty( $result['connected'] ) || ( $state['url'] ?? '' ) !== self::url() || ! $remote || 'approved' !== $remote['status'] ) ) ) {
					Fixpass_Access::revoke( (int) $local['grant'] );
					$local['ended'] = true;
				}
				if ( ! empty( $local['ended'] ) && empty( $local['reported'] ) ) {
					if ( $invalid || ( ! is_wp_error( $result ) && ( empty( $result['connected'] ) || ! $remote || ! in_array( $remote['status'], array( 'pending', 'approving', 'approved' ), true ) ) ) ) { $local['reported'] = true; }
					elseif ( ! is_wp_error( $result ) ) { $local['reported'] = ! is_wp_error( self::call( 'decision', array( 'request' => $id, 'action' => 'ended' ) ) ); }
				}
				$state['grants'][ $id ] = $local;
			}
			unset( $local );
			if ( ! is_wp_error( $result ) ) {
				$previous = array(); foreach ( $state['requests'] ?? array() as $r ) { $previous[ $r['id'] ] = $r['status']; }
				foreach ( $result['requests'] as $r ) { if ( ( $previous[ $r['id'] ] ?? '' ) !== $r['status'] ) { Fixpass_Monitor::record( 'access', 'agency_request', '', array( 'status' => $r['status'], 'hours' => (int) $r['hours'], 'purpose' => sanitize_text_field( $r['purpose'] ) ) ); } }
				$state['generation'] = $result['generation'] ?? ''; $state['requests'] = $result['requests']; $state['agency'] = $result['agency'];
				// The terms agreed with this client (a level chosen in FixHub). Older Hubs send none: no limits then.
				$state['agreement'] = self::clean_agreement( $result['agreement'] ?? null );
				$state['subtitle'] = mb_substr( sanitize_text_field( (string) ( $result['subtitle'] ?? '' ) ), 0, 60 );
				// Older Hubs don't send this: treat the name as set. When the team cleared its name the plugin shows plain Fixpass.
				$state['branded'] = ! isset( $result['branded'] ) || ! empty( $result['branded'] );
				$footer = is_array( $result['footer'] ?? null ) ? $result['footer'] : array();
				$state['footer_note']   = mb_substr( sanitize_text_field( (string) ( $footer['note'] ?? '' ) ), 0, 120 );
				$state['footer_credit'] = ! isset( $footer['credit'] ) || ! empty( $footer['credit'] );
				$hash = (string) ( $result['logo_hash'] ?? '' );
				if ( $hash !== (string) ( $state['logo_hash'] ?? '' ) ) {
					$state['logo'] = ''; $state['logo_hash'] = '';
					if ( preg_match( '/^[a-f0-9]{16}$/', $hash ) ) {
						$logo = self::call( 'logo' );
						$data = is_wp_error( $logo ) ? '' : (string) ( $logo['logo'] ?? '' );
						if ( self::valid_logo( $data ) && substr( hash( 'sha256', $data ), 0, 16 ) === $hash ) { $state['logo'] = $data; $state['logo_hash'] = $hash; }
					}
				}
				$state['contact'] = time(); if ( empty( $result['connected'] ) ) { $state['connected'] = false; } }
			update_option( self::OPTION, $state, false );
		} finally { self::$syncing = false; }
	}
	public static function changed( $grant, $reason ) {
		if ( in_array( $reason, array( 'login', 'changed', 'extended' ), true ) || self::$syncing ) { return; }
		$state = get_option( self::OPTION, array() );
		foreach ( $state['grants'] ?? array() as $id => $r ) {
			if ( (int) $r['grant'] === (int) $grant ) { $state['grants'][ $id ]['ended'] = true; update_option( self::OPTION, $state, false ); self::call( 'decision', array( 'request' => $id, 'action' => 'ended' ) ); self::flush_activity( true ); }
		}
	}
	public static function status() {
		self::sync();
		$s = get_option( self::OPTION, array() );
		return array( 'connected' => ! empty( $s['connected'] ) && ( $s['url'] ?? '' ) === self::url(), 'confirmed' => ! empty( $s['connected'] ) && empty( $s['error'] ) && (int) ( $s['contact'] ?? 0 ) > time() - 90 && ( $s['url'] ?? '' ) === self::url(), 'agency' => self::display_name(), 'agreement' => self::agreement(), 'generation' => $s['generation'] ?? '', 'error' => $s['error'] ?? '', 'requests' => array_map( static function ( $r ) { return array_intersect_key( $r, array_flip( array( 'id', 'purpose', 'hours', 'status', 'reusable', 'allow_extend', 'extend_until' ) ) ); }, $s['requests'] ?? array() ) );
	}
	public static function action( $action, $input = array() ) {
		if ( ! Fixpass_License::owner() ) { return new WP_Error( 'forbidden', 'Owner access required.', array( 'status' => 403 ) ); }
		$id = sanitize_text_field( $input['request_id'] ?? '' );
		$state = get_option( self::OPTION, array() );
		$result = true;
		if ( 'inspect' === $action ) {
			$code = sanitize_text_field( ( $input['code'] ?? '' ) );
			$result = self::call( 'inspect', array( 'code' => $code ) );
			if ( ! is_wp_error( $result ) ) {
				$expires = (int) floor( $result['expires'] / 1000 );
				return array( 'agency' => $result['agency'], 'url' => $result['url'], 'expires' => $expires, 'signature' => hash_hmac( 'sha256', $code . '|' . $expires . '|' . get_current_user_id(), wp_salt( 'auth' ) ) );
			}
		} elseif ( 'connect' === $action ) {
			$code = sanitize_text_field( ( $input['code'] ?? '' ) );
			$expires = (int) ( $input['expires'] ?? 0 );
			$signature = sanitize_text_field( ( $input['signature'] ?? '' ) );
			$expected = hash_hmac( 'sha256', $code . '|' . $expires . '|' . get_current_user_id(), wp_salt( 'auth' ) );
			$result = $expires > time() && hash_equals( $expected, $signature ) ? self::call( 'connect', array( 'code' => $code, 'accept' => true ) ) : new WP_Error( 'code_expired', 'Inspect a new connection code first.' );
			if ( ! is_wp_error( $result ) ) {
				update_option( Fixpass_License::OPTION, array( 'credential' => $result['credential'], 'url' => self::url() ), false );
				$state['checked'] = 0; $state['connected'] = true; $state['url'] = self::url(); $state['agency'] = $result['account']; update_option( self::OPTION, $state, false );
			}
		} elseif ( 'disconnect' === $action ) { return Fixpass_License::action( 'disconnect' ); }
		elseif ( 'end' === $action ) {
			if ( isset( $state['grants'][ $id ] ) ) { Fixpass_Access::revoke( (int) $state['grants'][ $id ]['grant'] ); }
			$result = self::call( 'decision', array( 'request' => $id, 'action' => 'ended' ) );
		} elseif ( 'decline' === $action ) { $result = self::call( 'decision', array( 'request' => $id, 'action' => 'decline' ) ); }
		elseif ( 'approve' === $action ) {
			// Serialize owner clicks across the complete reserve/create/confirm sequence.
			if ( (int) get_option( 'fixpass_agency_approving', 0 ) < time() - 120 ) { delete_option( 'fixpass_agency_approving' ); }
			if ( ! add_option( 'fixpass_agency_approving', time(), '', false ) ) { return new WP_Error( 'busy', 'Approval in progress. Refresh shortly.' ); }
			try {
				$result = self::approve( $id, (int) ( $input['hours'] ?? 0 ), $input );
			} finally { delete_option( 'fixpass_agency_approving' ); }
		} elseif ( 'refresh' !== $action ) { $result = new WP_Error( 'action', 'Unknown support action.' ); }
		if ( is_wp_error( $result ) ) { return $result; }
		if ( 'connect' === $action ) { Fixpass_License::action( 'refresh' ); }
		self::sync( true );
		return self::status();
	}
	private static function policy( $input, $hours ) {
		$ag       = self::agreement();
		$allow    = ! isset( $input['extend'] ) || ! empty( $input['extend'] );
		$reusable = ! empty( $input['reusable'] );
		if ( $ag ) {
			// FixHub enforces the same limits; this keeps the owner from choosing what the agreement does not cover.
			if ( $hours > $ag['max_hours'] ) { return new WP_Error( 'agreement', sprintf( 'Your agreement with %1$s (%2$s) allows up to %3$s of access. Choose a shorter time.', self::display_name(), $ag['name'], self::hours_label( $ag['max_hours'] ) ) ); }
			if ( $reusable && ! $ag['reusable'] ) { return new WP_Error( 'agreement', sprintf( 'Your agreement with %1$s (%2$s) allows one entry per approval. Choose a one-time link.', self::display_name(), $ag['name'] ) ); }
			if ( $ag['extend_hours'] < 1 ) { $allow = false; }
		}
		$until = ! empty( $input['extend_until'] ) ? gmdate( 'Y-m-d H:i:s', (int) ( $input['extend_until'] / 1000 ) ) : Fixpass_Access::parse_extend_limit( (int) ( $input['extend_days'] ?? 30 ), (string) ( $input['extend_date'] ?? '' ), $hours );
		if ( is_wp_error( $until ) ) { return $until; }
		$until = strtotime( $until . ' UTC' );
		if ( $ag && $ag['extend_hours'] > 0 ) { $until = min( $until, time() + $ag['extend_hours'] * HOUR_IN_SECONDS ); }
		if ( $ag && ! $allow ) { $until = time() + $hours * HOUR_IN_SECONDS; }
		return array( 'reusable' => $reusable, 'allow_extend' => $allow, 'extend_until' => $until * 1000 );
	}
	/**
	 * Check the agreement sent by FixHub and keep only what is understood.
	 *
	 * @param mixed $raw Value from the sync response.
	 * @return array|null
	 */
	public static function clean_agreement( $raw ) {
		if ( ! is_array( $raw ) ) { return null; }
		$max = (int) ( $raw['max_hours'] ?? 0 );
		$ext = (int) ( $raw['extend_hours'] ?? 0 );
		if ( ! in_array( $max, array( 24, 48, 72, 120, 168 ), true ) || $ext < 0 || $ext > 720 ) { return null; }
		if ( $ext > 0 && $ext <= $max ) { $ext = 0; }
		return array(
			'id'            => sanitize_text_field( (string) ( $raw['id'] ?? '' ) ),
			'name'          => mb_substr( sanitize_text_field( (string) ( $raw['name'] ?? '' ) ), 0, 60 ),
			'description'   => mb_substr( sanitize_text_field( (string) ( $raw['description'] ?? '' ) ), 0, 120 ),
			'max_hours'     => $max,
			'reusable'      => ! empty( $raw['reusable'] ),
			'extend_hours'  => $ext,
			'team_requests' => ! isset( $raw['team_requests'] ) || ! empty( $raw['team_requests'] ),
			'support_scope' => in_array( $raw['support_scope'] ?? 'full', array( 'full', 'no_installs', 'no_code' ), true ) ? $raw['support_scope'] ?? 'full' : 'full',
			'screenshots'   => ! empty( $raw['screenshots'] ),
			'owner_login_email'   => ! empty( $raw['owner_login_email'] ),
			'owner_summary_email' => ! empty( $raw['owner_summary_email'] ),
			'client_history'        => ! isset( $raw['client_history'] ) || ! empty( $raw['client_history'] ),
			'client_export'         => ! isset( $raw['client_history'] ) || ! empty( $raw['client_history'] ) ? ! isset( $raw['client_export'] ) || ! empty( $raw['client_export'] ) : false,
			'client_delete_history' => ! isset( $raw['client_history'] ) || ! empty( $raw['client_history'] ) ? ! isset( $raw['client_delete_history'] ) || ! empty( $raw['client_delete_history'] ) : false,
			'client_disconnect'     => ! isset( $raw['client_disconnect'] ) || ! empty( $raw['client_disconnect'] ),
			'tool_details'          => ! isset( $raw['tool_details'] ) || ! empty( $raw['tool_details'] ),
			'tool_debug'            => ! isset( $raw['tool_debug'] ) || ! empty( $raw['tool_debug'] ),
			'tool_troubleshoot'     => ! isset( $raw['tool_troubleshoot'] ) || ! empty( $raw['tool_troubleshoot'] ),
			'tool_viewas'           => ! isset( $raw['tool_viewas'] ) || ! empty( $raw['tool_viewas'] ),
		);
	}
	/**
	 * The terms agreed with this client, when this site is connected to a support team that set them.
	 *
	 * @return array|null
	 */
	/**
	 * Whether the support team's agreement lets the site owner do something in this plugin.
	 * No agreement means no limits.
	 *
	 * @param string $what history, export, delete_history or disconnect.
	 * @return bool
	 */
	public static function client_can( $what ) {
		$ag = self::agreement();
		return ! $ag || ! array_key_exists( 'client_' . $what, $ag ) || ! empty( $ag[ 'client_' . $what ] );
	}

	public static function agreement() {
		$s = get_option( self::OPTION, array() );
		return ! empty( $s['connected'] ) && ! empty( $s['agreement']['name'] ) ? $s['agreement'] : null;
	}
	public static function hours_label( $h ) {
		$h = (int) $h;
		if ( $h <= 72 ) { return sprintf( '%d hours', $h ); }
		if ( 168 === $h ) { return '1 week'; }
		if ( 336 === $h ) { return '2 weeks'; }
		return sprintf( '%d days', (int) round( $h / 24 ) );
	}
	private static function create_policy( $id, $hours, $policy, $note ) {
		return Fixpass_Access::create( array( 'agency_request' => $id, 'hours' => $hours, 'cleanup' => false, 'reusable' => ! empty( $policy['reusable'] ), 'allow_extend' => ! empty( $policy['allow_extend'] ), 'extend_until' => gmdate( 'Y-m-d H:i:s', (int) ( $policy['extend_until'] / 1000 ) ), 'note' => $note ) );
	}
	/** Apply only authenticated hosted policy; pending extension is never advertised as completed. */
	private static function reconcile( $id, $grant, $remote ) {
		$lock = 'fixpass_agency_reconcile_' . (int) $grant['id'];
		if ( (int) get_option( $lock, 0 ) < time() - 120 ) { delete_option( $lock ); }
		if ( ! add_option( $lock, time(), '', false ) ) { return new WP_Error( 'pending', 'Access synchronization is already pending. Refresh shortly.' ); }
		try { return self::reconcile_locked( $id, Fixpass_Access::get( (int) $grant['id'] ), $remote ); }
		finally { delete_option( $lock ); }
	}
	private static function reconcile_locked( $id, $grant, $remote ) {
		global $wpdb;
		$target = (int) ( $remote['pending_until'] ?? $remote['until'] ?? 0 );
		if ( ! Fixpass_Access::is_active( $grant ) || 'approved' !== $remote['status'] || $target <= time() * 1000 ) { return new WP_Error( 'inactive', 'Access ended. Fresh owner approval is required.' ); }
		$values = array( 'expires_at' => gmdate( 'Y-m-d H:i:s', (int) ( $target / 1000 ) ) );
		if ( false === $wpdb->update( Fixpass_DB::table( 'grants' ), $values, array( 'id' => (int) $grant['id'] ) ) ) { return new WP_Error( 'pending', 'Local extension could not be saved.' ); }
		$saved = Fixpass_Access::get( (int) $grant['id'] );
		if ( ! $saved || strtotime( $saved['expires_at'] . ' UTC' ) !== (int) ( $target / 1000 ) ) { return new WP_Error( 'pending', 'Local deadline is unconfirmed.' ); }
		if ( ! empty( $remote['pending_until'] ) ) {
			$ack = self::call( 'extend', array( 'request' => $id, 'confirm' => $target ) );
			if ( is_wp_error( $ack ) || (int) ( $ack['until'] ?? 0 ) !== $target ) {
				$wpdb->update( Fixpass_DB::table( 'grants' ), array( 'expires_at' => $grant['expires_at'] ), array( 'id' => (int) $grant['id'] ) );
				return is_wp_error( $ack ) ? $ack : new WP_Error( 'pending', 'Extension confirmation pending.' );
			}
		}
		if ( $target > strtotime( $grant['expires_at'] . ' UTC' ) * 1000 && ( ! empty( $remote['pending_until'] ) || (int) ( $remote['confirmed_until'] ?? 0 ) === $target ) ) {
			Fixpass_Monitor::record( 'access', 'access_extended', '', array( 'by_support' => true, 'from' => gmdate( 'c', strtotime( $grant['expires_at'] . ' UTC' ) ), 'until' => gmdate( 'c', (int) ( $target / 1000 ) ) ), (int) $grant['id'] );
			if ( Fixpass_Owner_Mail::enabled( 'login' ) ) { wp_mail( Fixpass_Settings::notify_email(), 'Support team extended access', Fixpass_Agency::display_name() . ' extended the access you authorized. Access now ends ' . gmdate( 'Y-m-d H:i:s', (int) ( $target / 1000 ) ) . ' UTC. You can end access from Fixpass at any time.' ); }
		}
		Fixpass_Access::agency_deadline( $grant['id'], (int) ( $target / 1000 ) );
		return Fixpass_Access::get( (int) $grant['id'] );
	}
	public static function extend( $grant_id, $hours ) {
		self::sync( true );
		$state = get_option( self::OPTION, array() );
		foreach ( $state['grants'] ?? array() as $id => $local ) {
			if ( (int) $local['grant'] !== (int) $grant_id ) { continue; }
			$grant = Fixpass_Access::get( $grant_id );
			if ( ! Fixpass_Access::is_active( $grant ) ) { return new WP_Error( 'inactive', 'Access ended.' ); }
			$r = self::call( 'extend', array( 'request' => $id, 'hours' => (int) $hours, 'expected' => strtotime( $grant['expires_at'] . ' UTC' ) * 1000 ) );
			if ( is_wp_error( $r ) ) { return $r; }
			return self::reconcile( $id, $grant, array( 'status' => 'approved', 'pending_until' => $r['until'] ) );
		}
		return new WP_Error( 'missing', 'Support grant unavailable.' );
	}
	/**
	 * Whether a white-label logo is a small PNG, JPEG or WebP data URI whose bytes match its type.
	 *
	 * @param string $data Data URI.
	 * @return bool
	 */
	private static function valid_logo( $data ) {
		if ( strlen( $data ) > 100000 || ! preg_match( '#^data:image/(png|jpeg|webp);base64,([A-Za-z0-9+/]+={0,2})$#', $data, $m ) ) { return false; }
		$bytes = base64_decode( $m[2], true );
		if ( false === $bytes || strlen( $bytes ) > 65536 ) { return false; }
		$info = @getimagesizefromstring( $bytes ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged
		return is_array( $info ) && ( 'image/' . $m[1] ) === ( $info['mime'] ?? '' );
	}
	/**
	 * The connected team's logo as a menu icon (an SVG wrapper, since WordPress only accepts data URIs for SVG), or '' to keep the default.
	 *
	 * @return string
	 */
	public static function logo_icon() {
		$s    = get_option( self::OPTION, array() );
		$logo = (string) ( $s['logo'] ?? '' );
		if ( empty( $s['connected'] ) || ! self::valid_logo( $logo ) ) { return ''; }
		return 'data:image/svg+xml;base64,' . base64_encode( '<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20"><image href="' . $logo . '" width="20" height="20" preserveAspectRatio="xMidYMid meet"/></svg>' ); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_encode
	}
	/**
	 * The connected team's brand for the plugin screens: its name and a validated logo data URI. Empty strings when not connected.
	 *
	 * @return array{name:string,logo:string,subtitle:string,footer_note:string,footer_credit:bool}
	 */
	public static function brand() {
		$s = get_option( self::OPTION, array() );
		if ( empty( $s['connected'] ) ) { return array( 'name' => '', 'logo' => '', 'subtitle' => '', 'footer_note' => '', 'footer_credit' => true ); }
		$logo = (string) ( $s['logo'] ?? '' );
		return array( 'name' => ( ! isset( $s['branded'] ) || ! empty( $s['branded'] ) ) ? self::display_name() : '', 'logo' => self::valid_logo( $logo ) ? $logo : '', 'subtitle' => (string) ( $s['subtitle'] ?? '' ), 'footer_note' => (string) ( $s['footer_note'] ?? '' ), 'footer_credit' => ! isset( $s['footer_credit'] ) || ! empty( $s['footer_credit'] ) );
	}
	public static function display_name() { $s = get_option( self::OPTION, array() ); $name = (string) ( $s['agency'] ?? '' ); return $name && false === strpos( $name, '@' ) ? $name : 'Support team'; }
	public static function report( $input ) {
		if ( ! Fixpass_License::owner() ) { return new WP_Error( 'forbidden', 'Owner access required.' ); }
		$guard = Fixpass_License::guard(); if ( is_wp_error( $guard ) ) { return $guard; }
		$hours = (int) ( $input['hours'] ?? 0 );
		$policy = self::policy( $input, $hours ); if ( is_wp_error( $policy ) ) { return $policy; }
		$description = sanitize_textarea_field( $input['description'] ?? '' );
		if ( true !== ( $input['approved'] ?? false ) || strlen( $description ) < 3 || strlen( $description ) > 500 || ! isset( Fixpass_Policy::durations()[ $hours ] ) ) { return new WP_Error( 'approval', 'Describe the problem and confirm the support team and access duration.' ); }
		self::sync( true );
		$status = self::status(); if ( empty( $status['generation'] ) || ( $input['generation'] ?? '' ) !== $status['generation'] || ( $input['agency'] ?? '' ) !== $status['agency'] ) { return new WP_Error( 'connection_changed', 'Connection changed. Refresh and approve the displayed support team again.' ); } if ( empty( $status['confirmed'] ) ) { return new WP_Error( 'connection', 'Refresh your support connection before delivering a report.' ); }
		if ( (int) get_option( 'fixpass_agency_approving', 0 ) < time() - 120 ) { delete_option( 'fixpass_agency_approving' ); }
		if ( ! add_option( 'fixpass_agency_approving', time(), '', false ) ) { return new WP_Error( 'busy', 'Approval in progress. Refresh shortly.' ); }
		try {
			$ids = array_slice( array_filter( array_map( 'sanitize_key', explode( ',', $input['pins'] ?? '' ) ) ), 0, 5 );
			$fingerprint = hash( 'sha256', wp_json_encode( array( $ids, $description, $hours, $status['generation'], ! empty( $input['reusable'] ), $input['extend'] ?? true, $input['extend_days'] ?? 30, $input['extend_date'] ?? '' ) ) );
			$pending = get_option( 'fixpass_report_delivery', array() );
			if ( ( $pending['fingerprint'] ?? '' ) !== $fingerprint || (int) ( $pending['time'] ?? 0 ) < time() - 110 ) {
				$pending = array( 'fingerprint' => $fingerprint, 'time' => time(), 'key' => wp_generate_uuid4(), 'report' => Fixpass_Share::report( $ids, $description ), 'policy' => $policy );
				update_option( 'fixpass_report_delivery', $pending, false );
			}
			if ( Fixpass_Access::active() ) { return new WP_Error( 'conflict', 'End existing access before delivering a new report.' ); }
			$reserved = self::call( 'report', array( 'generation' => $status['generation'], 'key' => $pending['key'], 'hours' => $hours, 'report' => $pending['report'], 'policy' => $pending['policy'] ) );
			if ( is_wp_error( $reserved ) ) { if ( 409 === (int) $reserved->get_error_data() ) { delete_option( 'fixpass_report_delivery' ); } return $reserved; }
			$id = $reserved['id'];
			$policy = $pending['policy'];
			$created = self::create_policy( $id, $hours, $policy, 'Customer report delivered to support team' );
			if ( is_wp_error( $created ) ) { self::call( 'decision', array( 'request' => $id, 'action' => 'ended' ) ); delete_option( 'fixpass_report_delivery' ); return $created; }
			$confirmed = self::call( 'decision', array( 'request' => $id, 'action' => 'confirm', 'hours' => $hours, 'policy' => $policy ) );
			// A lost confirmation response replays the exact owner-approved policy.
			if ( is_wp_error( $confirmed ) ) { $confirmed = self::call( 'decision', array( 'request' => $id, 'action' => 'confirm', 'hours' => $hours, 'policy' => $policy ) ); }
		if ( is_wp_error( $confirmed ) ) { Fixpass_Access::revoke( (int) $created['grant']['id'] ); self::call( 'decision', array( 'request' => $id, 'action' => 'ended' ) ); delete_option( 'fixpass_report_delivery' ); return $confirmed; }
			if ( ! empty( $confirmed['until'] ) ) { $aligned = self::reconcile( $id, $created['grant'], array( 'status' => 'approved', 'until' => $confirmed['until'] ) ); if ( is_wp_error( $aligned ) ) { Fixpass_Access::revoke( (int) $created['grant']['id'] ); return $aligned; } }
			Fixpass_Share::delivered( $ids, (int) $created['grant']['id'], count( $pending['report']['spots'] ) ); delete_option( 'fixpass_report_delivery' );
			return array( 'delivered' => true, 'agency' => $status['agency'] );
		} finally { delete_option( 'fixpass_agency_approving' ); }
	}

	public static function handle() {
		if ( ! Fixpass_License::owner() ) { wp_die( 'Owner access required.' ); }
		check_admin_referer( 'fixpass_agency' );
		$result = self::action( sanitize_key( wp_unslash( $_POST['agency_action'] ?? '' ) ), wp_unslash( $_POST ) );
		if ( is_wp_error( $result ) ) { wp_die( esc_html( $result->get_error_message() ) ); }
		wp_safe_redirect( admin_url( 'admin.php?page=fixpass&setup=1' ) ); exit;
	}

	private static function approve( $id, $hours, $input ) {
		$state = get_option( self::OPTION, array() );
		if ( empty( $state['connected'] ) || isset( $state['grants'][ $id ] ) || Fixpass_Access::active() ) { return new WP_Error( 'conflict', 'Existing access or approval must end first. Refresh the request list.' ); }
		$policy = self::policy( $input, $hours ); if ( is_wp_error( $policy ) ) { return $policy; }
		$result = self::call( 'decision', array( 'request' => $id, 'action' => 'reserve', 'hours' => $hours, 'policy' => $policy ) );
		if ( is_wp_error( $result ) ) { return $result; }
		$created = self::create_policy( $id, $hours, $policy, 'Owner-approved support request' );
		if ( is_wp_error( $created ) ) { self::call( 'decision', array( 'request' => $id, 'action' => 'ended' ) ); return $created; }
		$confirmed = self::call( 'decision', array( 'request' => $id, 'action' => 'confirm', 'hours' => $hours, 'policy' => $policy ) );
		if ( is_wp_error( $confirmed ) ) { $confirmed = self::call( 'decision', array( 'request' => $id, 'action' => 'confirm', 'hours' => $hours, 'policy' => $policy ) ); }
		if ( is_wp_error( $confirmed ) ) { Fixpass_Access::revoke( (int) $created['grant']['id'] ); return $confirmed; }
		if ( ! empty( $confirmed['until'] ) ) { return self::reconcile( $id, $created['grant'], array( 'status' => 'approved', 'until' => $confirmed['until'] ) ); }
		return true;
	}
	public static function entry() {
		nocache_headers(); header( 'Referrer-Policy: no-referrer' );
		$id = sanitize_text_field( wp_unslash( $_REQUEST['request'] ?? '' ) );
		$nonce = sanitize_text_field( wp_unslash( $_REQUEST['launch'] ?? '' ) );
		if ( 'POST' === ( $_SERVER['REQUEST_METHOD'] ?? '' ) ) {
			check_admin_referer( 'fixpass_agency_entry' );
			$state = get_option( self::OPTION, array() );
			$local = $state['grants'][ $id ] ?? null;
			$grant = $local ? Fixpass_Access::get( (int) $local['grant'] ) : null;
			if ( empty( $state['connected'] ) || ( $state['url'] ?? '' ) !== self::url() || ! $grant || ! Fixpass_Access::is_active( $grant ) || ( empty( $grant['reusable'] ) && ! empty( $grant['token_used_at'] ) ) ) { wp_die( 'Access ended or already used. Ask the owner to approve a new request.' ); }
			$result = self::call( 'claim', array( 'request' => $id, 'nonce' => $nonce ) );
			if ( is_wp_error( $result ) ) { wp_die( esc_html( $result->get_error_message() ) ); }
			Fixpass_Access::agency_login( $grant, $result['limits'] ?? null );
		}
		$state   = get_option( self::OPTION, array() );
		$local   = $state['grants'][ $id ] ?? null;
		$grant   = $local ? Fixpass_Access::get( (int) $local['grant'] ) : null;
		$request = null;
		foreach ( $state['requests'] ?? array() as $r ) { if ( ( $r['id'] ?? '' ) === $id ) { $request = $r; break; } }
		$site    = wp_specialchars_decode( get_bloginfo( 'name' ), ENT_QUOTES );
		login_header( 'WordPress support' );
		echo '<style>.fxp-entry{padding:22px 24px}.fxp-entry h1{margin:0 0 2px;font-size:18px}.fxp-entry .fxp-by{margin:0 0 12px;color:#646970}.fxp-facts{margin:0 0 14px;padding:12px 0;border-top:1px solid #e3e3e3;border-bottom:1px solid #e3e3e3;display:grid;gap:8px}.fxp-facts div{display:flex;justify-content:space-between;gap:14px}.fxp-facts dt{color:#646970}.fxp-facts dd{margin:0;text-align:right;font-weight:600}.fxp-entry details{border:1px solid #dcdcde;border-radius:6px;background:#fafafa;margin:0 0 16px}.fxp-entry summary{padding:11px 12px;font-weight:600;cursor:pointer}.fxp-entry details ul{margin:0;padding:0 14px 12px 32px;display:grid;gap:5px;font-size:13px;list-style:disc}.fxp-go{display:flex;gap:8px}.fxp-go .button{flex:1;min-height:42px;display:inline-flex;align-items:center;justify-content:center;margin:0;box-sizing:border-box}</style>';
		echo '<form method="post" class="fxp-entry" action="' . esc_url( add_query_arg( 'action', 'fixpass_agency', wp_login_url() ) ) . '">';
		echo '<h1>' . esc_html( sprintf( 'Enter %s', $site ) ) . '</h1><p class="fxp-by">' . esc_html( sprintf( 'Approved by the site owner for %s', self::display_name() ) ) . '</p>';
		echo '<dl class="fxp-facts">';
		if ( $request && ! empty( $request['purpose'] ) ) { echo '<div><dt>Request</dt><dd>' . esc_html( $request['purpose'] ) . '</dd></div>'; }
		if ( $grant && ! empty( $grant['expires_at'] ) ) {
			$ends = strtotime( $grant['expires_at'] . ' UTC' );
			echo '<div><dt>Access ends</dt><dd>' . esc_html( wp_date( 'j M, H:i', $ends ) . ' (in ' . human_time_diff( time(), $ends ) . ')' ) . '</dd></div>';
			echo '<div><dt>Link</dt><dd>' . esc_html( empty( $grant['reusable'] ) ? 'One entry, used when you enter' : 'Reusable until access ends' ) . '</dd></div>';
		}
		echo '<div><dt>You may</dt><dd>' . esc_html( self::scope_label() ) . '</dd></div></dl>';
		$ag = self::agreement();
		if ( $ag ) {
			echo '<details><summary>' . esc_html( 'Agreement: ' . $ag['name'] ) . '</summary><ul>';
			foreach ( self::agreement_points( $ag ) as $point ) { echo '<li>' . esc_html( $point ) . '</li>'; }
			echo '</ul></details>';
		}
		echo '<input type="hidden" name="action" value="fixpass_agency"><input type="hidden" name="request" value="' . esc_attr( $id ) . '"><input type="hidden" name="launch" value="' . esc_attr( $nonce ) . '">';
		wp_nonce_field( 'fixpass_agency_entry' ); echo '<div class="fxp-go"><button class="button button-primary button-large">Enter site</button><a class="button button-large" href="' . esc_url( home_url( '/' ) ) . '">Not now</a></div><noscript>JavaScript is needed to read the one-use launch from your browser.</noscript></form><script src="' . esc_url( FIXPASS_URL . 'assets/agency-entry.js?ver=' . FIXPASS_VERSION ) . '"></script>'; login_footer(); exit;
	}
	/** What support may do on this site, in words. */
	public static function scope_label() {
		$ag    = self::agreement();
		$scope = $ag['support_scope'] ?? 'full';
		if ( 'no_installs' === $scope ) { return 'Work as administrator, no plugin installs'; }
		if ( 'no_code' === $scope ) { return 'Work as administrator, no installs, code edits or exports'; }
		return 'Work as a full administrator';
	}
	/** The terms of an agreement as short sentences, for the support login page. Mirrors the owner\'s agreement card in the plugin. */
	public static function agreement_points( $a ) {
		$p   = array();
		$p[] = 'Access lasts up to ' . self::hours_label( (int) $a['max_hours'] ) . ' per approval.';
		$p[] = ! empty( $a['reusable'] ) ? 'The site owner chooses a one-time or a reusable link.' : 'One-time links only: one entry per approval.';
		$p[] = ! empty( $a['extend_hours'] ) ? 'With the owner\'s permission, access can be extended up to ' . self::hours_label( (int) $a['extend_hours'] ) . ' in total.' : 'Access cannot be extended. Ask the owner again if you need more time.';
		$p[] = 'The site owner can end access at any time.';
		if ( 'no_installs' === ( $a['support_scope'] ?? '' ) ) { $p[] = 'You cannot install or delete plugins.'; }
		if ( 'no_code' === ( $a['support_scope'] ?? '' ) ) { $p[] = 'You cannot install or delete plugins, edit code files, export data or update WordPress.'; }
		if ( ! empty( $a['screenshots'] ) ) { $p[] = 'The owner may attach a screenshot; you can open it only while access is open.'; }
		$off = array();
		foreach ( array( 'tool_details' => 'Site details', 'tool_debug' => 'Debugging', 'tool_troubleshoot' => 'Troubleshoot mode', 'tool_viewas' => 'View as' ) as $key => $label ) {
			if ( isset( $a[ $key ] ) && ! $a[ $key ] ) { $off[] = $label; }
		}
		if ( $off ) { $p[] = 'Not available to you under this agreement: ' . implode( ', ', $off ) . '.'; }
		$p[] = 'Your team role can narrow this further, never widen it.';
		$p[] = 'Each session is recorded, including what is changed.';
		return $p;
	}
	private static function form( $action, $label, $id = '', $hours = 0 ) {
		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">'; wp_nonce_field( 'fixpass_agency' );
		echo '<input type="hidden" name="action" value="fixpass_agency"><input type="hidden" name="agency_action" value="' . esc_attr( $action ) . '"><input type="hidden" name="request_id" value="' . esc_attr( $id ) . '"><input type="hidden" name="hours" value="' . (int) $hours . '"><p><button class="button">' . esc_html( $label ) . '</button></p></form>';
	}
	public static function render() { Fixpass_License::legacy_redirect(); }
}
