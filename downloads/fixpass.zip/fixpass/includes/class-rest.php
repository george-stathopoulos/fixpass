<?php
/**
 * REST API for the plugin's two screens.
 *
 * @package Fixpass
 */

defined( 'ABSPATH' ) || exit;

/**
 * Two audiences, kept apart:
 * - The site owner (administrators): create a support link, end access, turn Spotlight on or off.
 * - Support, while logged in with a link: the session, site details, debugging tools and
 *   troubleshooting mode. Administrators of the site don't get these.
 */
final class Fixpass_REST {

	const NS = 'fixpass/v1';

	/**
	 * Register routes.
	 */
	public static function register() {
		$owner   = static function () {
			return current_user_can( Fixpass_Access::CAP ) && ! Fixpass_Access::current_grant_id();
		};
		$support = static function () {
			return Fixpass_Access::current_grant_id() > 0;
		};
		$routes  = array(
			array( '/admin/setup', 'GET', 'setup', $owner ),
			array( '/admin/license', 'POST', 'license_action', $owner ),
			array( '/admin/agency', 'POST', 'agency_action', $owner ),
			array( '/admin/state', 'GET', 'state', $owner ),
			array( '/admin/link', 'POST', 'link', $owner ),
			array( '/admin/report', 'POST', 'report', $owner ),
			array( '/admin/end', 'POST', 'end', $owner ),
			array( '/admin/copy', 'POST', 'copy', $owner ),
			array( '/admin/extend', 'POST', 'extend', $owner ),
			array( '/admin/spotlight', 'POST', 'spotlight', $owner ),
			array( '/admin/onboarding', 'POST', 'onboarding', $owner ),
			array( '/admin/activity', 'GET', 'activity', $owner ),
			array( '/admin/messages', 'GET', 'messages', $owner ),
			array( '/admin/messages/read', 'POST', 'messages_read', $owner ),
			array( '/admin/activity/clear', 'POST', 'activity_clear', $owner ),
			array( '/admin/retention', 'POST', 'retention', $owner ),
			array( '/admin/session', 'GET', 'session', $support ),
			array( '/admin/session/message', 'POST', 'session_message', $support ),
			array( '/admin/session/extend', 'POST', 'extend_session', $support ),
			array( '/admin/session/leave', 'POST', 'leave_session', $support ),
			array( '/admin/session/end', 'POST', 'end_session', $support ),
			array( '/admin/health', 'GET', 'health', $support ),
			array( '/admin/debug', 'GET', 'debug', $support ),
			array( '/admin/troubleshoot', 'GET', 'troubleshoot', $support ),
			array( '/admin/troubleshoot', 'POST', 'troubleshoot_set', $support ),
			array( '/admin/roleview', 'GET', 'roleview', $support ),
			array( '/admin/roleview', 'POST', 'roleview_set', $support ),
		);
		foreach ( $routes as $r ) {
			register_rest_route(
				self::NS,
				$r[0],
				array(
					'methods'             => $r[1],
					'callback'            => array( __CLASS__, $r[2] ),
					'permission_callback' => static function ( $request ) use ( $r ) {
						if ( ! call_user_func( $r[3] ) ) { return false; }
						// Support tools can be switched off by the website's agreement or by the member's team role. Stopping what is already running stays possible.
						$tools = array( 'health' => 'details', 'debug' => 'debug', 'troubleshoot' => 'troubleshoot', 'troubleshoot_set' => 'troubleshoot', 'roleview' => 'viewas', 'roleview_set' => 'viewas' );
						if ( isset( $tools[ $r[2] ] ) && 'POST' === $r[1] && 'stop' === $request->get_param( 'op' ) ) { return true; }
						if ( isset( $tools[ $r[2] ] ) && ! Fixpass_Access::tool_allowed( $tools[ $r[2] ] ) ) { return false; }
						if ( in_array( $r[2], array( 'setup', 'license_action', 'agency_action', 'state', 'end', 'session', 'session_message', 'leave_session', 'end_session', 'activity', 'messages', 'messages_read' ), true ) ) { return true; }
						return Fixpass_License::guard();
					},
				)
			);
		}
	}

	/**
	 * What the site owner's screen shows.
	 *
	 * @return array
	 */
	public static function state() {
		$durations = array();
		foreach ( Fixpass_Policy::durations() as $hours => $label ) {
			$durations[] = array(
				'hours' => $hours,
				'label' => $label,
			);
		}
		// The latest access, active or not: its status is what the owner sees.
		$latest = Fixpass_Access::all( false, 1 );
		$g      = $latest ? $latest[0] : null;
		return array(
			'ready' => ! is_wp_error( Fixpass_License::guard() ),
			'agency' => Fixpass_Agency::status(),
			'spotlight'     => Fixpass_Settings::spotlight_enabled(),
			'retention_days' => Fixpass_Settings::get( 'retention_days' ),
			// The welcome tour stays hidden once dismissed, until Fixpass is reinstalled.
			'onboarded'     => (bool) get_option( 'fixpass_onboarded' ),
			'durations'     => $durations,
			// The default is 3 days, or the longest the agreement allows when that is shorter.
			'default_hours' => $durations ? min( Fixpass_Policy::DEFAULT_HOURS, max( array_column( $durations, 'hours' ) ) ) : Fixpass_Policy::DEFAULT_HOURS,
			'now'           => gmdate( 'c' ),
			'access'        => $g ? array(
				'active'     => Fixpass_Access::is_active( $g ),
				'status'     => Fixpass_Access::status( $g ),
				'granted_at' => self::iso( $g['created_at'] ),
				'number'     => Fixpass_Agency::number( (int) $g['id'] ),
				'extensions' => self::extensions( (int) $g['id'] ),
				'worked'     => self::worked( $g ),
				'expires_at' => self::iso( $g['expires_at'] ),
				'ended_at'   => self::iso( $g['revoked_at'] ),
				'copied'     => ! empty( $g['copied_at'] ),
				'cleanup'    => ! empty( $g['cleanup'] ),
				'reusable'   => ! empty( $g['reusable'] ),
				'allow_extend' => ! empty( $g['allow_extend'] ),
				'extend_until' => ! empty( $g['allow_extend'] ) ? self::iso( gmdate( 'Y-m-d H:i:s', Fixpass_Access::extend_limit( $g ) ) ) : null,
				// Extending stops 30 days after access was created.
				'agency' => Fixpass_Agency::owns( (int) $g['id'] ),
				'report' => 'Customer report delivered to support team' === ( $g['note'] ?? '' ),
				'can_extend' => ! Fixpass_Agency::owns( (int) $g['id'] ) && strtotime( $g['expires_at'] . ' UTC' ) < strtotime( $g['created_at'] . ' UTC' ) + Fixpass_Policy::MAX_TOTAL_DAYS * DAY_IN_SECONDS,
			) : null,
			'removing'      => ! ( $g && Fixpass_Access::is_active( $g ) ) && wp_next_scheduled( Fixpass_Plugin::SELF_REMOVE ),
		);
	}

	/**
	 * Every approved extension of an access, oldest first. The original end is the first extension's starting point.
	 *
	 * @param int $grant_id Access.
	 * @return array[] time, from (ISO or null for older entries), until (ISO or null), hours, by (support|owner).
	 */
	private static function extensions( $grant_id ) {
		global $wpdb;
		$rows = $wpdb->get_results( $wpdb->prepare( "SELECT details, created_at FROM %i WHERE grant_id = %d AND action = 'access_extended' ORDER BY id ASC LIMIT 50", Fixpass_DB::table( 'log' ), $grant_id ), ARRAY_A ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$out  = array();
		foreach ( (array) $rows as $row ) {
			$d     = (array) json_decode( (string) $row['details'], true );
			$out[] = array(
				'time'  => self::iso( $row['created_at'] ),
				'from'  => ! empty( $d['from'] ) ? (string) $d['from'] : null,
				'until' => ! empty( $d['until'] ) ? (string) $d['until'] : null,
				'hours' => (int) ( $d['hours'] ?? 0 ),
				'by'    => ! empty( $d['by_support'] ) ? 'support' : 'owner',
			);
		}
		return $out;
	}

	/**
	 * Seconds support was logged in during an access: each login until its logout, or until the access ended.
	 *
	 * @param array $grant Access.
	 * @return int
	 */
	private static function worked( array $grant ) {
		global $wpdb;
		$rows  = $wpdb->get_results( $wpdb->prepare( "SELECT action, created_at FROM %i WHERE grant_id = %d AND action IN ('support_login','support_logout') ORDER BY id ASC LIMIT 1000", Fixpass_DB::table( 'log' ), (int) $grant['id'] ), ARRAY_A ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$end   = ! empty( $grant['revoked_at'] ) ? strtotime( $grant['revoked_at'] . ' UTC' ) : min( time(), strtotime( $grant['expires_at'] . ' UTC' ) );
		$start = 0;
		$total = 0;
		foreach ( (array) $rows as $row ) {
			$at = strtotime( $row['created_at'] . ' UTC' );
			if ( 'support_login' === $row['action'] ) {
				if ( ! $start ) { $start = $at; }
			} elseif ( $start ) {
				$total += max( 0, $at - $start );
				$start  = 0;
			}
		}
		if ( $start ) { $total += max( 0, $end - $start ); }
		return $total;
	}

	public static function report( WP_REST_Request $r ) { $out = Fixpass_Agency::report( $r->get_json_params() ); return is_wp_error( $out ) ? self::bad( $out ) : $out; }

	public static function setup() { Fixpass_License::maybe_refresh(); return array( 'license' => Fixpass_License::status(), 'agency' => Fixpass_Agency::status(), 'ready' => Fixpass_License::ready() ); }
	/** An agreement can take Disconnect away from the site owner in this plugin. */
	private static function disconnect_blocked( $action ) { return 'disconnect' === $action && ! Fixpass_Agency::client_can( 'disconnect' ) ? new WP_Error( 'agreement', __( 'Your agreement with your support team does not allow disconnecting from this screen.', 'fixpass' ), array( 'status' => 403 ) ) : null; }
	public static function license_action( WP_REST_Request $r ) { $blocked = self::disconnect_blocked( sanitize_key( $r['action'] ) ); if ( $blocked ) { return self::bad( $blocked ); } $out = Fixpass_License::action( sanitize_key( $r['action'] ), $r['key'] ); return is_wp_error( $out ) ? self::bad( $out ) : self::setup(); }
	public static function agency_action( WP_REST_Request $r ) { $blocked = self::disconnect_blocked( sanitize_key( $r['action'] ) ); if ( $blocked ) { return self::bad( $blocked ); } $out = Fixpass_Agency::action( sanitize_key( $r['action'] ), $r->get_json_params() ); if ( is_wp_error( $out ) ) { return self::bad( $out ); } return 'inspect' === $r['action'] ? $out : self::setup(); }

	/**
	 * Create a support link (new access, or renew the current one with a fresh link).
	 *
	 * @param WP_REST_Request $request hours, pins (comma-separated).
	 * @return array|WP_Error
	 */
	public static function link( WP_REST_Request $request ) {
		$hours     = absint( $request->get_param( 'hours' ) );
		$extend    = array();
		$reusable  = null === $request->get_param( 'reusable' ) || rest_sanitize_boolean( $request->get_param( 'reusable' ) );
		$agreement = Fixpass_Agency::agreement();
		if ( $agreement ) {
			if ( $hours > $agreement['max_hours'] ) {
				return self::bad( new WP_Error( 'agreement', sprintf( 'Your agreement with %1$s (%2$s) allows up to %3$s of access. Choose a shorter time.', Fixpass_Agency::display_name(), $agreement['name'], Fixpass_Agency::hours_label( $agreement['max_hours'] ) ) ) );
			}
			if ( $reusable && ! $agreement['reusable'] ) {
				return self::bad( new WP_Error( 'agreement', sprintf( 'Your agreement with %1$s (%2$s) allows one entry per approval. Choose a one-time link.', Fixpass_Agency::display_name(), $agreement['name'] ) ) );
			}
		}
		if ( rest_sanitize_boolean( $request->get_param( 'extend' ) ) && ( ! $agreement || $agreement['extend_hours'] > 0 ) ) {
			$until = Fixpass_Access::parse_extend_limit( absint( $request->get_param( 'extend_days' ) ), sanitize_text_field( (string) $request->get_param( 'extend_date' ) ), $hours );
			if ( is_wp_error( $until ) ) {
				return self::bad( $until );
			}
			if ( $agreement ) {
				$cap = time() + $agreement['extend_hours'] * HOUR_IN_SECONDS;
				if ( strtotime( $until . ' UTC' ) > $cap ) {
					$until = gmdate( 'Y-m-d H:i:s', $cap );
				}
			}
			$extend = array(
				'allow' => true,
				'until' => $until,
			);
		}
		$out = Fixpass_Share::create( $hours, explode( ',', (string) $request->get_param( 'pins' ) ), rest_sanitize_boolean( $request->get_param( 'cleanup' ) ), $reusable, $extend );
		return is_wp_error( $out ) ? self::bad( $out ) : $out;
	}

	/**
	 * Step 2: the details were copied. With fresh=1 (after a reload, when the page no longer has
	 * the link), a new link is made and the message returned.
	 *
	 * @param WP_REST_Request $request fresh.
	 * @return array|WP_Error
	 */
	public static function copy( WP_REST_Request $request ) {
		$out = array();
		if ( rest_sanitize_boolean( $request->get_param( 'fresh' ) ) ) {
			$out = Fixpass_Share::fresh();
			if ( is_wp_error( $out ) ) {
				return self::bad( $out );
			}
		}
		Fixpass_Share::mark_copied();
		return $out;
	}

	/**
	 * Extend the access by 24 hours (up to 30 days from when it was created).
	 *
	 * @return array|WP_Error
	 */
	public static function extend() {
		$g = Fixpass_Access::active();
		if ( ! $g || ! Fixpass_Access::extend( (int) $g['id'], 24 ) ) {
			return self::bad( new WP_Error( 'fixpass_extend', __( 'This access can’t be extended: it has ended, or it already reaches 30 days from when it was created.', 'fixpass' ) ) );
		}
		return self::state();
	}

	/**
	 * The site owner ends access now.
	 *
	 * @return array
	 */
	public static function end() {
		$g = Fixpass_Access::active();
		if ( $g ) {
			Fixpass_Access::revoke( (int) $g['id'] );
		}
		return self::state();
	}

	/**
	 * Don't show the welcome tour again (or show it again, with done=false).
	 *
	 * @param WP_REST_Request $request done.
	 * @return array
	 */
	public static function onboarding( WP_REST_Request $request ) {
		update_option( 'fixpass_onboarded', rest_sanitize_boolean( $request->get_param( 'done' ) ), false );
		return self::state();
	}

	/**
	 * The access history for the site owner: access given, extended, ended, when support logged
	 * in and out, and what support did. Newest first.
	 *
	 * @return array { events[] }
	 */
	public static function activity() {
		if ( ! Fixpass_Agency::client_can( 'history' ) ) {
			return new WP_Error( 'agreement', __( 'Your agreement with your support team does not include the access history here.', 'fixpass' ), array( 'status' => 403 ) );
		}
		$events = array();
		foreach ( Fixpass_Monitor::query(
			array(
				'type'       => array( 'access', 'activity', 'change' ),
				'grant_only' => true,
				'limit'      => 300,
			)
		) as $row ) {
			$line     = Fixpass_Activity::owner_line( $row );
			$events[] = array(
				'id'    => (int) $row['id'],
				'grant_id' => (int) ( $row['grant_id'] ?? 0 ),
				'session' => Fixpass_Agency::number( (int) ( $row['grant_id'] ?? 0 ) ),
				'active' => Fixpass_Access::is_active( Fixpass_Access::get( (int) ( $row['grant_id'] ?? 0 ) ) ),
				'time'  => self::iso( $row['created_at'] ),
				'who'   => $line['who'],
				'actor' => $line['actor'],
				'event' => $line['text'],
				'tone'  => $line['tone'],
				'key'   => $line['key'],
				'ip'    => 'support_login' === $row['action'] ? (string) $row['ip'] : '',
				// Pages support only looked at: hidden unless asked for.
				'minor' => 'page_view' === $row['action'],
			);
		}
		return array( 'events' => $events, 'partial' => count( $events ) >= 300 );
	}

	/**
	 * Messages from support. Always available: they are not part of the access history option.
	 *
	 * @return array
	 */
	public static function messages() {
		$list = Fixpass_Inbox::messages( 50 );
		foreach ( $list as &$m ) { $m['time'] = self::iso( $m['time'] ); }
		return array( 'messages' => $list, 'support' => Fixpass_Inbox::support_presence() );
	}

	/**
	 * The owner has seen the messages.
	 *
	 * @return array
	 */
	public static function messages_read() {
		Fixpass_Inbox::mark_read();
		return array( 'ok' => true );
	}

	/**
	 * Delete the access history.
	 *
	 * @return array
	 */
	public static function activity_clear() {
		if ( ! Fixpass_Agency::client_can( 'delete_history' ) ) {
			return new WP_Error( 'agreement', __( 'Your agreement with your support team does not allow deleting the access history.', 'fixpass' ), array( 'status' => 403 ) );
		}
		Fixpass_Monitor::clear_history();
		return self::state();
	}

	/**
	 * How long the access history is kept.
	 *
	 * @param WP_REST_Request $request days.
	 * @return array|WP_Error
	 */
	public static function retention( WP_REST_Request $request ) {
		if ( ! Fixpass_Agency::client_can( 'delete_history' ) ) {
			return new WP_Error( 'agreement', __( 'Your agreement with your support team does not allow changing how long the history is kept.', 'fixpass' ), array( 'status' => 403 ) );
		}
		if ( ! Fixpass_Settings::set_retention( absint( $request->get_param( 'days' ) ) ) ) {
			return new WP_Error( 'fixpass_retention', __( 'Choose 30, 90 or 365 days.', 'fixpass' ), array( 'status' => 400 ) );
		}
		return self::state();
	}

	/**
	 * Legacy Spotlight preference endpoint; Spotlight remains enabled.
	 *
	 * @param WP_REST_Request $request enabled.
	 * @return array
	 */
	public static function spotlight( WP_REST_Request $request ) {
		if ( rest_sanitize_boolean( $request->get_param( 'enabled' ) ) ) {
			$license = Fixpass_License::guard();
			if ( is_wp_error( $license ) ) { return $license; }
		}
		Fixpass_Settings::set_spotlight( rest_sanitize_boolean( $request->get_param( 'enabled' ) ) );
		return self::state();
	}

	/**
	 * The support session: until when, and what the site owner flagged.
	 *
	 * @return array
	 */
	public static function session() {
		$grant = Fixpass_Access::current_grant();
		$ready = ! is_wp_error( Fixpass_License::guard() );
		return array(
			'site'    => wp_specialchars_decode( get_bloginfo( 'name' ), ENT_QUOTES ),
			'user'    => Fixpass_Agency::owns( (int) $grant['id'] ) ? Fixpass_Agency::display_name() : wp_get_current_user()->display_name,
			'messages' => self::session_messages( (int) $grant['id'] ),
			'expires' => self::iso( $grant['expires_at'] ),
			'reusable' => ! empty( $grant['reusable'] ),
			'extend'  => $ready ? Fixpass_Access::extend_info( $grant ) : array( 'allowed' => false, 'room' => false ),
			'shared'  => $ready ? Fixpass_Share::last() : array( 'spots' => array(), 'time' => null ),
		);
	}

	/** Messages live in the retained grant activity; nullable unique keys make retries atomic. */
	private static function session_messages( $grant ) {
		global $wpdb;
		$rows = $wpdb->get_results( $wpdb->prepare( "SELECT details, created_at FROM %i WHERE grant_id = %d AND action = 'support_message' ORDER BY id DESC LIMIT 100", Fixpass_DB::table( 'log' ), $grant ), ARRAY_A );
		return array_map( static function ( $row ) { $d = json_decode( $row['details'], true ); return array( 'text' => $d['message'], 'by' => $d['by'], 'time' => self::iso( $row['created_at'] ) ); }, $rows );
	}
	public static function session_message( WP_REST_Request $request ) {
		global $wpdb;
		$grant = Fixpass_Access::current_grant();
		$text = $request->get_param( 'text' );
		$operation = $request->get_param( 'operation' );
		if ( ! $grant || ! Fixpass_Access::is_active( $grant ) ) { return new WP_Error( 'session', 'Access has ended.', array( 'status' => 403 ) ); }
		if ( ! is_string( $text ) || ! preg_match( '/\S/u', $text ) || strlen( $text ) > 8000 || preg_match_all( '/./us', $text ) > 2000 || ! is_string( $operation ) || ! preg_match( '/^[a-zA-Z0-9-]{16,80}$/D', $operation ) ) { return new WP_Error( 'message', 'Enter a plain-text message of 1–2,000 characters.', array( 'status' => 400 ) ); }
		$key = hash( 'sha256', $grant['id'] . ':' . $operation );
		$by = Fixpass_Agency::owns( (int) $grant['id'] ) ? Fixpass_Agency::display_name() : wp_get_current_user()->display_name;
		$details = wp_json_encode( array( 'message' => $text, 'by' => $by ) );
		$wpdb->query( $wpdb->prepare( "INSERT IGNORE INTO %i (type, grant_id, actor_id, action, details, message_key, created_at) VALUES ('activity', %d, %d, 'support_message', %s, %s, %s)", Fixpass_DB::table( 'log' ), $grant['id'], get_current_user_id(), $details, $key, Fixpass_DB::now() ) );
		$saved = $wpdb->get_var( $wpdb->prepare( 'SELECT details FROM %i WHERE message_key = %s AND grant_id = %d', Fixpass_DB::table( 'log' ), $key, $grant['id'] ) );
		$d = json_decode( (string) $saved, true );
		if ( ! $d || $d['message'] !== $text ) { return new WP_Error( 'message_save', 'Message could not be saved. Retry with the same draft, or explicitly skip.', array( 'status' => 409 ) ); }
		return array( 'saved' => true );
	}

	/**
	 * Support extends their access by 1 or 24 hours, when the site owner allowed it.
	 *
	 * @param WP_REST_Request $request hours.
	 * @return array|WP_Error
	 */
	public static function extend_session( WP_REST_Request $request ) {
		$out = Fixpass_Access::extend_by_support( Fixpass_Access::current_grant_id(), absint( $request->get_param( 'hours' ) ) );
		return is_wp_error( $out ) ? self::bad( $out ) : self::session();
	}

	/**
	 * Support ends the session: logged out, access stays open until it expires or is ended.
	 *
	 * @return array
	 */
	public static function leave_session() {
		$grant_id = Fixpass_Access::current_grant_id();
		wp_logout();
		Fixpass_Access::set_status( $grant_id, 'left' );
		return array( 'redirect' => home_url( '/' ) );
	}

	/**
	 * Support ends their own access: the grant is revoked and the support account deleted.
	 *
	 * @return array
	 */
	public static function end_session() {
		Fixpass_Access::revoke( Fixpass_Access::current_grant_id(), 'support_ended', wp_get_current_user()->display_name );
		return array(
			'ended'    => true,
			'redirect' => home_url( '/' ),
		);
	}

	/**
	 * Site details and the problems they point at.
	 *
	 * @return array
	 */
	public static function health() {
		$license = Fixpass_License::guard();
		if ( is_wp_error( $license ) ) { return $license; }
		$data  = Fixpass_Diagnostics::collect();
		$flags = Fixpass_Health_Flags::evaluate( $data );
		return array(
			'data'  => $data,
			'flags' => $flags,
			'text'  => Fixpass_Diagnostics::to_text( $data, $flags ),
		);
	}

	/**
	 * Debugging tools.
	 *
	 * @param WP_REST_Request $request lines, search.
	 * @return array
	 */
	public static function debug( WP_REST_Request $request ) {
		$license = Fixpass_License::guard();
		if ( is_wp_error( $license ) ) { return $license; }
		return Fixpass_Debug::state( absint( $request->get_param( 'lines' ) ) ?: 200, sanitize_text_field( (string) $request->get_param( 'search' ) ) ); // phpcs:ignore Universal.Operators.DisallowShortTernary.Found
	}

	/**
	 * Troubleshooting mode state.
	 *
	 * @return array
	 */
	public static function troubleshoot() {
		return Fixpass_Safe_Mode::state();
	}

	/**
	 * Start or stop troubleshooting mode.
	 *
	 * @param WP_REST_Request $request op, keep, theme.
	 * @return array|WP_Error
	 */
	public static function troubleshoot_set( WP_REST_Request $request ) {
		if ( 'stop' === $request->get_param( 'op' ) ) {
			return Fixpass_Safe_Mode::stop();
		}
		return Fixpass_Safe_Mode::start( array_map( 'sanitize_text_field', (array) $request->get_param( 'keep' ) ), (bool) $request->get_param( 'theme' ) );
	}

	/**
	 * Which roles support can preview the site as, and which one they are viewing now.
	 *
	 * @return array
	 */
	public static function roleview() {
		return Fixpass_Role_View::state();
	}

	/**
	 * Start or stop viewing the site as another role.
	 *
	 * @param WP_REST_Request $request op, role.
	 * @return array|WP_Error
	 */
	public static function roleview_set( WP_REST_Request $request ) {
		if ( 'stop' === $request->get_param( 'op' ) ) {
			return Fixpass_Role_View::stop();
		}
		return Fixpass_Role_View::start( sanitize_key( (string) $request->get_param( 'role' ) ) );
	}

	/**
	 * ISO 8601 from a UTC MySQL date.
	 *
	 * @param string|null $mysql Date.
	 * @return string|null
	 */
	private static function iso( $mysql ) {
		return $mysql ? gmdate( 'c', strtotime( $mysql . ' UTC' ) ) : null;
	}

	/**
	 * Error with an HTTP 400 status.
	 *
	 * @param WP_Error $error Error.
	 * @return WP_Error
	 */
	private static function bad( WP_Error $error ) {
		$error->add_data( array( 'status' => 400 ) );
		return $error;
	}
}
