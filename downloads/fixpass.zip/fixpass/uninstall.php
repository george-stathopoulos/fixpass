<?php
/**
 * Uninstall: delete support accounts, tables and options.
 *
 * @package Fixpass
 */

defined( 'WP_UNINSTALL_PLUGIN' ) || exit;

global $wpdb;

// Any remaining support accounts (deactivation normally removed them already).
$fixpass_users = get_users(
	array(
		'meta_key' => 'fixpass_grant', // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key
		'fields'   => 'ID',
	)
);
if ( $fixpass_users ) {
	require_once ABSPATH . 'wp-admin/includes/user.php';
	foreach ( $fixpass_users as $fixpass_user ) {
		wp_delete_user( (int) $fixpass_user );
	}
}

// Best effort: tell FixHub this site no longer runs the plugin, before the saved credential is deleted.
$fixpass_license = get_option( 'fixpass_prototype_license', array() );
$fixpass_agency  = get_option( 'fixpass_agency', array() );
if ( ! empty( $fixpass_license['credential'] ) && ! empty( $fixpass_agency['connected'] ) ) {
	if ( ! class_exists( 'Fixpass_License' ) ) {
		require_once __DIR__ . '/includes/class-license.php';
	}
	Fixpass_License::request( 'agency-site/offline', array( 'credential' => $fixpass_license['credential'], 'url' => untrailingslashit( home_url( '/' ) ), 'reason' => 'removed' ) );
}

foreach ( array( 'grants', 'log' ) as $fixpass_table ) {
	$wpdb->query( $wpdb->prepare( 'DROP TABLE IF EXISTS %i', $wpdb->prefix . 'fixpass_' . $fixpass_table ) ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.DirectDatabaseQuery.SchemaChange, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
}

delete_metadata( 'user', 0, 'fixpass_messages_seen', '', true );

$wpdb->query( $wpdb->prepare( 'DELETE FROM %i WHERE option_name LIKE %s', $wpdb->options, $wpdb->esc_like( 'fixpass_shot_' ) . '%' ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- screenshots go with the plugin.

foreach ( array( 'fixpass_settings', 'fixpass_db', 'fixpass_troubleshoot', 'fixpass_pins', 'fixpass_shared', 'fixpass_last_shared', 'fixpass_onboarded', 'fixpass_creating', 'fixpass_prototype_license', 'fixpass_prototype_testing', 'fixpass_pairing', 'fixpass_agency', 'fixpass_agency_approving' ) as $fixpass_option ) {
	delete_option( $fixpass_option );
}

$fixpass_mu = WPMU_PLUGIN_DIR . '/fixpass-troubleshoot.php';
if ( file_exists( $fixpass_mu ) ) {
	wp_delete_file( $fixpass_mu );
}

foreach ( array( 'fixpass_prune', 'fixpass_expire_access', 'fixpass_self_remove', 'fixpass_agency_sync' ) as $fixpass_hook ) {
	wp_clear_scheduled_hook( $fixpass_hook );
}
