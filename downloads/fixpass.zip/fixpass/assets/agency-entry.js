// Launch secret stays in the browser fragment / POST body, outside server URL logs.
(()=>{const input=document.querySelector('input[name="launch"]');if(!input)return;const nonce=new URLSearchParams(location.hash.slice(1)).get('launch');if(nonce){input.value=nonce;history.replaceState(null,'',location.pathname+location.search);}})();
