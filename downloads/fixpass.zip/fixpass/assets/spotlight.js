/**
 * Fixpass Spotlight: pick the spot that has a problem (click an element or drag a box)
 * and take it to Fixpass; or, from a support link (?fxp_spot=), highlight that spot.
 *
 * Plain JavaScript on purpose: it runs on any front-end or admin page, without React.
 */
( function () {
	'use strict';

	var cfg = window.fixpassSpotlight || {};
	var t = cfg.i18n || {};
	var PREFIX = 'fxp-pin';
	// Marks Pinpoint's own overlay, so picking ignores it (page classes may start with "fxp-pin" too).
	var MARK = 'fxp-pin-ui';

	function el( tag, cls, text ) {
		var n = document.createElement( tag );
		if ( cls ) {
			n.className = cls + ' ' + MARK;
		}
		if ( text ) {
			n.textContent = text;
		}
		return n;
	}

	function ours( node ) {
		while ( node && node !== document.body ) {
			if ( node.id === 'wpadminbar' || ( node.classList && node.classList.contains( MARK ) ) ) {
				return true;
			}
			node = node.parentNode;
		}
		return false;
	}

	// Elements that differ between visitors (the admin toolbar, Pinpoint's own overlay) or that
	// aren't part of the layout: never counted when finding an element again.
	function counts( n ) {
		return (
			n.nodeType === 1 &&
			n.id !== 'wpadminbar' &&
			! ( n.classList && n.classList.contains( MARK ) ) &&
			[ 'SCRIPT', 'STYLE', 'LINK', 'NOSCRIPT', 'TEMPLATE', 'META' ].indexOf( n.tagName ) === -1
		);
	}

	function stableClasses( n ) {
		return ( n.getAttribute( 'class' ) || '' )
			.split( /\s+/ )
			.filter( function ( c ) {
				return c && /^[A-Za-z][\w-]*$/.test( c ) && ! /\d{3,}|active|hover|focus|open|selected|current|logged-in|admin-bar/.test( c );
			} )
			.slice( 0, 2 );
	}

	/**
	 * The way back to an element from <body>: tag, stable classes and position among siblings
	 * of the same tag (not counting the admin toolbar and other per-visitor elements), or an ID.
	 *
	 * @param {Element} node Element.
	 * @return {Array} Steps [ { t, c, i, id } ].
	 */
	function pathFor( node ) {
		var steps = [];
		while ( node && node.nodeType === 1 && node !== document.body && node !== document.documentElement && steps.length < 10 ) {
			if ( node.id && /^[A-Za-z][\w-]*$/.test( node.id ) && document.querySelectorAll( '#' + node.id ).length === 1 ) {
				steps.unshift( { id: node.id } );
				break;
			}
			var parent = node.parentElement;
			var same = parent
				? Array.prototype.filter.call( parent.children, function ( c ) {
						return counts( c ) && c.tagName === node.tagName;
				  } )
				: [ node ];
			steps.unshift( { t: node.tagName.toLowerCase(), c: stableClasses( node ), i: same.indexOf( node ) } );
			node = parent;
		}
		return steps;
	}

	/**
	 * Find an element again from its path (see pathFor).
	 *
	 * @param {Array} steps Steps.
	 * @return {Element|null} Element.
	 */
	function resolvePath( steps ) {
		var node = document.body;
		for ( var k = 0; k < steps.length && node; k++ ) {
			var step = steps[ k ];
			if ( step.id ) {
				node = document.getElementById( step.id );
				continue;
			}
			var same = Array.prototype.filter.call( node.children, function ( c ) {
				return counts( c ) && c.tagName.toLowerCase() === step.t;
			} );
			var withClasses = same.filter( function ( c ) {
				return ( step.c || [] ).every( function ( cls ) {
					return c.classList.contains( cls );
				} );
			} );
			// The only one with those classes wins; otherwise the same position as before.
			node = withClasses.length === 1 ? withClasses[ 0 ] : same[ step.i ] || withClasses[ 0 ] || null;
		}
		return node && node !== document.body ? node : null;
	}

	/**
	 * A readable description of where the element is (shown to support).
	 *
	 * @param {Array} steps Steps.
	 * @return {string} Selector-like text.
	 */
	function describe( steps ) {
		return steps
			.map( function ( st ) {
				return st.id ? '#' + st.id : st.t + ( st.c && st.c.length ? '.' + st.c.join( '.' ) : '' );
			} )
			.join( ' > ' );
	}

	function pageRect( r ) {
		return {
			x: r.left + window.scrollX,
			y: r.top + window.scrollY,
			w: r.width,
			h: r.height,
		};
	}

	function place( box, r ) {
		box.style.left = r.left + 'px';
		box.style.top = r.top + 'px';
		box.style.width = r.width + 'px';
		box.style.height = r.height + 'px';
	}

	/* ---------------------------------------------------------------- Picking a spot */

	function pick() {
		if ( ! cfg.can || submitting || ! localPage( window.location.href ) ) { return; }
		if ( session && session.spots.length >= 5 ) { showPanel(); return; }
		clearPanel();
		if ( document.querySelector( '.' + PREFIX + '-layer' ) ) {
			return;
		}
		var layer = el( 'div', PREFIX + '-layer' );
		var hl = el( 'div', PREFIX + '-box' );
		var tip = el( 'div', PREFIX + '-tip', t.pick );
		var cancelBtn = el( 'button', PREFIX + '-btn', t.cancel );
		cancelBtn.type = 'button';
		if ( cfg.shots ) {
			var onlyBtn = el( 'button', PREFIX + '-btn', t.shotOnly );
			onlyBtn.type = 'button';
			onlyBtn.addEventListener( 'click', function () { stop(); screenshotOnly(); } );
			tip.appendChild( onlyBtn );
		}
		tip.appendChild( cancelBtn );
		document.body.appendChild( layer );
		document.body.appendChild( hl );
		document.body.appendChild( tip );
		hl.style.display = 'none';

		var start = null;
		var current = null;

		function under( x, y ) {
			layer.style.pointerEvents = 'none';
			hl.style.display = 'none';
			var node = document.elementFromPoint( x, y );
			layer.style.pointerEvents = '';
			return node && ! ours( node ) ? node : null;
		}

		function stop() {
			[ layer, hl, tip ].forEach( function ( n ) {
				if ( n.parentNode ) {
					n.parentNode.removeChild( n );
				}
			} );
			document.removeEventListener( 'keydown', onKey, true );
		}

		function onKey( e ) {
			if ( e.key === 'Escape' ) {
				e.preventDefault();
				stop();
				// Picking another spot was cancelled: back to the spots picked so far.
				if ( session && session.spots.length ) {
					showPanel();
				}
			}
		}

		layer.addEventListener( 'mousemove', function ( e ) {
			if ( start ) {
				var r = {
					left: Math.min( start.x, e.clientX ),
					top: Math.min( start.y, e.clientY ),
					width: Math.abs( e.clientX - start.x ),
					height: Math.abs( e.clientY - start.y ),
				};
				hl.style.display = '';
				hl.classList.add( 'is-drag' );
				place( hl, r );
				return;
			}
			current = under( e.clientX, e.clientY );
			if ( current ) {
				hl.style.display = '';
				hl.classList.remove( 'is-drag' );
				place( hl, current.getBoundingClientRect() );
			}
		} );
		layer.addEventListener( 'mousedown', function ( e ) {
			e.preventDefault();
			start = { x: e.clientX, y: e.clientY };
		} );
		layer.addEventListener( 'mouseup', function ( e ) {
			e.preventDefault();
			var dragged = start && ( Math.abs( e.clientX - start.x ) > 6 || Math.abs( e.clientY - start.y ) > 6 );
			var rect;
			var node;
			if ( dragged ) {
				rect = {
					left: Math.min( start.x, e.clientX ),
					top: Math.min( start.y, e.clientY ),
					width: Math.abs( e.clientX - start.x ),
					height: Math.abs( e.clientY - start.y ),
				};
				node = under( rect.left + rect.width / 2, rect.top + rect.height / 2 );
			} else {
				node = under( e.clientX, e.clientY );
				rect = node ? node.getBoundingClientRect() : null;
			}
			start = null;
			if ( ! rect ) {
				return;
			}
			stop();
			confirmReport( node, rect, dragged );
		} );
		cancelBtn.addEventListener( 'click', function () {
			stop();
			if ( session && session.spots.length ) {
				showPanel();
			}
		} );
		document.addEventListener( 'keydown', onKey, true );
	}

	/**
	 * Where a dragged box is, relative to an element.
	 *
	 * @param {Element} anchor Anchor.
	 * @param {Object}  rect   Box (viewport coordinates).
	 * @return {Object} { x, y, w, h }.
	 */
	function boxIn( anchor, rect ) {
		// Pixel offsets from the element under the box's centre: a nearby element keeps the box
		// in place even when the page is a different width for support.
		var a = anchor.getBoundingClientRect();
		return {
			px: true,
			x: Math.round( rect.left - a.left ),
			y: Math.round( rect.top - a.top ),
			w: Math.round( rect.width ),
			h: Math.round( rect.height ),
		};
	}

	/* ---------------------------------------------------------------- Confirm and send */

	// The spots picked so far in this report (up to 5) and their numbered marks on the page.
	var session = null;

	/**
	 * Everything about one spot, read now (the page may change before the report is sent).
	 *
	 * @param {Element|null} node   Element (or the anchor of an area).
	 * @param {Object}       rect   Spot (viewport coordinates).
	 * @param {boolean}      isArea A dragged box.
	 * @return {Object} Spot.
	 */
	function spotData( node, rect, isArea ) {
		var log = window.rspPinLog || { errors: [], requests: [] };
		return {
			url: window.location.href,
			title: document.title,
			selector: node ? describe( pathFor( node ) ) : '',
			path: node ? pathFor( node ) : [],
			kind: isArea ? 'area' : 'element',
			box: isArea && node ? boxIn( node, rect ) : null,
			text: node && ! isArea ? String( node.innerText || node.value || '' ).trim().slice( 0, 200 ) : '',
			label: '',
			rect: pageRect( rect ),
			viewport: { w: window.innerWidth, h: window.innerHeight, dpr: window.devicePixelRatio || 1 },
			browser: navigator.userAgent,
			area: cfg.area,
			errors: JSON.parse( JSON.stringify( log.errors ) ),
			requests: JSON.parse( JSON.stringify( log.requests ) ),
		};
	}

	// Drafts never contain the REST nonce, credentials or DOM nodes. Two-hour tab-local lifetime.
	var draftKey = cfg.draft ? 'fxp_spotlight:' + cfg.draft : '';
	var storageFailed = false;
	var submitting = false;
	function localPage( value ) {
		try {
			var url = new URL( value );
			return [ cfg.home, cfg.admin ].some( function ( base ) {
				var root = new URL( base );
				return url.origin === root.origin && ( url.pathname === root.pathname.replace( /\/$/, '' ) || url.pathname.indexOf( root.pathname ) === 0 );
			} ) && ! url.username && ! url.password;
		} catch ( e ) { return false; }
	}
	function pageKey( value ) {
		var url = new URL( value );
		url.searchParams.delete( 'fxp_guide' );
		url.searchParams.delete( 'fxp_spot' );
		return url.origin + url.pathname + url.search;
	}
	function persist() {
		try {
			if ( ! draftKey ) { throw new Error(); }
			if ( ! session || ! session.spots.filter( function ( spot ) { return spot.kind !== 'screenshot'; } ).length ) { window.sessionStorage.removeItem( draftKey ); return; }
			var data = JSON.stringify( { version: 1, expires: Date.now() + 7200000, spots: session.spots.filter( function ( spot ) { return spot.kind !== 'screenshot'; } ).map( function ( spot ) { var copy = Object.assign( {}, spot ); delete copy.shot; return copy; } ) } );
			if ( data.length > 150000 ) { throw new Error(); }
			window.sessionStorage.setItem( draftKey, data );
			storageFailed = false;
		} catch ( e ) { storageFailed = true; }
	}
	function restore() {
		try {
			var raw = window.sessionStorage.getItem( draftKey );
			if ( ! raw ) { return; }
			if ( raw.length > 150000 ) { throw new Error(); }
			var data = JSON.parse( raw );
			if ( data.version !== 1 || ! Number.isFinite( data.expires ) || data.expires <= Date.now() || data.expires > Date.now() + 7200000 || ! Array.isArray( data.spots ) || ! data.spots.length || data.spots.length > 5 ) { throw new Error(); }
			data.spots.forEach( function ( spot ) {
				if ( ! spot || ! localPage( spot.url ) || typeof spot.title !== 'string' || typeof spot.label !== 'string' || spot.label.length > 80 || ! Array.isArray( spot.path ) || spot.path.length > 10 || ! spot.rect || ! spot.viewport || ! [ 'x', 'y', 'w', 'h' ].every( function ( k ) { return Number.isFinite( spot.rect[k] ) && Math.abs( spot.rect[k] ) < 10000000; } ) ) { throw new Error(); }
			} );
			session = { spots: data.spots, marks: [], panel: null };
			drawMarks();
			showBrowse( false );
		} catch ( e ) {
			try { window.sessionStorage.removeItem( draftKey ); } catch ( ignored ) { storageFailed = true; }
		}
	}
	function clearPanel() {
		if ( session && session.panel ) { session.panel.remove(); session.panel = null; }
	}
	function endSession() {
		if ( session ) { session.marks.forEach( function ( n ) { n.remove(); } ); clearPanel(); }
		session = null;
		persist();
	}
	function drawMarks() {
		session.marks.forEach( function ( n ) { n.remove(); } );
		session.marks = [];
		session.spots.forEach( function ( spot, i ) {
			if ( spot.kind === 'screenshot' || pageKey( spot.url ) !== pageKey( window.location.href ) ) { return; }
			var mark = el( 'div', PREFIX + '-box is-picked is-page' );
			mark.style.left = spot.rect.x + 'px'; mark.style.top = spot.rect.y + 'px';
			mark.style.width = spot.rect.w + 'px'; mark.style.height = spot.rect.h + 'px';
			mark.appendChild( el( 'span', PREFIX + '-num', String( i + 1 ) ) );
			document.body.appendChild( mark ); session.marks.push( mark );
		} );
	}
	function confirmReport( node, rect, isArea ) {
		if ( ! session ) { session = { spots: [], marks: [], panel: null }; }
		if ( session.spots.length >= 5 || ! localPage( window.location.href ) ) { showPanel(); return; }
		session.spots.push( spotData( node, rect, isArea ) );
		persist(); drawMarks(); showPanel( session.spots.length - 1 );
	}
	function button( parent, text, action, primary ) {
		var btn = el( 'button', PREFIX + '-btn' + ( primary ? ' is-primary' : '' ), text );
		btn.type = 'button'; btn.addEventListener( 'click', action ); parent.appendChild( btn ); return btn;
	}
	// Support: a way back to the support session, so the browser's Back button is never needed.
	function backToSession( parent ) {
		if ( ! cfg.session ) { return null; }
		var a = el( 'a', PREFIX + '-btn is-primary', t.backToSession ); a.href = cfg.session; parent.appendChild( a ); return a;
	}
	function storageWarning( panel ) {
		if ( storageFailed ) { var warning = el( 'p', PREFIX + '-error', t.storage ); warning.setAttribute( 'role', 'alert' ); panel.appendChild( warning ); }
	}
	function showBrowse( focus ) {
		if ( submitting ) { return; }
		clearPanel();
		if ( ! session || ! session.spots.length ) { return; }
		var bar = el( 'div', PREFIX + '-panel is-browse' ); session.panel = bar;
		bar.setAttribute( 'role', 'region' ); bar.setAttribute( 'aria-label', t.title );
		var count = el( 'span', '', t.count.replace( '%d', session.spots.length ) ); count.setAttribute( 'role', 'status' ); bar.appendChild( count );
		if ( session.spots.length < 5 ) { button( bar, t.capture, function () { clearPanel(); pick(); } ); }
		var review = button( bar, t.review, showPanel );
		button( bar, t.next, finish, true ); storageWarning( bar ); document.body.appendChild( bar );
		if ( focus !== false ) { review.focus(); }
	}

	/* ---------------------------------------------------------------- Screenshots (only when the agreement allows) */

	// Fields that must never reach support: covered automatically, before the client sees the preview.
	var SENSITIVE = 'input[type="password"],input[autocomplete^="cc-"],input[autocomplete="one-time-code"],input[name*="card" i],input[name*="cvv" i],input[name*="cvc" i],input[name*="iban" i],input[name*="ssn" i],input[name*="pass" i],input[id*="card" i],input[id*="cvv" i],input[id*="cvc" i],iframe[name*="card" i],iframe[src*="stripe" i],iframe[src*="paypal" i]';
	var libLoading = null;
	function loadLib() {
		if ( window.html2canvas ) { return Promise.resolve(); }
		if ( ! libLoading ) {
			libLoading = new Promise( function ( resolve, reject ) {
				var tag = document.createElement( 'script' );
				tag.src = cfg.shotLib; tag.onload = resolve; tag.onerror = function () { libLoading = null; reject(); };
				document.head.appendChild( tag );
			} );
		}
		return libLoading;
	}
	function shotRow( field, spot, i ) {
		var row = el( 'div', PREFIX + '-shot' );
		if ( spot.shot ) {
			var img = el( 'img', PREFIX + '-thumb' ); img.src = spot.shot; img.alt = '';
			row.appendChild( img );
			button( row, t.shotRemove, function () {
				if ( spot.kind === 'screenshot' ) { session.spots.splice( i, 1 ); persist(); drawMarks(); if ( session.spots.length ) { showPanel(); } else { endSession(); } return; }
				delete spot.shot; showPanel( i );
			} );
		} else {
			button( row, t.shotAdd, function () { takeShot( spot, i ); } );
			row.appendChild( el( 'p', PREFIX + '-muted', t.shotNote ) );
		}
		field.appendChild( row );
	}
	function takeShot( spot, i, after ) {
		var rects = [];
		Array.prototype.forEach.call( document.querySelectorAll( SENSITIVE ), function ( n ) {
			if ( ours( n ) ) { return; }
			var r = n.getBoundingClientRect();
			if ( r.width > 0 && r.height > 0 ) { rects.push( { x: r.left, y: r.top, w: r.width, h: r.height } ); }
		} );
		var hidden = Array.prototype.slice.call( document.querySelectorAll( '.' + MARK ) );
		hidden.forEach( function ( n ) { n.style.visibility = 'hidden'; } );
		// Redrawing the page makes the browser report errors that are not the site's (for example an aborted view transition). Keep them out of the report.
		var log = window.rspPinLog;
		if ( log ) { log.hold = true; }
		var release = function () { if ( log ) { window.setTimeout( function () { log.hold = false; }, 1500 ); } };
		var failed = function () {
			release();
			hidden.forEach( function ( n ) { n.style.visibility = ''; } );
			if ( after ) { after( false, true ); return; }
			if ( session && session.panel ) { var e = el( 'p', PREFIX + '-error', t.shotFail ); e.setAttribute( 'role', 'alert' ); session.panel.appendChild( e ); }
		};
		var w = window.innerWidth, h = window.innerHeight, scale = Math.min( 1, 1400 / w );
		loadLib().then( function () {
			return window.html2canvas( document.documentElement, {
				x: window.scrollX, y: window.scrollY, width: w, height: h, windowWidth: document.documentElement.scrollWidth, windowHeight: document.documentElement.scrollHeight,
				scale: scale, useCORS: true, logging: false, allowTaint: false, backgroundColor: '#ffffff',
				ignoreElements: function ( n ) { return n.id === 'wpadminbar' || !! ( n.classList && n.classList.contains( MARK ) ); },
				onclone: function ( doc ) {
					Array.prototype.forEach.call( doc.querySelectorAll( SENSITIVE ), function ( n ) { if ( 'value' in n ) { n.value = ''; } n.setAttribute( 'value', '' ); } );
				},
			} );
		} ).then( function ( canvas ) {
			release();
			hidden.forEach( function ( n ) { n.style.visibility = ''; } );
			previewShot( canvas, rects.map( function ( r ) { return { x: r.x * scale, y: r.y * scale, w: r.w * scale, h: r.h * scale }; } ), function ( data ) {
				if ( data ) { spot.shot = data; }
				if ( after ) { after( !! data, false ); return; }
				showPanel( i );
			} );
		} ).catch( failed );
	}
	// Full-page preview: the client sees exactly what would be sent, and can cover areas or mark the problem.
	function previewShot( source, auto, done ) {
		var marks = [];
		var tool = 'arrow';
		var layer = el( 'div', PREFIX + '-shotview' ); layer.setAttribute( 'role', 'dialog' ); layer.setAttribute( 'aria-label', t.shotTitle );
		var head = el( 'div', PREFIX + '-shotview__head' );
		head.appendChild( el( 'strong', '', t.shotTitle ) );
		var body = el( 'div', PREFIX + '-shotview__body' );
		var tools = el( 'div', PREFIX + '-row' ); tools.setAttribute( 'role', 'group' ); tools.setAttribute( 'aria-label', t.shotTools );
		var canvas = el( 'canvas', PREFIX + '-shotview__canvas' ); canvas.width = source.width; canvas.height = source.height;
		var ctx = canvas.getContext( '2d' );
		var unit = Math.max( 2, Math.round( source.width / 400 ) ); // Line width that reads on any screen size.
		function draw( m ) {
			if ( m.k === 'cover' ) { ctx.fillStyle = '#111111'; ctx.fillRect( m.x, m.y, m.w, m.h ); return; }
			ctx.strokeStyle = '#e5242b'; ctx.fillStyle = '#e5242b'; ctx.lineWidth = unit * 1.5; ctx.lineCap = 'round'; ctx.lineJoin = 'round';
			if ( m.k === 'box' ) { ctx.strokeRect( m.x, m.y, m.w, m.h ); }
			if ( m.k === 'pen' ) { ctx.beginPath(); m.pts.forEach( function ( q, n ) { if ( n ) { ctx.lineTo( q.x, q.y ); } else { ctx.moveTo( q.x, q.y ); } } ); ctx.stroke(); }
			if ( m.k === 'arrow' ) {
				var dx = m.b.x - m.a.x, dy = m.b.y - m.a.y, len = Math.sqrt( dx * dx + dy * dy );
				if ( len < 4 ) { return; }
				var head = Math.min( len * 0.5, unit * 8 ), ang = Math.atan2( dy, dx );
				ctx.beginPath(); ctx.moveTo( m.a.x, m.a.y ); ctx.lineTo( m.b.x, m.b.y ); ctx.stroke();
				ctx.beginPath(); ctx.moveTo( m.b.x, m.b.y );
				ctx.lineTo( m.b.x - head * Math.cos( ang - 0.45 ), m.b.y - head * Math.sin( ang - 0.45 ) );
				ctx.lineTo( m.b.x - head * Math.cos( ang + 0.45 ), m.b.y - head * Math.sin( ang + 0.45 ) );
				ctx.closePath(); ctx.fill();
			}
		}
		function paint( live ) {
			ctx.drawImage( source, 0, 0 );
			auto.forEach( function ( c ) { draw( { k: 'cover', x: c.x, y: c.y, w: c.w, h: c.h } ); } );
			// Covers go on last, so nothing drawn can reveal what a cover hides.
			var all = marks.concat( live ? [ live ] : [] );
			all.filter( function ( m ) { return m.k !== 'cover'; } ).forEach( draw );
			all.filter( function ( m ) { return m.k === 'cover'; } ).forEach( draw );
		}
		paint();
		var drag = null;
		function at( e ) {
			var b = canvas.getBoundingClientRect();
			return { x: ( e.clientX - b.left ) * canvas.width / b.width, y: ( e.clientY - b.top ) * canvas.height / b.height };
		}
		function rectOf( a, b ) { return { x: Math.min( a.x, b.x ), y: Math.min( a.y, b.y ), w: Math.abs( a.x - b.x ), h: Math.abs( a.y - b.y ) }; }
		function shape( a, b, pts ) {
			if ( tool === 'arrow' ) { return { k: 'arrow', a: a, b: b }; }
			if ( tool === 'pen' ) { return { k: 'pen', pts: pts }; }
			return Object.assign( { k: tool }, rectOf( a, b ) );
		}
		canvas.addEventListener( 'pointerdown', function ( e ) { var p = at( e ); drag = { a: p, pts: [ p ] }; canvas.setPointerCapture( e.pointerId ); } );
		canvas.addEventListener( 'pointermove', function ( e ) { if ( ! drag ) { return; } var p = at( e ); drag.pts.push( p ); paint( shape( drag.a, p, drag.pts ) ); } );
		canvas.addEventListener( 'pointerup', function ( e ) {
			if ( ! drag ) { return; }
			var p = at( e ), m = shape( drag.a, p, drag.pts.concat( [ p ] ) ); drag = null;
			var big = m.k === 'pen' ? m.pts.length > 2 : m.k === 'arrow' ? Math.abs( p.x - m.a.x ) + Math.abs( p.y - m.a.y ) > 8 : m.w > 6 && m.h > 6;
			if ( big ) { marks.push( m ); }
			paint(); undo.disabled = marks.length === 0;
		} );
		var buttons = {};
		[ [ 'arrow', t.shotArrow ], [ 'box', t.shotBox ], [ 'pen', t.shotPen ], [ 'cover', t.shotCover ] ].forEach( function ( x ) {
			buttons[ x[0] ] = button( tools, x[1], function () {
				tool = x[0];
				Object.keys( buttons ).forEach( function ( k ) { buttons[ k ].setAttribute( 'aria-pressed', k === tool ? 'true' : 'false' ); buttons[ k ].classList.toggle( 'is-on', k === tool ); } );
			} );
			buttons[ x[0] ].setAttribute( 'aria-pressed', x[0] === tool ? 'true' : 'false' ); buttons[ x[0] ].classList.toggle( 'is-on', x[0] === tool );
		} );
		var row = el( 'div', PREFIX + '-row' );
		var undo = button( row, t.shotUndo, function () { marks.pop(); paint(); undo.disabled = marks.length === 0; } ); undo.disabled = true;
		function close( data ) { layer.remove(); document.removeEventListener( 'keydown', onKey ); done( data ); }
		function onKey( e ) { if ( e.key === 'Escape' ) { e.preventDefault(); close( null ); } }
		button( row, t.shotSkip, function () { close( null ); } );
		button( row, t.shotUse, function () {
			var quality = 0.72, out = canvas.toDataURL( 'image/jpeg', quality );
			while ( out.length > 560000 && quality > 0.3 ) { quality -= 0.1; out = canvas.toDataURL( 'image/jpeg', quality ); }
			if ( out.length > 560000 ) { close( null ); return; }
			close( out );
		}, true );
		head.appendChild( row ); layer.appendChild( head );
		body.appendChild( tools ); body.appendChild( el( 'p', PREFIX + '-muted', t.shotHint ) ); body.appendChild( canvas );
		layer.appendChild( body );
		document.body.appendChild( layer ); document.addEventListener( 'keydown', onKey );
	}
	// Support: show the client's screenshot, fetched from the client's site while access is open.
	function viewShot( id ) {
		window.fetch( cfg.api + 'spot/' + id + '/shot', { credentials: 'same-origin' } )
			.then( function ( r ) { return r.ok ? r.json() : Promise.reject(); } )
			.then( function ( res ) {
				var layer = el( 'div', PREFIX + '-shotview' ); layer.setAttribute( 'role', 'dialog' ); layer.setAttribute( 'aria-label', t.shotView );
				var head = el( 'div', PREFIX + '-shotview__head' ); head.appendChild( el( 'strong', '', t.shotView ) );
				var row = el( 'div', PREFIX + '-row' );
				var fit = true; var img = el( 'img', PREFIX + '-shotview__canvas' ); img.src = res.image; img.alt = '';
				var size = button( row, t.shotActual, function () { fit = ! fit; layer.classList.toggle( 'is-actual', ! fit ); size.textContent = fit ? t.shotActual : t.shotFit; } );
				var tab = el( 'a', PREFIX + '-btn', t.shotNewTab ); tab.href = res.image; tab.target = '_blank'; tab.rel = 'noopener'; row.appendChild( tab );
				backToSession( row );
				button( row, t.close, function () { layer.remove(); } );
				head.appendChild( row );
				var body = el( 'div', PREFIX + '-shotview__body' );
				body.appendChild( img ); layer.appendChild( head ); layer.appendChild( body ); document.body.appendChild( layer );
			} )
			.catch( function () { var l = el( 'div', PREFIX + '-label is-fixed', t.shotGone ); document.body.appendChild( l ); setTimeout( function () { l.remove(); }, 5000 ); } );
	}

	// A screenshot of the page on its own, without pointing at anything.
	function screenshotOnly() {
		if ( ! cfg.shots || submitting || ! localPage( window.location.href ) ) { return; }
		if ( ! session ) { session = { spots: [], marks: [], panel: null }; }
		if ( session.spots.length >= 5 ) { showPanel(); return; }
		clearPanel();
		var spot = spotData( null, { left: 0, top: 0, width: window.innerWidth, height: window.innerHeight }, false );
		spot.kind = 'screenshot'; spot.label = '';
		session.spots.push( spot );
		var index = session.spots.length - 1;
		takeShot( spot, index, function ( ok, failed ) {
			if ( ! ok ) {
				session.spots.splice( session.spots.indexOf( spot ), 1 );
			}
			persist(); drawMarks();
			// The new screenshot's own note gets the cursor, not the first spot's.
			if ( session.spots.length ) { showPanel( ok ? session.spots.indexOf( spot ) : undefined ); } else { endSession(); }
			if ( ! ok && failed ) {
				var note = el( 'div', PREFIX + '-label is-fixed', t.shotFail ); note.setAttribute( 'role', 'alert' );
				document.body.appendChild( note ); window.setTimeout( function () { note.remove(); }, 6000 );
			}
		} );
	}
	function showPanel( focusIndex ) {
		if ( submitting ) { return; }
		clearPanel();
		if ( ! session || ! session.spots.length ) { return; }
		var panel = el( 'div', PREFIX + '-panel' ); session.panel = panel;
		panel.setAttribute( 'role', 'dialog' ); panel.setAttribute( 'aria-label', t.title );
		panel.appendChild( el( 'strong', PREFIX + '-panel__title', t.title ) );
		var count = el( 'p', PREFIX + '-muted', t.count.replace( '%d', session.spots.length ) ); count.setAttribute( 'role', 'status' ); panel.appendChild( count );
		session.spots.forEach( function ( spot, i ) {
			var field = el( 'div', PREFIX + '-review' );
			field.appendChild( el( 'p', PREFIX + '-page', ( i + 1 ) + '. ' + ( spot.kind === 'screenshot' ? t.shotOnlyTitle + ' · ' : '' ) + spot.title ) );
			field.appendChild( el( 'p', PREFIX + '-muted', spot.url ) );
			var wrap = el( 'label', PREFIX + '-field', t.label );
			var input = el( 'input' ); input.type = 'text'; input.maxLength = 80; input.value = spot.label; input.placeholder = t.labelHint;
			input.addEventListener( 'input', function () {
				spot.label = input.value.slice( 0, 80 ); persist();
				if ( storageFailed && ! panel.querySelector( '.' + PREFIX + '-error' ) ) { storageWarning( panel ); }
			} );
			wrap.appendChild( input ); field.appendChild( wrap );
			if ( cfg.shots ) { shotRow( field, spot, i ); }
			button( field, t.remove + ' ' + ( i + 1 ), function () {
				session.spots.splice( i, 1 ); persist(); drawMarks();
				if ( session.spots.length ) { showPanel(); } else { endSession(); }
			} ); panel.appendChild( field );
		} );
		panel.appendChild( el( 'p', PREFIX + '-muted', t.what ) );
		var row = el( 'div', PREFIX + '-row' );
		button( row, t.next, finish, true );
		if ( session.spots.length < 5 ) { button( row, t.another, function () { clearPanel(); pick(); } ); }
		button( row, t.browse, showBrowse );
		button( row, t.discard, endSession ); panel.appendChild( row ); storageWarning( panel );
		panel.addEventListener( 'keydown', function ( e ) { if ( e.key === 'Escape' ) { e.preventDefault(); showBrowse(); } } );
		document.body.appendChild( panel );
		var inputs = panel.querySelectorAll( 'input' );
		var index = typeof focusIndex === 'number' ? Math.max( 0, Math.min( focusIndex, inputs.length - 1 ) ) : 0;
		inputs[ index ].focus();
		var current = inputs[ index ].closest( '.' + PREFIX + '-review' );
		if ( current && typeof focusIndex === 'number' && session.spots.length > 1 ) { current.classList.add( 'is-current' ); }
		if ( current && current.scrollIntoView ) { current.scrollIntoView( { block: 'nearest' } ); }
	}
	function finish() {
		if ( submitting || ! session || ! session.spots.length ) { return; }
		submitting = true;
		var panel = session.panel;
		Array.prototype.forEach.call( panel.querySelectorAll( 'button, input' ), function ( n ) { n.disabled = true; } );
		window.fetch( cfg.api + 'admin/spot', {
			method: 'POST', credentials: 'same-origin',
			headers: { 'Content-Type': 'application/json', 'X-WP-Nonce': cfg.nonce },
			body: JSON.stringify( { spots: session.spots } ),
		} ).then( function ( r ) { if ( ! r.ok ) { throw new Error(); } return r.json(); } ).then( function ( res ) {
			if ( ! Array.isArray( res.ids ) || res.ids.length !== session.spots.length || ! res.ids.every( function ( id ) { return /^[a-z0-9]{32}$/.test( id ); } ) ) { throw new Error(); }
			var target = cfg.back + res.ids.join( ',' ); endSession();
			var here = window.location.href.split( '#' )[0]; window.location.href = target;
			if ( target.split( '#' )[0] === here ) { window.location.reload(); }
		} ).catch( function () {
			Array.prototype.forEach.call( panel.querySelectorAll( 'button, input' ), function ( n ) { n.disabled = false; } );
			var error = el( 'p', PREFIX + '-error', t.failed ); error.setAttribute( 'role', 'alert' ); panel.appendChild( error );
		} ).finally( function () { submitting = false; } );
	}

	/* ---------------------------------------------------------------- Highlighting (support) */

	function highlight( id ) {
		var pinId = id;
		window
			.fetch( cfg.api + 'spot/' + id, { credentials: 'same-origin' } )
			.then( function ( r ) {
				return r.ok ? r.json() : Promise.reject();
			} )
			.then( function ( spot ) {
				return new Promise( function ( resolve ) {
					var tries = 0;
					( function look() {
						var found = null;
						if ( spot.kind === 'screenshot' ) { resolve( { spot: spot, node: null } ); return; }
						if ( spot.path && spot.path.length ) {
							found = resolvePath( spot.path );
						} else {
							try {
								found = spot.selector ? document.querySelector( spot.selector ) : null;
							} catch ( e ) {
								found = null;
							}
						}
						// Screens built by scripts can appear late: keep looking for a few seconds.
						if ( found || tries++ >= 16 ) {
							resolve( { spot: spot, node: found } );
						} else {
							window.setTimeout( look, 500 );
						}
					} )();
				} );
			} )
			.then( function ( found ) {
				var spot = found.spot;
				var node = found.node;
				if ( spot.kind === 'screenshot' ) {
					var only = el( 'div', PREFIX + '-label is-fixed', t.shotOnlyTitle );
					if ( spot.shot ) { var see = el( 'button', PREFIX + '-btn', t.shotView ); see.type = 'button'; see.addEventListener( 'click', function () { viewShot( pinId ); } ); only.appendChild( see ); }
					backToSession( only );
					var shut = el( 'button', PREFIX + '-btn', t.close ); shut.type = 'button'; shut.addEventListener( 'click', function () { only.remove(); } ); only.appendChild( shut );
					document.body.appendChild( only );
					return;
				}
				var box = el( 'div', PREFIX + '-box is-highlight' );
				var label = el( 'div', PREFIX + '-label', node ? t.here : t.notFound );
				var close = el( 'button', PREFIX + '-btn', t.close );
				close.type = 'button';
				if ( spot.shot ) { var view = el( 'button', PREFIX + '-btn', t.shotView ); view.type = 'button'; view.addEventListener( 'click', function () { viewShot( pinId ); } ); label.appendChild( view ); }
				backToSession( label );
				label.appendChild( close );
				document.body.appendChild( box );
				document.body.appendChild( label );
				var recorded = function () {
					return {
						left: spot.rect.x - window.scrollX,
						top: spot.rect.y - window.scrollY,
						width: spot.rect.w,
						height: spot.rect.h,
					};
				};
				function update() {
					var a = node ? node.getBoundingClientRect() : null;
					var b = spot.box;
					var r;
					if ( a && spot.kind === 'area' && b ) {
						r = b.px
							? { left: a.left + b.x, top: a.top + b.y, width: b.w, height: b.h }
							: {
									left: a.left + b.x * a.width,
									top: a.top + b.y * a.height,
									width: b.w * a.width,
									height: b.h * a.height,
							  };
					} else {
						r = a || recorded();
					}
					// On a screen about as wide as the customer's, a box far bigger or smaller than
					// what they picked means the page differs here: show where they picked instead.
					var similar = spot.viewport && spot.viewport.w && Math.abs( window.innerWidth - spot.viewport.w ) / spot.viewport.w < 0.25;
					var off = function ( got, want ) {
						return want > 0 && ( got > want * 2.5 || got < want * 0.4 );
					};
					if ( a && similar && ( off( r.width, spot.rect.w ) || off( r.height, spot.rect.h ) ) ) {
						r = recorded();
					}
					place( box, r );
					label.style.left = Math.max( 8, r.left ) + 'px';
					label.style.top = Math.max( 8, r.top - 44 ) + 'px';
				}
				if ( node ) {
					node.scrollIntoView( { block: 'center' } );
				} else {
					window.scrollTo( 0, Math.max( 0, spot.rect.y - 120 ) );
				}
				update();
				window.addEventListener( 'scroll', update, { passive: true } );
				window.addEventListener( 'resize', update );
				close.addEventListener( 'click', function () {
					box.remove();
					label.remove();
					window.removeEventListener( 'scroll', update );
					window.removeEventListener( 'resize', update );
				} );
			} )
			.catch( function () {
				var label = el( 'div', PREFIX + '-label is-fixed', t.pinGone );
				document.body.appendChild( label );
				setTimeout( function () {
					label.remove();
				}, 5000 );
			} );
	}

	/**
	 * First time only (per browser): explain Spotlight before the page is paused for picking.
	 */
	function start() {
		if ( ! cfg.can || submitting ) { return; }
		if ( session && session.spots.length ) { showPanel(); return; }
		var seen = false;
		try {
			seen = window.localStorage.getItem( 'fxp_spotlight_intro' ) === '1';
		} catch ( e ) {}
		if ( seen || document.querySelector( '.' + PREFIX + '-intro' ) ) {
			pick();
			return;
		}
		var bg = el( 'div', PREFIX + '-intro-bg' );
		var card = el( 'div', PREFIX + '-intro' );
		card.setAttribute( 'role', 'dialog' );
		card.setAttribute( 'aria-modal', 'true' );
		card.appendChild( el( 'strong', PREFIX + '-intro__title', t.introTitle ) );
		var list = el( 'ol', PREFIX + '-intro__steps' );
		[ t.intro1, t.intro2, t.intro3 ].forEach( function ( line ) {
			list.appendChild( el( 'li', '', line ) );
		} );
		card.appendChild( list );
		card.appendChild( el( 'p', PREFIX + '-intro__note', t.introPause ) );
		card.appendChild( el( 'p', PREFIX + '-intro__note', t.introPrivacy ) );
		if ( cfg.shots ) { card.appendChild( el( 'p', PREFIX + '-intro__note', t.introShot ) ); }
		var hide = el( 'label', PREFIX + '-intro__hide' );
		var box = document.createElement( 'input' );
		box.type = 'checkbox';
		box.checked = false;
		hide.appendChild( box );
		hide.appendChild( document.createTextNode( ' ' + t.introHide ) );
		card.appendChild( hide );
		var row = el( 'div', PREFIX + '-row' );
		var go = el( 'button', PREFIX + '-btn is-primary', t.introStart );
		var no = el( 'button', PREFIX + '-btn', t.cancel );
		go.type = 'button';
		no.type = 'button';
		row.appendChild( go );
		if ( cfg.shots ) {
			var only = el( 'button', PREFIX + '-btn', t.shotOnly );
			only.type = 'button';
			only.addEventListener( 'click', function () {
				if ( box.checked ) { try { window.localStorage.setItem( 'fxp_spotlight_intro', '1' ); } catch ( e ) {} }
				close();
				screenshotOnly();
			} );
			row.appendChild( only );
		}
		row.appendChild( no );
		card.appendChild( row );
		document.body.appendChild( bg );
		document.body.appendChild( card );
		go.focus();
		function close() {
			bg.remove();
			card.remove();
			document.removeEventListener( 'keydown', onKey, true );
		}
		function onKey( e ) {
			if ( e.key === 'Escape' ) {
				e.preventDefault();
				close();
			}
		}
		document.addEventListener( 'keydown', onKey, true );
		bg.addEventListener( 'click', close );
		no.addEventListener( 'click', close );
		go.addEventListener( 'click', function () {
			if ( box.checked ) {
				try {
					window.localStorage.setItem( 'fxp_spotlight_intro', '1' );
				} catch ( e ) {}
			}
			close();
			pick();
		} );
	}

	function ready( fn ) {
		if ( document.readyState === 'loading' ) {
			document.addEventListener( 'DOMContentLoaded', fn );
		} else {
			fn();
		}
	}

	// Guided by the Fixpass page ("Show the problem"): keep the toolbar button pulsing, with a hint
	// beside it, so the owner knows what to click. Remembered for this browser tab until they use
	// the button, hide the hint, or come back to the Fixpass page.
	var GUIDE = 'fxpGuide';

	function guideKept() {
		try {
			return window.sessionStorage.getItem( GUIDE ) === '1';
		} catch ( e ) {
			return false;
		}
	}

	function guideKeep( on ) {
		try {
			if ( on ) {
				window.sessionStorage.setItem( GUIDE, '1' );
			} else {
				window.sessionStorage.removeItem( GUIDE );
			}
		} catch ( e ) {}
	}

	function guideEnd() {
		guideKeep( false );
		var li = document.getElementById( 'wp-admin-bar-fixpass-spotlight' );
		if ( li ) {
			li.classList.remove( 'fxp-glow' );
		}
		var hint = document.querySelector( '.' + PREFIX + '-hint' );
		if ( hint ) {
			hint.remove();
		}
	}

	function guideShow() {
		var li = document.getElementById( 'wp-admin-bar-fixpass-spotlight' );
		if ( ! li || /[?&]page=fixpass/.test( window.location.search ) ) {
			return;
		}
		li.classList.add( 'fxp-glow' );
		var hint = el( 'div', PREFIX + '-hint' );
		hint.setAttribute( 'role', 'status' );
		hint.appendChild( el( 'span', '', t.guideHint || 'Click here, then click the problem on this page' ) );
		var close = el( 'button', PREFIX + '-hint__x', '×' );
		close.type = 'button';
		close.setAttribute( 'aria-label', t.guideStop || 'Hide this hint' );
		close.addEventListener( 'click', guideEnd );
		hint.appendChild( close );
		document.body.appendChild( hint );
		function place() {
			var r = li.getBoundingClientRect();
			hint.style.top = Math.round( r.bottom + 12 ) + 'px';
			hint.style.right = Math.max( 8, Math.round( window.innerWidth - r.right ) ) + 'px';
		}
		place();
		window.addEventListener( 'resize', place );
	}

	ready( function () {
		if ( cfg.can && /[?&]fxp_guide=1/.test( window.location.search ) ) {
			guideKeep( true );
		}
		if ( cfg.can && guideKept() ) {
			guideShow();
		}
		if ( cfg.pin ) {
			// Wait for late layout (images, fonts) so the spot is where it was.
			window.setTimeout( function () {
				highlight( cfg.pin );
			}, 600 );
		}
		if ( cfg.can ) {
			if ( draftKey ) { restore(); }
			cfg.start = start;
			document.addEventListener( 'click', function ( e ) {
				var a = e.target.closest && e.target.closest( '#wp-admin-bar-fixpass-spotlight a' );
				if ( a ) {
					e.preventDefault();
					guideEnd();
					start();
				}
			} );
		}
	} );
} )();
