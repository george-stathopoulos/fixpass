/* Keeps the Fixpass toolbar items current while a page stays open (WordPress Heartbeat). */
( function ( $ ) {
	var cfg = window.fixpassInbox;
	if ( ! cfg || ! $ ) { return; }
	function item( id, label, count ) {
		var node = document.getElementById( 'wp-admin-bar-' + id );
		if ( ! count ) { if ( node && node.parentNode ) { node.parentNode.removeChild( node ); } return; }
		if ( ! node ) {
			var bar = document.getElementById( 'wp-admin-bar-top-secondary' );
			if ( ! bar ) { return; }
			node = document.createElement( 'li' );
			node.id = 'wp-admin-bar-' + id;
			node.className = 'fxp-ab-messages';
			var a = document.createElement( 'a' );
			a.className = 'ab-item';
			a.href = cfg.page + ( id === 'fixpass-messages' ? '#fixpass-messages' : '' );
			var span = document.createElement( 'span' );
			span.className = 'ab-label';
			span.textContent = label + ' ';
			var badge = document.createElement( 'span' );
			badge.className = 'fxp-ab-badge';
			a.appendChild( span ); a.appendChild( badge ); node.appendChild( a );
			bar.insertBefore( node, bar.firstChild );
		}
		var b = node.querySelector( '.fxp-ab-badge' );
		if ( b ) { b.textContent = count > 99 ? '99+' : String( count ); }
	}
	function presence( state ) {
		var node = document.getElementById( 'wp-admin-bar-fixpass-presence' );
		if ( ! state ) { if ( node && node.parentNode ) { node.parentNode.removeChild( node ); } return; }
		var text = cfg.presence && cfg.presence[ state ];
		if ( ! text ) { return; }
		if ( ! node ) {
			var bar = document.getElementById( 'wp-admin-bar-top-secondary' );
			if ( ! bar ) { return; }
			node = document.createElement( 'li' );
			node.id = 'wp-admin-bar-fixpass-presence';
			var a = document.createElement( 'a' );
			a.className = 'ab-item';
			a.href = cfg.page;
			var dot = document.createElement( 'span' );
			dot.className = 'fxp-ab-dot';
			var label = document.createElement( 'span' );
			label.className = 'ab-label';
			a.appendChild( dot ); a.appendChild( label ); node.appendChild( a );
			bar.insertBefore( node, bar.firstChild );
		}
		var d = node.querySelector( '.fxp-ab-dot' );
		d.className = 'fxp-ab-dot' + ( state === 'live' ? ' is-live' : '' ) + ( state === 'done' ? ' is-done' : '' );
		node.className = state === 'live' ? 'fxp-ab-live' : 'fxp-ab-idle';
		node.querySelector( '.ab-label' ).textContent = text[ 0 ];
		node.setAttribute( 'title', text[ 1 ] );
	}
	$( document ).on( 'heartbeat-send', function ( e, data ) { data.fixpass_inbox = 1; } );
	$( document ).on( 'heartbeat-tick', function ( e, data ) {
		if ( ! data.fixpass_inbox ) { return; }
		item( 'fixpass-messages', cfg.messages, data.fixpass_inbox.messages );
		item( 'fixpass-request', cfg.requests, data.fixpass_inbox.requests );
		presence( data.fixpass_inbox.presence );
	} );
}( window.jQuery ) );
